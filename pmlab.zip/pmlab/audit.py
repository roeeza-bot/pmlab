"""
ביקורת סטטיסטית עצמאית.  python3 audit.py

לא בודק שהקוד רץ — בודק שהמסקנות שהוא מייצר נכונות.
כל בדיקה כאן מנסה *להפריך* הנחה במודל.
"""

import sys

import numpy as np

sys.path.insert(0, ".")

from pmlab.core.stats import benjamini_hochberg, paired_bootstrap
from pmlab.power import required_n

FINDINGS = []


def finding(severity, title, detail):
    FINDINGS.append((severity, title, detail))
    tag = {"CRIT": "‼", "WARN": "⚠", "INFO": "·"}[severity]
    print(f"\n  {tag} [{severity}] {title}")
    for line in detail.strip().split("\n"):
        print(f"      {line}")


# ═══════════ 1. האם ה-SD בניתוח העוצמה מציאותי? ═══════════
def audit_sd_assumption():
    print("\n" + "─" * 66)
    print("  1. הנחת ה-SD בניתוח העוצמה")
    print("─" * 66)

    rng = np.random.default_rng(0)
    sds = []
    for _ in range(400):
        n = 500
        p = rng.uniform(0.05, 0.95, n)
        out = (rng.random(n) < p).astype(int)
        mkt = np.clip(p + rng.normal(0, 0.09, n), 0.01, 0.99)
        agt = np.clip(p + rng.normal(0, 0.06, n), 0.01, 0.99)
        d = (mkt - out) ** 2 - (agt - out) ** 2
        sds.append(d.std())
    emp = np.mean(sds)
    print(f"\n  SD אמפירי של ההפרש המזווג: {emp:.4f}")
    print(f"  SD שהונח בקוד:              0.1000")

    if abs(emp - 0.10) / 0.10 > 0.25:
        finding("WARN", "הנחת SD לא מדויקת",
                f"האמפירי הוא {emp:.4f}, לא 0.10.\n"
                f"n הנדרש משתנה ביחס לריבוע -> פי {(emp/0.10)**2:.2f}.")
    else:
        finding("INFO", "הנחת SD סבירה",
                f"פער של {abs(emp-0.10)/0.10*100:.0f}% בלבד. הסדר גודל תקף.")

    # תלות בהתפלגות ההסתברויות
    print("\n  רגישות ל-mix של ההסתברויות:")
    for lo, hi, label in [(0.4, 0.6, "צמוד ל-50%"),
                          (0.05, 0.95, "מפוזר"),
                          (0.02, 0.98, "כולל קיצונים")]:
        ds = []
        for _ in range(200):
            p = rng.uniform(lo, hi, 400)
            out = (rng.random(400) < p).astype(int)
            mkt = np.clip(p + rng.normal(0, 0.09, 400), 0.01, 0.99)
            agt = np.clip(p + rng.normal(0, 0.06, 400), 0.01, 0.99)
            ds.append(((mkt - out) ** 2 - (agt - out) ** 2).std())
        print(f"    {label:<18} SD = {np.mean(ds):.4f}")

    finding("INFO", "ה-SD תלוי בהרכב השווקים",
            "שווקים צמודים ל-50% מייצרים SD נמוך יותר -> צריך פחות דגימות.\n"
            "כדאי לחשב את ה-SD מהנתונים בפועל, לא להניח אותו.")


# ═══════════ 2. האם ה-p של הבוטסטרפ מכויל? ═══════════
def audit_bootstrap_calibration():
    print("\n" + "─" * 66)
    print("  2. כיול ערכי ה-p של הבוטסטרפ")
    print("─" * 66)
    print("\n  תחת ההשערה הריקה, p אמור להתפלג אחיד.")
    print("  אם הוא מוטה כלפי מטה -> יותר מדי זיהויים שגויים.\n")

    rng = np.random.default_rng(1)
    ps = []
    for t in range(600):
        n = 60
        p = rng.uniform(0.1, 0.9, n)
        out = (rng.random(n) < p).astype(int)
        a = np.clip(p + rng.normal(0, 0.09, n), 0.01, 0.99)
        m = np.clip(p + rng.normal(0, 0.09, n), 0.01, 0.99)
        r = paired_bootstrap((a - out) ** 2, (m - out) ** 2,
                             n_boot=1200, seed=t)
        ps.append(r["p_value"])
    ps = np.array(ps)

    for alpha in (0.01, 0.05, 0.10):
        rate = (ps < alpha).mean()
        status = "✓" if rate <= alpha * 1.6 else "✗"
        print(f"    P(p < {alpha:.2f}) = {rate:.4f}   (יעד ≈ {alpha})  {status}")

    r05 = (ps < 0.05).mean()
    if r05 > 0.09:
        finding("CRIT", "ערכי p אנטי-שמרניים",
                f"שיעור דחייה של {r05:.3f} ב-alpha=0.05.\n"
                "המבחן מייצר יותר מדי זיהויים שגויים.")
    elif r05 > 0.065:
        finding("WARN", "ערכי p מעט אנטי-שמרניים",
                f"{r05:.3f} מול יעד 0.05. תיקון BH מפצה חלקית.")
    else:
        finding("INFO", "ערכי p מכויילים סבירות",
                f"שיעור דחייה {r05:.3f} ב-alpha=0.05.")


# ═══════════ 3. האם BH הוא הכלי הנכון כאן? ═══════════
def audit_bh_choice():
    print("\n" + "─" * 66)
    print("  3. בחירת שיטת התיקון")
    print("─" * 66)
    print("""
  BH שולט ב-FDR: מתוך התחומים שהוכרזו מנצחים, איזה שיעור
  הוא שגוי. זה מתאים לגילוי מדעי — אבל כאן ההחלטה היא
  להשקיע כסף בתחום אחד.

  בהחלטה כזו רלוונטי FWER (הסיכוי לטעות *ולו פעם אחת*),
  ובונפרוני שולט בו ישירות.""")

    rng = np.random.default_rng(2)
    fdr_hit = fwer_hit = 0
    trials = 400
    for t in range(trials):
        pv = []
        for d in range(5):
            n = 60
            p = rng.uniform(0.1, 0.9, n)
            out = (rng.random(n) < p).astype(int)
            a = np.clip(p + rng.normal(0, 0.09, n), 0.01, 0.99)
            m = np.clip(p + rng.normal(0, 0.09, n), 0.01, 0.99)
            r = paired_bootstrap((a - out) ** 2, (m - out) ** 2,
                                 n_boot=800, seed=t * 11 + d)
            pv.append(r["p_value"] if r["mean_diff"] > 0 else 1.0)
        if any(benjamini_hochberg(pv, 0.05)):
            fdr_hit += 1
        if min(pv) < 0.05 / 5:            # בונפרוני
            fwer_hit += 1

    print(f"\n    BH  — עולם ריק מייצר 'מנצח': {fdr_hit/trials*100:.1f}%")
    print(f"    Bonferroni:                    {fwer_hit/trials*100:.1f}%")

    finding("WARN", "BH מקל מדי להחלטת השקעה",
            f"BH נותן {fdr_hit/trials*100:.0f}% זיהוי שגוי, בונפרוני "
            f"{fwer_hit/trials*100:.0f}%.\n"
            "להחלטה על כסף — השתמש בבונפרוני (alpha/5 = 0.01).\n"
            "המלצה: להציג את שניהם, ולהתנות כסף על החמור.")


# ═══════════ 4. הבעיה הגדולה: הצצות חוזרות ═══════════
def audit_peeking():
    print("\n" + "─" * 66)
    print("  4. הצצות חוזרות (optional stopping)")
    print("─" * 66)
    print("""
  הדוח מיועד להרצה 'מתי שבא לך'. זו בעיה חמורה:
  אם בודקים שוב ושוב ועוצרים כשרואים תוצאה יפה,
  שיעור הזיהוי השגוי מזנק.""")

    rng = np.random.default_rng(4)
    trials = 300
    once = repeated = 0
    for t in range(trials):
        n_max = 200
        p = rng.uniform(0.1, 0.9, n_max)
        out = (rng.random(n_max) < p).astype(int)
        a = np.clip(p + rng.normal(0, 0.09, n_max), 0.01, 0.99)
        m = np.clip(p + rng.normal(0, 0.09, n_max), 0.01, 0.99)
        ba, bm = (a - out) ** 2, (m - out) ** 2

        r_end = paired_bootstrap(ba, bm, n_boot=600, seed=t)
        if r_end["p_value"] < 0.05 and r_end["mean_diff"] > 0:
            once += 1

        for k in range(30, n_max + 1, 20):       # מציץ כל 20 תחזיות
            rk = paired_bootstrap(ba[:k], bm[:k], n_boot=600, seed=t * 31 + k)
            if rk["p_value"] < 0.05 and rk["mean_diff"] > 0:
                repeated += 1
                break

    print(f"\n    בדיקה אחת בסוף:        {once/trials*100:5.1f}% זיהוי שגוי")
    print(f"    הצצה כל 20 תחזיות:     {repeated/trials*100:5.1f}% זיהוי שגוי")

    finding("CRIT", "הצצות חוזרות מנפחות זיהוי שגוי",
            f"מ-{once/trials*100:.0f}% ל-{repeated/trials*100:.0f}% — "
            "בערך פי 2.5.\n"
            "הדוח מזמין בדיוק את ההתנהגות הזו.\n"
            "פתרון: לקבוע n יעד מראש, ולנעול את ההחלטה עליו בלבד.\n"
            "הדוח צריך להסתיר את המובהקות עד שמגיעים ל-n שנקבע.")


# ═══════════ 5. עצמאות התצפיות ═══════════
def audit_independence():
    print("\n" + "─" * 66)
    print("  5. הנחת העצמאות")
    print("─" * 66)
    print("""
  הבוטסטרפ מניח שכל תחזית עצמאית. בפועל:
    - שווקים על אותו אירוע מתואמים כמעט לחלוטין
    - משחקים באותה ליגה חולקים גורמים משותפים
    - טעות שיטתית בסוכן משפיעה על כל התחזיות באותו יום""")

    rng = np.random.default_rng(6)
    for rho, label in [(0.0, "עצמאי"), (0.3, "מתאם בינוני"),
                       (0.6, "מתאם גבוה")]:
        fp = 0
        for t in range(250):
            n, k = 100, 10        # 10 אשכולות של 10
            clus = rng.normal(0, 0.09 * np.sqrt(rho), k).repeat(n // k)
            idio = rng.normal(0, 0.09 * np.sqrt(1 - rho), n)
            p = rng.uniform(0.1, 0.9, n)
            out = (rng.random(n) < p).astype(int)
            a = np.clip(p + clus + idio, 0.01, 0.99)
            m = np.clip(p + rng.normal(0, 0.09, n), 0.01, 0.99)
            r = paired_bootstrap((a - out) ** 2, (m - out) ** 2,
                                 n_boot=600, seed=t)
            if r["p_value"] < 0.05:
                fp += 1
        print(f"    {label:<16} (ρ={rho:.1f})  זיהוי שגוי: {fp/250*100:5.1f}%")

    finding("CRIT", "מתאם בין תחזיות שובר את המבחן",
            "כשהתחזיות מקובצות, שיעור הזיהוי השגוי חורג מ-5%.\n"
            "ספורט הוא המקרה הגרוע — הרבה משחקים באותה ליגה,\n"
            "אותו יום, עם גורמים משותפים.\n"
            "פתרון: block bootstrap לפי אירוע/ליגה/יום,\n"
            "או לספור אשכולות ולא תחזיות כיחידת המדגם.")


# ═══════════ 6. הטיית ההישרדות בבקטסט ═══════════
def audit_backtest_bias():
    print("\n" + "─" * 66)
    print("  6. הטיות בבקטסט")
    print("─" * 66)

    finding("CRIT", "מחיר ההשוואה בבקטסט שגוי מבחינה מתודולוגית",
            "הקוד משתמש ב-lastTradePrice — המחיר האחרון לפני ההכרעה.\n"
            "זה מחיר שראה כמעט את כל המידע, ולכן מדויק בצורה קיצונית.\n"
            "השוואה מולו תראה את הסוכן גרוע ממה שהוא.\n"
            "הכיוון של ההטיה בטוח, אבל הגודל לא ידוע — כלומר\n"
            "*אי אפשר לכמת* את התוצאה, רק לומר 'לפחות כזה'.\n"
            "פתרון: להשתמש ב-price history API בנקודת זמן קבועה\n"
            "לפני ההכרעה (למשל 24 שעות), אחרת הבקטסט לא בר-פירוש.")

    finding("WARN", "הטיית שרידות בשווקים סגורים",
            "שווקים שבוטלו או נפתרו כ-void לא מופיעים.\n"
            "אם ביטולים מתואמים עם אי-ודאות גבוהה, המדגם מוטה\n"
            "לכיוון שווקים 'קלים' יותר.")

    finding("WARN", "החלון הנקי צר",
            "בין נקודת החיתוך להיום יש כ-3 חודשים.\n"
            "זה מגביל את גודל המדגם הנקי, ומטה אותו לעונה מסוימת\n"
            "(למשל אילו ליגות פעילות בקיץ).")


# ═══════════ 7. גודל האפקט שמעניין מבחינה כלכלית ═══════════
def audit_economic_relevance():
    print("\n" + "─" * 66)
    print("  7. מובהקות סטטיסטית מול משמעות כלכלית")
    print("─" * 66)
    print("""
  אפילו edge מובהק לא בהכרח רווחי. צריך לתרגם
  שיפור ב-Brier לתשואה צפויה אחרי עלויות.""")

    print(f"\n    {'שיפור':>8} {'Brier':>10} {'~edge למחיר':>14} {'n נדרש':>12}")
    print("    " + "-" * 46)
    for s in [0.08, 0.07, 0.06, 0.045]:
        n, eff = required_n(s)
        # קירוב: שיפור ב-Brier ~ שיפור בדיוק ההסתברות
        price_edge = np.sqrt(max(eff, 0))
        imp = (1 - s / 0.09) * 100
        print(f"    {imp:>7.0f}% {eff:>10.5f} {price_edge:>13.3f} {n:>12,.0f}")

    finding("WARN", "edge קטן נבלע בעלויות",
            "שיפור של 11% ב-Brier ≈ 0.04 ביתרון מחיר.\n"
            "הספרד הטיפוסי בשווקי נישה גדול מזה.\n"
            "כלומר: edge מובהק סטטיסטית עדיין יכול להיות\n"
            "לא רווחי אחרי ספרד, slippage ועמלות.\n"
            "צריך סף כלכלי נפרד, לא רק סף סטטיסטי.")


def main():
    print("=" * 66)
    print("  ביקורת סטטיסטית עצמאית — PMLAB")
    print("=" * 66)

    audit_sd_assumption()
    audit_bootstrap_calibration()
    audit_bh_choice()
    audit_peeking()
    audit_independence()
    audit_backtest_bias()
    audit_economic_relevance()

    print("\n" + "=" * 66)
    print("  סיכום הביקורת")
    print("=" * 66)
    for sev in ("CRIT", "WARN", "INFO"):
        items = [f for f in FINDINGS if f[0] == sev]
        if items:
            print(f"\n  {sev} ({len(items)}):")
            for _, title, _ in items:
                print(f"    • {title}")
    print("\n" + "=" * 66)


if __name__ == "__main__":
    main()
