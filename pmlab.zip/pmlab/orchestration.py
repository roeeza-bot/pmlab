"""
מבחן אורקסטרציה.  python3 orchestration.py

זה המבחן שהיה חסר, ושהיה תופס את כל הכשלים ששתי הביקורות
האחרונות מצאו.

ההבדל מ-e2e.py: שם בדקנו שכל רכיב *יכול* לבצע את ההתנהגות.
כאן אנחנו מריצים את `cmd_forecast` האמיתי מול API מזויף,
ובודקים שהצינור **מפעיל** כל רכיב, בסדר הנכון.

הכלל: אף בדיקה כאן לא קוראת מחרוזות מקוד המקור.
כולן מריצות את הקוד ובוחנות מה קרה.
"""

import json
import os
import sys
import traceback
from datetime import datetime, timedelta, timezone
from unittest import mock

sys.path.insert(0, ".")

PASS, FAIL = [], []
DB = "orch_test.db"


def check(name, fn):
    try:
        fn()
        PASS.append(name)
        print(f"  ✓ {name}")
    except AssertionError as e:
        FAIL.append((name, str(e)))
        print(f"  ✗ {name}\n      {e}")
    except Exception as e:  # noqa: BLE001
        FAIL.append((name, f"{type(e).__name__}: {e}"))
        print(f"  ✗ {name}\n      {type(e).__name__}: {e}")
        traceback.print_exc(limit=4)


# הפיקסטורה חייבת להיות יחסית לשעון האמיתי — הצינור משתמש
# ב-datetime.now() ולא בזמן מוזרק. תאריך קבוע הופך את כל
# השווקים ל"עברו כבר" ומדלג עליהם בשקט.
NOW = datetime.now(timezone.utc)
EVENT_END = NOW + timedelta(hours=24)


def make_market(mid="mkt-1", outcomes=("Yes", "No"), prices=("0.62", "0.38"),
                end=None, question=None):
    return {
        "id": mid,
        "conditionId": f"cond-{mid}",
        "question": question or "Will Jon Jones beat Tom Aspinall at UFC 320?",
        "description": "Jon Jones faces Tom Aspinall in the main event.",
        "category": "mma",
        "slug": f"{mid}-slug",
        "endDate": (end or EVENT_END).isoformat(),
        "liquidityNum": 80_000,
        "volume24hr": 40_000,
        "acceptingOrders": True,
        "outcomes": json.dumps(list(outcomes)),
        "outcomePrices": json.dumps(list(prices)),
        "clobTokenIds": json.dumps([f"{mid}-yes", f"{mid}-no"]),
    }


class FakePM:
    """פולימרקט מזויף. מתעד כל קריאה כדי שנוכל לבדוק את הסדר."""
    name = "polymarket"

    def __init__(self, markets):
        self.markets = markets
        self.calls = []
        self.s = None
        self.refetch_price = "0.64"      # מחיר שונה, כדי לזהות refetch

    def active_markets(self, pages=4):
        self.calls.append(("active_markets", None))
        return list(self.markets)

    def market_by_condition(self, cid):
        self.calls.append(("market_by_condition", cid))
        for m in self.markets:
            if m["conditionId"] == cid:
                fresh = dict(m)
                fresh["outcomePrices"] = json.dumps(
                    [self.refetch_price,
                     f"{1 - float(self.refetch_price):.2f}"])
                return fresh
        return None


class FakeForecaster:
    """מעריך מזויף. מתעד בדיוק מה הועבר אליו."""

    def __init__(self, db, probability=0.7, abstain=False, reason=""):
        self.db = db
        self.probability = probability
        self.abstain = abstain
        self.reason = reason
        self.received = []

    def forecast(self, domain, question, end_date, description="",
                 as_of=None, base_rate=None, sides=None):
        self.received.append({
            "domain": domain, "question": question, "end_date": end_date,
            "description": description, "as_of": as_of,
            "base_rate": base_rate, "sides": sides,
        })
        if self.abstain:
            return {
                "abstain": True, "abstain_reason": self.reason or "thin",
                "coverage": 0.2, "n_records": 2, "n_unique_claims": 1,
                "n_independent_sources": 1, "coverage_yes_side": 0.5,
                "coverage_no_side": 0.0,
                "evidence_fingerprint": "FP_A",
                "yes_entity": getattr(sides, "yes_entity", ""),
                "no_entity": getattr(sides, "no_entity", ""),
                "entities": ["jon jones", "tom aspinall"],
                "as_of": (as_of or NOW).isoformat(),
            }
        return {
            "abstain": False, "probability": self.probability,
            "confidence": "medium", "rationale": "test",
            "coverage": 0.8, "n_records": 9, "n_unique_claims": 5,
            "n_independent_sources": 3, "coverage_yes_side": 0.6,
            "coverage_no_side": 0.5, "source_diversity": 0.4,
            "freshness_hours": 6.0, "evidence_fingerprint": "FP_A",
            "yes_entity": getattr(sides, "yes_entity", ""),
            "no_entity": getattr(sides, "no_entity", ""),
            "direction_verified": getattr(sides, "direction_verified", False),
            "entities": ["jon jones", "tom aspinall"],
            "as_of": (as_of or NOW).isoformat(),
            "model_version": "fake-model", "prompt_hash": "deadbeef",
            "knowledge_ids": [1, 2, 3],
        }


class FakeResearcher:
    """חוקר מזויף. מתעד אילו שאילתות הורצו ועבור איזה שוק."""
    instances = []

    def __init__(self, domain, db, **kw):
        self.domain = domain
        self.db = db
        self.queries_run = []
        FakeResearcher.instances.append(self)

    def run_cycle(self):
        self.queries_run.extend(getattr(self.domain, "research_queries", []))
        return len(self.queries_run)

    def research_event(self, sides, market=None):
        """אם הצינור קורא לזה — נדע שהמחקר ממוקד-אירוע פעיל."""
        from pmlab.core.event_sides import event_research_queries
        qs = event_research_queries(sides, self.domain.key
                                    if hasattr(self.domain, "key")
                                    else str(self.domain))
        self.queries_run.extend(qs)
        return len(qs)


def fresh_db():
    from pmlab.core.db import DB as _DB
    if os.path.exists(DB):
        os.remove(DB)
    return _DB(DB)


def run_pipeline(markets, forecaster, freeze_now=NOW):
    """
    מריץ את cmd_forecast האמיתי מול תלויות מזויפות.
    זו הנקודה: הקוד הייצורי, לא העתק שלו.
    """
    from pmlab import run as runmod

    db = fresh_db()
    pm = FakePM(markets)
    FakeResearcher.instances = []

    with mock.patch.object(runmod, "Polymarket", lambda *a, **k: pm), \
         mock.patch.object(runmod, "Forecaster",
                           lambda *a, **k: forecaster), \
         mock.patch.object(runmod, "Researcher", FakeResearcher):
        runmod.cmd_forecast(db)

    return db, pm


# ═══════════════════════════════════════════════════════════
def orch_happy_path():
    print("\n[ מסלול מלא — תחזית מוצלחת ]")

    def t_pipeline_completes():
        fc = FakeForecaster(None)
        db, pm = run_pipeline([make_market()], fc)
        rows = db.q("SELECT * FROM forecasts")
        assert len(rows) == 1, f"expected 1 forecast, got {len(rows)}"
        assert rows[0]["status"] == "open"
        assert rows[0]["agent_prob"] == 0.7
    check("צינור מלא מייצר תחזית אחת", t_pipeline_completes)

    def t_sides_reached_forecaster():
        fc = FakeForecaster(None)
        run_pipeline([make_market()], fc)
        assert fc.received, "forecaster was never called"
        sides = fc.received[0]["sides"]
        assert sides is not None, "sides not passed to forecaster"
        assert "Jones" in sides.yes_entity, f"YES={sides.yes_entity!r}"
        assert sides.no_entity, \
            f"NO side empty — resolver failed (NO={sides.no_entity!r})"
    check("שני הצדדים נפתרו והועברו למעריך", t_sides_reached_forecaster)

    def t_base_rate_reached_forecaster():
        fc = FakeForecaster(None)
        run_pipeline([make_market()], fc)
        br = fc.received[0]["base_rate"]
        assert br is not None, "base rate not passed"
        assert 0.0 <= br <= 1.0
    check("base rate חושב והועבר", t_base_rate_reached_forecaster)

    def t_metadata_persisted():
        fc = FakeForecaster(None)
        db, _ = run_pipeline([make_market()], fc)
        r = db.q("SELECT * FROM forecasts")[0]
        for f in ("as_of", "cluster_id", "coverage", "n_records",
                  "n_unique_claims", "n_independent_sources",
                  "coverage_yes_side", "coverage_no_side",
                  "evidence_fingerprint", "yes_entity", "no_entity",
                  "reference_class", "base_rate_value", "base_rate_source",
                  "forecast_horizon_hours", "model_version", "prompt_hash"):
            assert r[f] is not None, f"field '{f}' not persisted by pipeline"
    check("כל המטא-דאטה נשמרה בפועל", t_metadata_persisted)

    def t_price_refetched_after_lock():
        fc = FakeForecaster(None)
        db, pm = run_pipeline([make_market()], fc)
        r = db.q("SELECT * FROM forecasts")[0]
        assert ("market_by_condition", "cond-mkt-1") in pm.calls, \
            "no post-lock refetch happened"
        assert abs(r["market_prob"] - 0.64) < 1e-9, \
            f"stored price {r['market_prob']} is the stale cycle snapshot, " \
            f"not the refetched 0.64"
        assert r["market_fetched_at"], "fetch timestamp missing"
        assert r["market_snapshot_source"], "snapshot provenance missing"
    check("מחיר נשלף מחדש אחרי הנעילה ונשמר", t_price_refetched_after_lock)


# ═══════════════════════════════════════════════════════════
def orch_event_research():
    print("\n[ מחקר ממוקד-אירוע ]")

    def t_event_research_invoked():
        """
        [ביקורת 6, סעיף 3.1] הצינור חייב להריץ מחקר ספציפי
        לשני הצדדים — לא רק סריקת תחום רחבה.
        """
        fc = FakeForecaster(None)
        run_pipeline([make_market()], fc)
        all_q = [q for inst in FakeResearcher.instances
                 for q in inst.queries_run]
        assert all_q, "no research ran at all during the pipeline"
        event_q = [q for q in all_q if isinstance(q, dict)]
        assert event_q, \
            "CRITICAL: no event-specific research ran — pipeline only " \
            "performed broad domain sweeps"
        sides_tagged = {q.get("side") for q in event_q}
        assert {"yes", "no"} <= sides_tagged, \
            f"research did not cover both sides, got {sides_tagged}"
    check("מחקר ממוקד-אירוע מופעל ע\"י הצינור", t_event_research_invoked)

    def t_queries_name_both_entities():
        fc = FakeForecaster(None)
        run_pipeline([make_market()], fc)
        text = " ".join(
            q["query"] for inst in FakeResearcher.instances
            for q in inst.queries_run if isinstance(q, dict))
        assert "Jones" in text, "YES entity missing from research queries"
        assert "Aspinall" in text, "NO entity missing from research queries"
    check("השאילתות נוקבות בשני הצדדים", t_queries_name_both_entities)


# ═══════════════════════════════════════════════════════════
def orch_abstain_retry():
    print("\n[ הימנעות וניסיון חוזר ]")

    def t_abstention_persisted():
        fc = FakeForecaster(None, abstain=True, reason="one-sided evidence")
        db, _ = run_pipeline([make_market()], fc)
        rows = db.q("SELECT * FROM forecasts WHERE status='abstained'")
        assert len(rows) == 1, "abstention not recorded"
        assert rows[0]["abstain_reason"], "reason not stored"
        assert rows[0]["evidence_fingerprint"], \
            "fingerprint not stored — retry can never trigger"
    check("הימנעות נשמרת עם טביעת אצבע", t_abstention_persisted)

    def t_retry_on_new_evidence():
        """
        [ביקורת 6, סעיף 3.2] אחרי הימנעות, מידע חדש על האירוע
        חייב לפתוח את השוק מחדש — גם בתוך תקופת הצינון.
        """
        from pmlab import run as runmod

        db = fresh_db()
        mkt = make_market()
        pm = FakePM([mkt])

        fc1 = FakeForecaster(None, abstain=True, reason="thin")
        with mock.patch.object(runmod, "Polymarket", lambda *a, **k: pm), \
             mock.patch.object(runmod, "Forecaster", lambda *a, **k: fc1), \
             mock.patch.object(runmod, "Researcher", FakeResearcher):
            runmod.cmd_forecast(db)
        assert len(db.q("SELECT * FROM forecasts")) == 1

        # ראיות חדשות *במאגר* -> טביעת אצבע שונה -> הערכה מחדש.
        # חשוב: משנים את הידע האמיתי, לא את מה שהמעריך מחזיר —
        # אחרת לא בדקנו את השער אלא את הפיקסטורה.
        db.add_knowledge(
            "mma", "https://x.com/1", "injury",
            "Tom Aspinall pulled out of the bout with a shoulder injury",
            0.95,
            published_at=(datetime.now(timezone.utc)
                          - timedelta(hours=1)).isoformat(),
            entity_ids=["tom aspinall"])
        fc2 = FakeForecaster(None, probability=0.66)

        with mock.patch.object(runmod, "Polymarket", lambda *a, **k: pm), \
             mock.patch.object(runmod, "Forecaster", lambda *a, **k: fc2), \
             mock.patch.object(runmod, "Researcher", FakeResearcher):
            runmod.cmd_forecast(db)

        assert fc2.received, \
            "CRITICAL: market was blocked by the pre-check; new evidence " \
            "never reached the forecaster"
        rows = db.q("SELECT * FROM forecasts ORDER BY id")
        assert len(rows) == 2, \
            f"expected abstention + new forecast, got {len(rows)} rows"
        assert rows[-1]["status"] == "open"
    check("ראיות חדשות פותחות שוק שנמנענו ממנו", t_retry_on_new_evidence)

    def t_no_retry_without_change():
        from pmlab import run as runmod

        db = fresh_db()
        pm = FakePM([make_market()])
        fc = FakeForecaster(None, abstain=True, reason="thin")
        for _ in range(2):
            with mock.patch.object(runmod, "Polymarket", lambda *a, **k: pm), \
                 mock.patch.object(runmod, "Forecaster", lambda *a, **k: fc), \
                 mock.patch.object(runmod, "Researcher", FakeResearcher):
                runmod.cmd_forecast(db)
        rows = db.q("SELECT * FROM forecasts")
        assert len(rows) == 1, \
            f"unchanged evidence must not create a second row, got {len(rows)}"
    check("ראיות ללא שינוי לא מייצרות כפילות", t_no_retry_without_change)


# ═══════════════════════════════════════════════════════════
def orch_outcome_mapping():
    print("\n[ מיפוי YES/NO ]")

    def t_rejects_unlabelled_binary():
        """
        [ביקורת 6, סעיף 4.1] שוק בלי תוויות Yes/No מפורשות
        חייב להידחות — לא להניח שאינדקס 0 הוא YES.
        """
        fc = FakeForecaster(None)
        db, _ = run_pipeline(
            [make_market(outcomes=("Fighter A", "Fighter B"))], fc)
        rows = db.q("SELECT * FROM forecasts")
        assert len(rows) == 0, \
            "CRITICAL: market without explicit Yes/No labels was accepted; " \
            "outcomePrices[0] was assumed to be YES"
    check("שוק בלי תוויות Yes/No נדחה", t_rejects_unlabelled_binary)

    def t_yes_located_by_label():
        """אם הסדר הפוך — המחיר חייב לבוא מהתווית, לא מהמיקום."""
        from pmlab.platforms.polymarket import market_prob
        reversed_market = {
            "outcomes": json.dumps(["No", "Yes"]),
            "outcomePrices": json.dumps(["0.30", "0.70"]),
        }
        p = market_prob(reversed_market)
        assert p == 0.70, \
            f"CRITICAL: YES price read by position ({p}), not by label (0.70)"
    check("מחיר YES נקרא לפי תווית ולא לפי מיקום", t_yes_located_by_label)

    def t_resolution_by_label():
        from pmlab.backtest import actual_outcome
        m = {"outcomes": json.dumps(["No", "Yes"]),
             "outcomePrices": json.dumps(["0", "1"])}
        assert actual_outcome(m) == 1, \
            "CRITICAL: resolution read by position, not by label"
    check("הכרעה נקראת לפי תווית ולא לפי מיקום", t_resolution_by_label)


# ═══════════════════════════════════════════════════════════
def orch_horizon_and_time():
    print("\n[ אופק וזמן ]")

    def t_outside_window_skipped():
        fc = FakeForecaster(None)
        far = make_market("far", end=NOW + timedelta(hours=200))
        near = make_market("near", end=NOW + timedelta(hours=2))
        db, _ = run_pipeline([far, near], fc)
        assert len(db.q("SELECT * FROM forecasts")) == 0, \
            "markets outside the horizon window were forecast"
        assert not fc.received, "forecaster called for ineligible markets"
    check("שווקים מחוץ לחלון האופק מדולגים", t_outside_window_skipped)

    def t_horizon_from_event_start():
        """
        [ביקורת 6, סעיף 4.5] האופק חייב להימדד מזמן תחילת האירוע.
        אם קיים eventStartTime — הוא גובר על endDate.
        """
        fc = FakeForecaster(None)
        m = make_market("es")
        m["eventStartTime"] = (NOW + timedelta(hours=24)).isoformat()
        m["endDate"] = (NOW + timedelta(hours=200)).isoformat()  # דדליין טכני
        db, _ = run_pipeline([m], fc)
        assert len(db.q("SELECT * FROM forecasts")) == 1, \
            "CRITICAL: horizon measured from endDate, not from event start"
    check("אופק נמדד מזמן האירוע ולא מדדליין השוק", t_horizon_from_event_start)

    def t_stale_price_not_timestamped_fresh():
        """
        [ביקורת 6, סעיף 4.3] אם השליפה מחדש נכשלת — אסור לתייג
        מחיר ישן כאילו נשלף עכשיו.
        """
        from pmlab import run as runmod

        db = fresh_db()
        pm = FakePM([make_market()])
        pm.market_by_condition = lambda cid: None    # refetch נכשל
        fc = FakeForecaster(None)
        with mock.patch.object(runmod, "Polymarket", lambda *a, **k: pm), \
             mock.patch.object(runmod, "Forecaster", lambda *a, **k: fc), \
             mock.patch.object(runmod, "Researcher", FakeResearcher):
            runmod.cmd_forecast(db)
        r = db.q("SELECT * FROM forecasts")[0]
        if r["market_prob"] is not None:
            assert r["market_snapshot_source"] and \
                "fail" in r["market_snapshot_source"].lower(), \
                "fallback price not marked as a failed refetch"
            assert r["market_fetched_at"] != r["market_locked_at"] or True
            # החוק: או שלא שומרים מחיר, או ששומרים חותמת המקורית
            assert "refetch failed" in r["market_snapshot_source"], \
                "stale price timestamped as freshly fetched"
    check("מחיר ישן לא מתויג כטרי", t_stale_price_not_timestamped_fresh)


# ═══════════════════════════════════════════════════════════
def orch_freshness():
    print("\n[ טריות ראיות ]")

    def t_unknown_publication_date():
        """
        [ביקורת 6, סעיף 4.4] כתבה בלי תאריך פרסום שנאספה היום
        אינה 'טרייה בת 0 שעות'.
        """
        from pmlab.core.evidence import assess_evidence
        from pmlab.core.event_sides import parse_sides

        class R:
            def __init__(self):
                self.content = "Jon Jones note about Tom Aspinall"
                self.source_url = "http://a.com"
                self.entity_ids = []
                self.published_at = None
                self.collected_at = NOW

        q = assess_evidence([R()], parse_sides(
            "Will Jon Jones beat Tom Aspinall?"), now=NOW)
        assert getattr(q, "freshness_unknown", None) is True, \
            "CRITICAL: missing published_at treated as fresh; " \
            "no freshness_unknown flag"
    check("תאריך פרסום חסר מסומן כלא ידוע", t_unknown_publication_date)


def main():
    print("=" * 68)
    print("  ORCHESTRATION — הצינור הייצורי, לא הרכיבים")
    print("=" * 68)
    for fn in (orch_happy_path, orch_event_research, orch_abstain_retry,
               orch_outcome_mapping, orch_horizon_and_time, orch_freshness):
        fn()

    print("\n" + "=" * 68)
    print(f"  עברו: {len(PASS)}    נכשלו: {len(FAIL)}")
    if FAIL:
        print("\n  כשלים:")
        for n, e in FAIL:
            print(f"    ✗ {n}\n        {e}")
    print("=" * 68)
    if os.path.exists(DB):
        os.remove(DB)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
