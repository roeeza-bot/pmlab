"""
סימולטור מילוי וסלקציה שלילית.
  ./venv/bin/python -m pmlab.fillsim collect 180
  ./venv/bin/python -m pmlab.fillsim report

**למה זה מחליף את VPIN ולא מוסיף לו.**

הביקורת של Andersen ו-Bondarenko: VPIN מתואם בהכרח עם נפח
ותנודתיות, ואחרי בקרה עליהם אין לו כוח ניבוי נוסף. עקביות
זיהוי תקופות רעילות: 60% בלבד. וזה עם נתוני עסקאות מלאים —
הגרסה שלנו קירבה נפח משינוי בעומק הספר, כלומר חלשה יותר.

לכן: **לא מודדים "כמה רעיל". מודדים ישירות מה יקרה.**

השיטה — פקודות רפאים:
  1. בכל דגימה מציבים פקודה וירטואלית ב-bid+tick וב-ask−tick
  2. בדגימה הבאה בודקים אם השוק חצה אותה → מילוי
  3. אחרי המילוי עוקבים אחרי המיד ל-5/15/60 דקות
  4. אם המחיר זז **נגדנו** אחרי המילוי — זו סלקציה שלילית,
     נמדדת ישירות בסנטים, בלי מדד עקיף

    רווח = ספרד שנלכד  −  תנועה נגדנו  +  החזר

זה בדיוק מה שיקרה בפועל. אין הנחות על alpha, אין jump מומצא.

**המגבלה שנשארת:** אנחנו מתעלמים מ-queue position. בפועל יש
תור לפנינו, כך שחלק מהמילויים כאן לא היו קורים. לכן התוצאה
היא **תקרה עליונה** — אם היא שלילית, המציאות גרועה יותר.
"""

import logging
import os
import sqlite3
import sys
import time
from datetime import datetime, timedelta, timezone

import numpy as np

from .toxicity import MIN_LIQUIDITY, Poly, top_of_book

log = logging.getLogger(__name__)

DB = "fillsim.db"
TICK = 0.01
POLL_SECONDS = 45
HORIZONS_MIN = [5, 15, 60]
MAKER_REBATE = 0.0039        # 39bp, מ-mm_model
SIZE = 50.0                  # דולר לפקודה

SCHEMA = """
CREATE TABLE IF NOT EXISTS quotes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    token_id TEXT NOT NULL,
    question TEXT, category TEXT,
    side TEXT NOT NULL,          -- buy / sell
    quote_price REAL,            -- איפה הצבנו
    mid_at_quote REAL,
    spread REAL,
    filled INTEGER DEFAULT 0,
    fill_ts TEXT,
    expired INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_q ON quotes(token_id, filled, expired);

CREATE TABLE IF NOT EXISTS outcomes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    quote_id INTEGER NOT NULL,
    horizon_min INTEGER NOT NULL,
    mid_after REAL,
    adverse REAL,                -- תנועה נגדנו. חיובי = הפסד
    pnl REAL                     -- ספרד − adverse + החזר
);

CREATE TABLE IF NOT EXISTS mids (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    token_id TEXT NOT NULL,
    mid REAL, bid REAL, ask REAL
);
CREATE INDEX IF NOT EXISTS idx_m ON mids(token_id, ts);
"""

QUOTE_TTL_MIN = 30


def collect(minutes=180):
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    conn.commit()

    pm = Poly()
    deadline = datetime.now(timezone.utc) + timedelta(minutes=minutes)
    cycle = 0
    import json as _j

    while datetime.now(timezone.utc) < deadline:
        cycle += 1
        tracked = 0
        for m in pm.active_markets(pages=2):
            try:
                liq = float(m.get("liquidityNum") or m.get("liquidity") or 0)
            except (TypeError, ValueError):
                continue
            if liq < MIN_LIQUIDITY:
                continue
            toks = m.get("clobTokenIds")
            if isinstance(toks, str):
                try:
                    toks = _j.loads(toks)
                except _j.JSONDecodeError:
                    continue
            if not isinstance(toks, list) or not toks:
                continue

            tid = str(toks[0])
            tob = top_of_book(pm.book(tid))
            if not tob:
                continue

            now = datetime.now(timezone.utc).isoformat()
            conn.execute(
                "INSERT INTO mids (ts, token_id, mid, bid, ask) "
                "VALUES (?,?,?,?,?)",
                (now, tid, tob["mid"], tob["bid"], tob["ask"]))

            check_fills(conn, tid, tob, now)

            # פקודות רפאים חדשות — רק אם אין כבר פתוחות
            open_q = conn.execute(
                "SELECT COUNT(*) c FROM quotes WHERE token_id=? "
                "AND filled=0 AND expired=0", (tid,)).fetchone()["c"]
            if open_q == 0 and tob["spread"] >= 2 * TICK:
                q = (m.get("question") or "")[:120]
                cat = m.get("category") or "?"
                for side, price in (("buy", round(tob["bid"] + TICK, 3)),
                                    ("sell", round(tob["ask"] - TICK, 3))):
                    conn.execute(
                        """INSERT INTO quotes (ts, token_id, question, category,
                           side, quote_price, mid_at_quote, spread)
                           VALUES (?,?,?,?,?,?,?,?)""",
                        (now, tid, q, cat, side, price,
                         tob["mid"], tob["spread"]))
            tracked += 1
            time.sleep(0.15)

        conn.commit()
        resolve_outcomes(conn)
        expire_old(conn)
        log.info("cycle %d: tracked %d", cycle, tracked)
        time.sleep(POLL_SECONDS)
    conn.close()


def check_fills(conn, tid, tob, now):
    """
    פקודת קנייה ב-p מתמלאת רק אם הבסט-אסק ירד **מתחת** ל-p —
    כלומר מישהו באמת חצה לתוכנו. שמרני בכוונה.
    """
    for q in conn.execute(
            "SELECT * FROM quotes WHERE token_id=? AND filled=0 AND expired=0",
            (tid,)).fetchall():
        hit = (q["side"] == "buy" and tob["ask"] < q["quote_price"]) or \
              (q["side"] == "sell" and tob["bid"] > q["quote_price"])
        if hit:
            conn.execute("UPDATE quotes SET filled=1, fill_ts=? WHERE id=?",
                         (now, q["id"]))


def expire_old(conn):
    cutoff = (datetime.now(timezone.utc)
              - timedelta(minutes=QUOTE_TTL_MIN)).isoformat()
    conn.execute("UPDATE quotes SET expired=1 WHERE filled=0 AND expired=0 "
                 "AND ts < ?", (cutoff,))
    conn.commit()


def resolve_outcomes(conn):
    """אחרי מילוי — לאן זז המחיר? זו הסלקציה השלילית, נמדדת ישירות."""
    now = datetime.now(timezone.utc)
    for q in conn.execute(
            "SELECT * FROM quotes WHERE filled=1 AND fill_ts IS NOT NULL"
    ).fetchall():
        t0 = datetime.fromisoformat(q["fill_ts"])
        age = (now - t0).total_seconds() / 60
        done = {r["horizon_min"] for r in conn.execute(
            "SELECT horizon_min FROM outcomes WHERE quote_id=?", (q["id"],))}
        for h in HORIZONS_MIN:
            if h in done or age < h:
                continue
            row = conn.execute(
                "SELECT mid FROM mids WHERE token_id=? ORDER BY ts DESC "
                "LIMIT 1", (q["token_id"],)).fetchone()
            if not row:
                continue
            mid_after = row["mid"]
            # קנינו -> מפסידים אם המחיר ירד. מכרנו -> אם עלה.
            move = mid_after - q["mid_at_quote"]
            adverse = -move if q["side"] == "buy" else move
            captured = q["spread"] / 2 - TICK      # מה שנלכד בפועל
            pnl = captured - adverse + MAKER_REBATE
            conn.execute(
                "INSERT INTO outcomes (quote_id, horizon_min, mid_after, "
                "adverse, pnl) VALUES (?,?,?,?,?)",
                (q["id"], h, mid_after, adverse, pnl))
    conn.commit()


# ─────────────────────────────────────────────────────────────

def report():
    if not os.path.exists(DB):
        print("\n  אין נתונים. הרץ: fillsim collect\n")
        return
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    W = 70
    print("=" * W)
    print("  סימולטור מילוי — מדידה ישירה, בלי VPIN")
    print("=" * W)

    total = conn.execute("SELECT COUNT(*) c FROM quotes").fetchone()["c"]
    filled = conn.execute(
        "SELECT COUNT(*) c FROM quotes WHERE filled=1").fetchone()["c"]
    expired = conn.execute(
        "SELECT COUNT(*) c FROM quotes WHERE expired=1").fetchone()["c"]
    ntok = conn.execute(
        "SELECT COUNT(DISTINCT token_id) c FROM quotes").fetchone()["c"]

    print(f"\n[ מילוי ]")
    print(f"  פקודות שהוצבו : {total}   שווקים: {ntok}")
    print(f"  התמלאו        : {filled}"
          f"  ({filled/max(total,1)*100:.1f}%)")
    print(f"  פגו           : {expired}")

    if filled == 0:
        print("\n  ** אף פקודה לא התמלאה. **")
        print("  זו תשובה: השווקים האלה לא זזים מספיק כדי")
        print("  שעשיית שוק תייצר עסקאות. רווח לעסקה לא רלוונטי")
        print("  כשאין עסקאות.")
        print("=" * W)
        return

    print(f"\n[ סלקציה שלילית — כמה זז המחיר נגדנו אחרי המילוי ]")
    print(f"  {'אופק':>6} {'n':>5} {'adverse':>10} {'ספרד':>9} "
          f"{'רווח':>10} {'חיובי':>8}")
    print("  " + "-" * 52)
    verdicts = {}
    for h in HORIZONS_MIN:
        rows = conn.execute(
            """SELECT o.adverse, o.pnl, q.spread FROM outcomes o
               JOIN quotes q ON q.id=o.quote_id WHERE o.horizon_min=?""",
            (h,)).fetchall()
        if not rows:
            continue
        adv = np.array([r["adverse"] for r in rows])
        pnl = np.array([r["pnl"] for r in rows])
        sp = np.array([r["spread"] for r in rows])
        verdicts[h] = pnl
        print(f"  {h:>6} {len(rows):>5} {adv.mean()*100:>9.3f}% "
              f"{sp.mean()*100:>8.2f}% {pnl.mean()*100:>9.3f}% "
              f"{(pnl>0).mean()*100:>7.0f}%")

    if not verdicts:
        print("\n  אין עדיין מעקבים. צריך זמן ריצה ארוך יותר.")
        print("=" * W)
        return

    h = max(verdicts)
    pnl = verdicts[h]
    se = pnl.std(ddof=1) / np.sqrt(len(pnl)) if len(pnl) > 1 else 0
    lo = pnl.mean() - 1.96 * se

    print(f"\n[ פסק דין — אופק {h} דקות ]")
    print(f"  n = {len(pnl)}")
    print(f"  רווח ממוצע לעסקה : {pnl.mean()*100:+.3f}%  "
          f"({pnl.mean()*SIZE:+.3f}$ על {SIZE:.0f}$)")
    print(f"  גבול תחתון 95%   : {lo*100:+.3f}%")
    print()
    if len(pnl) < 30:
        print(f"  רק {len(pnl)} מילויים. מתחת לסף למסקנה.")
    elif lo > 0:
        daily = pnl.mean() * SIZE * filled
        print("  ★ רווחי, וגבול הסמך לא חוצה אפס.")
        print(f"    בקצב שנצפה: {daily:+.2f}$ לחלון הדגימה.")
    elif pnl.mean() > 0:
        print("  רווח ממוצע חיובי אך לא מובחן מרעש.")
    else:
        print("  מפסיד. הסלקציה השלילית גדולה מהספרד ומההחזר.")

    print(f"\n[ לפי קטגוריה ]")
    rows = conn.execute(
        """SELECT q.category cat, COUNT(*) n, AVG(o.pnl) p, AVG(o.adverse) a
           FROM outcomes o JOIN quotes q ON q.id=o.quote_id
           WHERE o.horizon_min=? GROUP BY q.category
           HAVING n>=5 ORDER BY p DESC""", (h,)).fetchall()
    if rows:
        print(f"  {'קטגוריה':<20} {'n':>5} {'adverse':>10} {'רווח':>10}")
        print("  " + "-" * 48)
        for r in rows[:10]:
            print(f"  {(r['cat'] or '?')[:20]:<20} {r['n']:>5} "
                  f"{r['a']*100:>9.3f}% {r['p']*100:>9.3f}%")

    print(f"\n[ מגבלה שנשארת ]")
    print("  מתעלמים מ-queue position: בפועל יש תור לפנינו, כך")
    print("  שחלק מהמילויים כאן לא היו קורים. התוצאה היא **תקרה**.")
    print("  אם היא שלילית — המציאות גרועה יותר.")
    print("=" * W)


def main():
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(message)s",
                        datefmt="%H:%M:%S")
    cmd = sys.argv[1] if len(sys.argv) > 1 else "report"
    if cmd == "collect":
        collect(int(sys.argv[2]) if len(sys.argv) > 2 else 180)
    else:
        report()


if __name__ == "__main__":
    main()
