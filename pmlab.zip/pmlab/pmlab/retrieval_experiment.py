"""
ניסוי אחזור מבודד.  ./venv/bin/python -m pmlab.retrieval_experiment

השאלה: האם אחזור מידע משפר את התחזית — או רק מדליף את התשובה?

מריץ שלוש זרועות על **אותם שווקים בדיוק**:

  A. ללא אחזור          — הבסיס שכבר מדדנו
  B. אחזור מסונן לתאריך — רק מקורות שפורסמו לפני as_of
  C. אחזור לא מסונן     — בקרת דליפה

הפרשנות:
  C >> B   →  דליפה. האחזור "עובד" כי הוא קורא את התשובה.
  B  > A   →  אחזור אמיתי עוזר. יש כיוון.
  B ≈ A    →  אחזור לא מוסיף כלום על השאלות האלה.
  B  < A   →  אחזור מזיק — עקבי עם הממצא ש"היכן שהארכיון
              נשא רק ספקולציה, אחזור הזיק".

as_of נקבע ל-**7 ימים לפני ההכרעה**. לא יום, כדי שיהיה
מרווח ביטחון מול אי-דיוקים בחותמות התאריך של המקורות.
"""

import logging
import os
import time
from datetime import datetime, timedelta, timezone

import numpy as np
import requests

from .backtest import (
    BACKTEST_SYSTEM, MODEL_CUTOFF, actual_outcome, fetch_resolved,
    historical_price, parse_dt, resolution_window, token_ids,
)
from .core.db import DB, utcnow
from .core.domains import DOMAINS
from .core.parsing import extract_probability, parse_json_object
from .core.stats import brier, cluster_robust_test, skill_score
from .platforms.polymarket import Polymarket, is_binary, match_domain

log = logging.getLogger(__name__)

LEAD_DAYS = 7          # as_of = ההכרעה פחות שבעה ימים
N_MARKETS = 20         # קטן בכוונה — זה ניסוי, לא מדגם
MAX_SNIPPETS = 6


# ─────────────────────────────────────────────────────────────
# אחזור
# ─────────────────────────────────────────────────────────────

class Tavily:
    """
    חיפוש עם סינון תאריכים **נאכף בקוד**.

    לא משתמשים בחיפוש המובנה של המודל: אם המודל יכול לחפש
    מיוזמתו, אי אפשר לאכוף חלון זמן, וכל הניסוי מזוהם.
    """

    URL = "https://api.tavily.com/search"

    def __init__(self, api_key=None):
        self.key = api_key or os.environ.get("TAVILY_API_KEY", "")
        self.s = requests.Session()

    def search(self, query: str, before: datetime | None):
        if not self.key:
            return []
        payload = {
            "api_key": self.key,
            "query": query,
            "max_results": MAX_SNIPPETS,
            "search_depth": "basic",
        }
        if before is not None:
            # חלון של 60 יום שמסתיים ב-as_of
            payload["start_date"] = (before - timedelta(days=60)).strftime("%Y-%m-%d")
            payload["end_date"] = before.strftime("%Y-%m-%d")
        try:
            r = self.s.post(self.URL, json=payload, timeout=30)
            r.raise_for_status()
            results = (r.json() or {}).get("results", [])
        except Exception as e:  # noqa: BLE001
            log.error("tavily failed: %s", e)
            return []

        out = []
        for it in results:
            pub = it.get("published_date") or it.get("published_time")
            # שכבת אכיפה שנייה: גם אם ה-API החזיר משהו מאוחר,
            # אנחנו זורקים אותו. אמון באפס.
            if before is not None and pub:
                d = parse_dt(pub)
                if d and d > before:
                    continue
            out.append({
                "title": it.get("title", "")[:150],
                "content": (it.get("content") or "")[:600],
                "url": it.get("url", ""),
                "published": pub or "unknown",
            })
        return out[:MAX_SNIPPETS]


def evidence_block(snips) -> str:
    if not snips:
        return "(no sources retrieved)"
    return "\n\n".join(
        f"[{s['published']}] {s['title']}\n{s['content']}" for s in snips)


# ─────────────────────────────────────────────────────────────
# חיזוי
# ─────────────────────────────────────────────────────────────

class Arm:
    def __init__(self, api_key=None):
        from anthropic import Anthropic
        self.client = Anthropic(api_key=api_key
                                or os.environ["ANTHROPIC_API_KEY"])

    def forecast(self, question, end_date, description="", evidence=None):
        ev = ""
        if evidence is not None:
            ev = f"""
RETRIEVED SOURCES (all published before your decision date):
{evidence_block(evidence)}

Use these sources. If they do not bear on the question, say so and
stay at the base rate rather than reading meaning into them.
"""
        prompt = f"""QUESTION:
{question}

{f"Details: {description}" if description else ""}
Resolution date: {end_date}
{ev}
Estimate the probability this resolves YES. JSON only."""
        try:
            resp = self.client.messages.create(
                model="claude-sonnet-4-6", max_tokens=1100, temperature=0.0,
                system=BACKTEST_SYSTEM,
                messages=[{"role": "user", "content": prompt}],
            )
        except Exception as e:  # noqa: BLE001
            log.error("forecast failed: %s", e)
            return None
        text = "".join(b.text for b in resp.content if b.type == "text")
        data = parse_json_object(text)
        p = extract_probability(data)
        if p is None:
            return None
        lo, hi = data.get("range_low"), data.get("range_high")
        try:
            lo, hi = float(lo), float(hi)
            if hi > lo:
                p = (lo + hi) / 2
        except (TypeError, ValueError):
            pass
        return max(0.10, min(0.90, p))


# ─────────────────────────────────────────────────────────────

def run():
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(message)s",
                        datefmt="%H:%M:%S")

    if not os.environ.get("TAVILY_API_KEY"):
        print("\n  חסר TAVILY_API_KEY. הרשמה חינם: tavily.com\n")
        return

    pm = Polymarket()
    tv = Tavily()
    arm = Arm()

    markets = fetch_resolved(pm, pages=2)
    log.info("fetched %d resolved markets", len(markets))

    picked = []
    for m in markets:
        if resolution_window(m) != "clean" or not is_binary(m):
            continue
        if not match_domain(m, DOMAINS):
            continue
        end = parse_dt(m.get("endDate"))
        out = actual_outcome(m)
        toks = token_ids(m)
        if end is None or out is None or not toks:
            continue
        as_of = end - timedelta(days=LEAD_DAYS)
        if as_of <= MODEL_CUTOFF:      # חייב להיות אחרי החיתוך
            continue
        mp = historical_price(pm.s, toks[0], m.get("endDate"),
                              lead_hours=LEAD_DAYS * 24)
        if mp is None:
            continue
        picked.append((m, as_of, out, mp))
        if len(picked) >= N_MARKETS:
            break

    log.info("selected %d markets for the experiment", len(picked))
    if len(picked) < 8:
        print("\n  לא נמצאו מספיק שווקים מתאימים.\n")
        return

    rows = []
    for i, (m, as_of, out, mp) in enumerate(picked, 1):
        q = (m.get("question") or "").strip()
        desc = (m.get("description") or "")[:600]
        log.info("[%d/%d] %s", i, len(picked), q[:55])

        pa = arm.forecast(q, str(m.get("endDate")), desc, evidence=None)

        snips_b = tv.search(q, before=as_of)
        pb = arm.forecast(q, str(m.get("endDate")), desc, evidence=snips_b)

        snips_c = tv.search(q, before=None)
        pc = arm.forecast(q, str(m.get("endDate")), desc, evidence=snips_c)

        if None in (pa, pb, pc):
            continue
        rows.append({
            "q": q, "out": out, "mkt": mp,
            "A": pa, "B": pb, "C": pc,
            "nb": len(snips_b), "nc": len(snips_c),
            "day": str(m.get("endDate"))[:10],
        })
        log.info("    A=%.2f  B=%.2f  C=%.2f  mkt=%.2f  out=%d  "
                 "(srcB=%d srcC=%d)", pa, pb, pc, mp, out,
                 len(snips_b), len(snips_c))
        time.sleep(0.5)

    report(rows)


def report(rows):
    W = 68
    print("\n" + "=" * W)
    print("  ניסוי אחזור — שלוש זרועות על אותם שווקים")
    print("=" * W)
    if len(rows) < 8:
        print(f"\n  רק {len(rows)} שווקים הושלמו. מעט מדי.")
        print("=" * W)
        return

    y = np.array([r["out"] for r in rows], float)
    mk = np.array([r["mkt"] for r in rows], float)
    cid = np.array([r["day"] for r in rows])
    bm = ((mk - y) ** 2).mean()

    print(f"\n  n = {len(rows)}   אשכולות = {len(set(cid))}")
    print(f"  מקורות ממוצע: מסונן {np.mean([r['nb'] for r in rows]):.1f}   "
          f"לא מסונן {np.mean([r['nc'] for r in rows]):.1f}")
    print(f"\n  שוק: Brier {bm:.4f}\n")

    res = {}
    for arm_key, label in (("A", "ללא אחזור"),
                           ("B", "אחזור מסונן לתאריך"),
                           ("C", "אחזור לא מסונן (בקרת דליפה)")):
        p = np.array([r[arm_key] for r in rows], float)
        b = ((p - y) ** 2).mean()
        ss = skill_score(b, bm)
        t = cluster_robust_test((p - y) ** 2, (mk - y) ** 2, cid)
        res[arm_key] = (b, ss)
        print(f"  {label:<32} Brier {b:.4f}   skill {ss:+.3f}   "
              f"p={t['p_value']:.3f}")

    print("\n[ פרשנות ]")
    bA, sA = res["A"]
    bB, sB = res["B"]
    bC, sC = res["C"]

    leak = sC - sB
    print(f"  פער דליפה (C − B): {leak:+.3f}")
    if leak > 0.15:
        print("  ⚠ אחזור לא מסונן טוב בהרבה — זו דליפה, לא כישרון.")
        print("    כל תוצאה מזרוע C חסרת ערך.")
    else:
        print("  ✓ אין פער דליפה גדול. הסינון עובד, או שאין מה לדלוף.")

    print()
    gain = sB - sA
    print(f"  תרומת האחזור (B − A): {gain:+.3f}")
    if gain > 0.10:
        print("  ★ אחזור מסונן משפר משמעותית. זה הכיוון.")
    elif gain > 0.03:
        print("  שיפור קטן. שווה לבדוק על מדגם גדול יותר.")
    elif gain > -0.03:
        print("  אחזור לא מוסיף כלום על השאלות האלה.")
    else:
        print("  אחזור **מזיק**. עקבי עם הממצא שהיכן שהמקורות")
        print("  נושאים רק ספקולציה, אחזור פוגע.")

    print("\n[ שווקים בודדים ]")
    for r in rows[:12]:
        print(f"  out={r['out']}  A={r['A']:.2f} B={r['B']:.2f} "
              f"C={r['C']:.2f} mkt={r['mkt']:.2f} | {r['q'][:38]}")
    print("=" * W)


if __name__ == "__main__":
    run()
