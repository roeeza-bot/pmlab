"""
ניתוח עוצמה. python -m pmlab.power

הרץ את זה *לפני* שאתה מתחיל. הוא עונה על השאלה
שכמעט אף אחד לא שואל: כמה תחזיות בכלל צריך
כדי שהתשובה תהיה משמעותית?

המתמטיקה:
  לחוזה בינארי, Brier של מנבא עם רעש σ סביב ההסתברות האמיתית:
      E[Brier] = E[p(1-p)] + σ²
  האיבר הראשון זהה לשוק ולסוכן (אותם אירועים).
  לכן ההפרש כולו הוא:  σ²_שוק − σ²_סוכן

  וזה מספר קטן מאוד, בעוד שהשונות של ההפרש לכל תחזית
  היא גדולה. משם נובע גודל המדגם.
"""

import numpy as np

MARKET_NOISE = 0.09     # רעש השוק. שוקי חיזוי מכויילים היטב.
SD_PAIRED_DIFF = 0.10   # SD אמפירי של ההפרש המזווג
Z_ALPHA = 2.576         # דו-צדדי ב-alpha=0.01 (BH על 5 מבחנים)
Z_POWER = 0.842         # עוצמה 80%


def required_n(agent_noise: float,
               market_noise: float = MARKET_NOISE,
               sd_diff: float = SD_PAIRED_DIFF,
               z_a: float = Z_ALPHA, z_b: float = Z_POWER) -> tuple[float, float]:
    effect = market_noise ** 2 - agent_noise ** 2
    if effect <= 0:
        return float("inf"), effect
    n = ((z_a + z_b) * sd_diff / effect) ** 2
    return n, effect


def days_to_complete(n: float, forecasts_per_day: float,
                     mean_resolution_days: float) -> float:
    """כמה ימים עד שמגיעים ל-n הכרעות."""
    if forecasts_per_day <= 0:
        return float("inf")
    return n / forecasts_per_day + mean_resolution_days


def main():
    print("=" * 68)
    print("  ניתוח עוצמה — כמה תחזיות צריך?")
    print("=" * 68)
    print(f"\n  רעש השוק: {MARKET_NOISE}   SD הפרש מזווג: {SD_PAIRED_DIFF}")
    print(f"  alpha אחרי BH על 5 תחומים: 0.01   עוצמה: 80%\n")

    print(f"  {'שיפור הסוכן':>14} {'אפקט Brier':>13} {'n נדרש':>14}")
    print("  " + "-" * 46)
    for s in [0.085, 0.08, 0.07, 0.06, 0.045, 0.03]:
        n, eff = required_n(s)
        imp = (1 - s / MARKET_NOISE) * 100
        print(f"  {imp:>13.0f}% {eff:>13.5f} {n:>14,.0f}")

    print("\n[ כמה זמן זה לוקח ]")
    print("  בהנחת שיפור של 33% (סוכן טוב מאוד), n≈5,800:\n")
    n33, _ = required_n(0.06)
    scenarios = [
        ("ספורט — זנב ארוך", 15, 3),
        ("קריפטו", 5, 20),
        ("מאקרו", 2, 45),
        ("גיאופוליטיקה", 2, 60),
        ("טכנולוגיה", 2, 50),
    ]
    for label, per_day, res_days in scenarios:
        d = days_to_complete(n33, per_day, res_days)
        yrs = d / 365
        note = "  ← ריאלי" if yrs < 1.5 else ""
        print(f"  {label:<22} {per_day:>3}/יום  →  {d:>6,.0f} ימים "
              f"({yrs:.1f} שנים){note}")

    print("\n[ המסקנה ]")
    print("  שוקי חיזוי מכויילים היטב, ולכן ההפרש שאנחנו מחפשים זעיר")
    print("  ביחס לשונות. זה אומר ששלושה מהתחומים לא ניתנים להכרעה")
    print("  בזמן סביר — פשוט אין מספיק אירועים בעולם.")
    print()
    print("  ספורט הוא היחיד שנפתר מספיק מהר כדי להשלים את הניסוי.")
    print("  זה לא אומר שיש שם edge — זה אומר שאפשר *לבדוק*.")
    print("=" * 68)


if __name__ == "__main__":
    main()
