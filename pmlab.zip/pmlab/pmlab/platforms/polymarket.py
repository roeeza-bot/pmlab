"""מתאם פולימרקט — שליפת שווקים והתאמה לתחומים."""

import json
import logging
import time
from datetime import datetime, timezone

import requests

log = logging.getLogger(__name__)
GAMMA = "https://gamma-api.polymarket.com"


class Polymarket:
    name = "polymarket"

    def __init__(self):
        self.s = requests.Session()
        self.s.headers.update({"User-Agent": "pmlab/1.0"})

    def _get(self, path, params=None, retries=3):
        for i in range(retries):
            try:
                r = self.s.get(f"{GAMMA}{path}", params=params, timeout=20)
                if r.status_code == 429:
                    time.sleep(2 ** i)
                    continue
                r.raise_for_status()
                return r.json()
            except Exception as e:  # noqa: BLE001
                if i == retries - 1:
                    log.error("GET %s failed: %s", path, e)
                time.sleep(1.5 * (i + 1))
        return None

    def active_markets(self, pages=4) -> list[dict]:
        out = []
        for i in range(pages):
            batch = self._get("/markets", {
                "active": "true", "closed": "false", "archived": "false",
                "limit": 250, "offset": i * 250,
                "order": "volume24hr", "ascending": "false",
            })
            if not batch:
                break
            out.extend(batch)
        return out

    def market_by_condition(self, condition_id: str):
        d = self._get("/markets", {"condition_ids": condition_id})
        return d[0] if isinstance(d, list) and d else None


# ---------- התאמת שוק לתחום ----------

def event_time(market: dict):
    """
    זמן האירוע האמיתי.

    endDate בפולימרקט הוא מתי השוק **נסגר** — לא מתי האירוע
    מתחיל. אם קיים שדה מפורש לזמן האירוע, הוא גובר.
    """
    for key in ("eventStartTime", "gameStartTime", "startDate"):
        v = market.get(key)
        if v:
            d = days_to_end(v)
            if d is not None:
                return d, key
    d = days_to_end(market.get("endDate"))
    return (d, "endDate") if d is not None else (None, None)


def days_to_end(end_date) -> float | None:
    """
    תאריכים ללא אזור זמן היו מפילים את זה בחריגה.
    נתפס ב-QA. עכשיו מנורמל ל-UTC.
    """
    if not end_date:
        return None
    try:
        dt = datetime.fromisoformat(str(end_date).replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None
    if dt.tzinfo is None:                      # naive -> assume UTC
        dt = dt.replace(tzinfo=timezone.utc)
    return (dt - datetime.now(timezone.utc)).total_seconds() / 86400


def match_domain(market: dict, domains: dict) -> str | None:
    """מחזיר את מפתח התחום, או None אם השוק לא מתאים לאף אחד."""
    text = " ".join(str(market.get(k) or "") for k in
                    ("question", "description", "category", "slug")).lower()

    d = days_to_end(market.get("endDate"))
    if d is None:
        return None

    best = None
    for key, dom in domains.items():
        if any(x in text for x in dom.exclude):
            continue
        if not any(x in text for x in dom.include):
            continue
        if not (dom.min_days <= d <= dom.max_days):
            continue
        # מעדיפים התאמה ספציפית יותר (יותר מילות מפתח שנפגעו)
        score = sum(1 for x in dom.include if x in text)
        if best is None or score > best[1]:
            best = (key, score)
    return best[0] if best else None


def _outcomes(market: dict) -> list[str]:
    oc = market.get("outcomes")
    if isinstance(oc, str):
        try:
            oc = json.loads(oc)
        except json.JSONDecodeError:
            return []
    return [str(x) for x in oc] if isinstance(oc, list) else []


def yes_index(market: dict) -> int | None:
    """
    מאתר את אינדקס ה-YES **לפי התווית**.

    למה זה קריטי: הקוד הקודם הניח ש-outcomePrices[0] הוא YES.
    אם הסדר הפוך אי-פעם, או שהתוויות הן שמות קבוצות, כל
    ההסתברות וכל ההכרעה מתהפכות — **בשקט**. תת-קבוצה הפוכה
    בנתונים תיראה בדיוק כמו רעש, ולא תתגלה לעולם.
    """
    oc = _outcomes(market)
    if len(oc) != 2:
        return None
    lowered = [o.strip().lower() for o in oc]
    if "yes" in lowered and "no" in lowered:
        return lowered.index("yes")
    return None


def is_binary(market: dict) -> bool:
    """
    רק שווקים עם תוויות Yes/No **מפורשות**.

    שוק כמו ["Fighter A", "Fighter B"] נדחה בכוונה: אין בו
    מיפוי חד-משמעי בין השאלה לבין אינדקס המחיר.
    """
    return yes_index(market) is not None


def market_prob(market: dict) -> float | None:
    """
    מחיר השוק ל-YES, נקרא **לפי התווית** ולא לפי מיקום.
    נשלף רק אחרי שהערכת הסוכן ננעלה.
    """
    idx = yes_index(market)
    if idx is None:
        return None
    pr = market.get("outcomePrices")
    if isinstance(pr, str):
        try:
            pr = json.loads(pr)
        except json.JSONDecodeError:
            return None
    if not isinstance(pr, list) or len(pr) <= idx:
        return None
    try:
        p = float(pr[idx])
    except (TypeError, ValueError):
        return None
    return p if 0.0 <= p <= 1.0 else None


def liquid_enough(market: dict, min_liq=5000.0) -> bool:
    try:
        return float(market.get("liquidityNum") or market.get("liquidity") or 0) >= min_liq
    except (TypeError, ValueError):
        return False
