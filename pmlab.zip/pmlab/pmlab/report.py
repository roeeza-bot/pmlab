"""
דוח. python -m pmlab.report

תוקן אחרי הביקורת השלישית:
  [3.7]  domain_verdict נקרא עם חתימה שגויה → קריסה על נתונים אמיתיים
  [3.7]  MIN_N_PER_DOMAIN / TARGET_N_PER_DOMAIN לא היו מוגדרים
  [3.7]  bonferroni יובא אך לא הופעל
  [3.11] cluster_id לא הועבר לשכבת ההסקה
  [3.14] הסקה כלכלית התעלמה מאשכולות
"""

import numpy as np

from .core.db import DB
from .core.domains import DOMAINS
from .core.stats import (
    benjamini_hochberg, bonferroni, calibration_bins, cluster_robust_test,
    domain_verdict, is_economically_viable, observed_power_need,
    simulated_pnl, skill_score, target_clusters,
)

W = 72


def cluster_of(row) -> str:
    """[3.11] מזהה אשכול. חייב לשרוד עד שכבת ההסקה."""
    keys = row.keys()
    if "cluster_id" in keys and row["cluster_id"]:
        return row["cluster_id"]
    day = (row["end_date"] or row["resolved_at"] or "")[:10]
    return f"{row['domain']}|{day}"


def cluster_level_pnl(rows, spread=0.03):
    """
    [3.14] P&L מצטבר *ברמת האשכול*, לא ברמת העסקה.
    כמה עסקאות מאותו אירוע אינן תצפיות בלתי-תלויות.
    """
    a = np.array([r["agent_prob"] for r in rows], dtype=float)
    m = np.array([r["market_prob"] for r in rows], dtype=float)
    o = np.array([r["outcome"] for r in rows], dtype=float)
    cids = np.array([cluster_of(r) for r in rows])

    per_cluster = []
    for c in np.unique(cids):
        mask = cids == c
        res = simulated_pnl(a[mask], m[mask], o[mask], spread=spread)
        if res["n_trades"] > 0:
            per_cluster.append(res["mean_pnl"])

    overall = simulated_pnl(a, m, o, spread=spread)
    if per_cluster:
        arr = np.array(per_cluster)
        overall["n_trades"] = len(arr)      # יחידת המדגם = אשכול
        overall["mean_pnl"] = float(arr.mean())
        overall["sd"] = float(arr.std(ddof=1)) if len(arr) > 1 else 0.0
    return overall, len(per_cluster)


def main():
    db = DB()
    print("=" * W)
    print("  PMLAB — האם לסוכן יש edge על השוק?")
    print("=" * W)

    print("\n[ בסיס ידע ]")
    for key, dom in DOMAINS.items():
        print(f"  {dom.label_he:<24} {db.knowledge_count(key):>4} פריטים")

    open_n = len(db.open_forecasts())
    all_res = db.resolved()
    abst = db.q("SELECT * FROM forecasts WHERE status='abstained'")
    void = db.q("SELECT * FROM forecasts WHERE status='void'")

    print(f"\n[ תחזיות ]")
    print(f"  פתוחות: {open_n}   הוכרעו: {len(all_res)}   "
          f"הימנעויות: {len(abst)}   void: {len(void)}")

    # ---- [3.1] ההימנעויות נמדדות, לא נזרקות ----
    if abst:
        print("\n[ הימנעויות — לפי סיבה ]")
        reasons = {}
        for r in abst:
            key = (r["abstain_reason"] or "?").split("(")[0].strip()[:44]
            reasons[key] = reasons.get(key, 0) + 1
        for k, v in sorted(reasons.items(), key=lambda x: -x[1]):
            print(f"  {v:>4}×  {k}")
        rate = len(abst) / (len(abst) + len(all_res) + open_n)
        print(f"  שיעור הימנעות: {rate:.1%}")

    if not all_res:
        print("\n  אין עדיין הכרעות.")
        print("=" * W)
        return

    # ---- לכל תחום ----
    results, pvals, keys, pnls = {}, [], [], {}
    print("\n[ דיוק לפי תחום ]")
    print(f"  {'תחום':<24} {'n':>5} {'clust':>6} {'סוכן':>9} {'שוק':>9} {'skill':>8}")
    print("  " + "-" * (W - 4))

    for key, dom in DOMAINS.items():
        rows = [r for r in db.resolved(key) if r["brier_market"] is not None]
        if not rows:
            print(f"  {dom.label_he:<24} {'—':>5}")
            continue

        agent = np.array([r["brier_agent"] for r in rows])
        market = np.array([r["brier_market"] for r in rows])
        cid = np.array([cluster_of(r) for r in rows])       # [3.11]

        res = cluster_robust_test(agent, market, cid)
        results[key] = res
        pvals.append(res["p_value"])
        keys.append(key)

        tradable = [r for r in rows if r["agent_prob"] is not None
                    and r["market_prob"] is not None
                    and r["outcome"] is not None]
        pnls[key] = cluster_level_pnl(tradable)[0] if tradable else None
        res["pnl"] = pnls[key]

        ss = skill_score(agent.mean(), market.mean())
        print(f"  {dom.label_he:<24} {len(rows):>5} {res['n_clusters']:>6} "
              f"{agent.mean():>9.4f} {market.mean():>9.4f} {ss:>+8.3f}")

    if not keys:
        print("\n  אין נתונים מספיקים.")
        print("=" * W)
        return

    # ---- [3.7] שני התיקונים, לא רק BH ----
    bh = benjamini_hochberg(pvals, alpha=0.05)
    bonf = bonferroni(pvals, alpha=0.05)

    print("\n[ מובהקות ]")
    print("  BH שולט ב-FDR. בונפרוני שולט ב-FWER — והוא הרלוונטי")
    print("  להחלטה על כסף. כסף מותנה בבונפרוני בלבד.\n")

    for key, p, ok_bh, ok_bf in zip(keys, pvals, bh, bonf):
        r = results[key]
        ci = (f"[{r['ci_low']:+.4f}, {r['ci_high']:+.4f}]"
              if r["ci_low"] is not None else "—")
        print(f"  {DOMAINS[key].label_he}")
        print(f"    יתרון Brier: {r['mean_diff']:+.4f}   95% CI: {ci}")
        print(f"    {r['n']} תחזיות ב-{r['n_clusters']} אשכולות   p={p:.4f}")
        print(f"    BH: {'עבר' if ok_bh else 'נכשל'}   "
              f"בונפרוני: {'עבר' if ok_bf else 'נכשל'}")

        pn = pnls.get(key)
        if pn and pn["n_trades"]:
            viable, why = is_economically_viable(pn)
            print(f"    P&L ברמת אשכול: {pn['mean_pnl']:+.4f} "
                  f"על {pn['n_trades']} אשכולות → {why}")
        print(f"    → {domain_verdict(key, r, ok_bh, ok_bf)}")
        print()

    # ---- כיול ----
    with_mkt = [r for r in all_res if r["brier_market"] is not None]
    probs = np.array([r["agent_prob"] for r in with_mkt])
    outs = np.array([r["outcome"] for r in with_mkt])
    print("[ כיול ]  (חוזה 70% → אמור לקרות ב-70%)")
    for b in calibration_bins(probs, outs):
        gap = b["actual"] - b["predicted"]
        flag = "  ←" if abs(gap) > 0.15 and b["n"] >= 5 else ""
        print(f"  {b['range']}  n={b['n']:<4} חזה {b['predicted']:.2f} "
              f"בפועל {b['actual']:.2f}  ({gap:+.2f}){flag}")

    # ---- עוצמה מהנתונים בפועל ----
    print("\n[ עוצמה — מחושבת מה-SD שנמדד ]")
    for key in keys:
        r = results[key]
        need = observed_power_need(r["sd_diff"], 0.006, n_tests=len(keys))
        print(f"  {DOMAINS[key].label_he:<24} SD={r['sd_diff']:.4f}  "
              f"נדרש ≈{need:,.0f} תחזיות")

    # ---- שורה תחתונה ----
    print("\n[ שורה תחתונה ]")
    winners = [k for k, ok in zip(keys, bonf)
               if ok and results[k]["mean_diff"] > 0
               and results[k]["n_clusters"] >= target_clusters(k)]
    if winners:
        for k in winners:
            print(f"  ★ {DOMAINS[k].label_he} — עבר בונפרוני ואת יעד האשכולות.")
    else:
        locked = [k for k in keys if results[k]["n_clusters"] < target_clusters(k)]
        if locked:
            need = ", ".join(
                f"{DOMAINS[k].label_he} ({results[k]['n_clusters']}/{target_clusters(k)})"
                for k in locked)
            print(f"  🔒 עדיין נעול: {need}")
        else:
            print("  אף תחום לא הראה edge מובהק. תוצאה תקפה.")

    print("=" * W)


if __name__ == "__main__":
    main()
