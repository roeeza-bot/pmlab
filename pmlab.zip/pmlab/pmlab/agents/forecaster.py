"""
סוכן-מעריך. אחד לכולם.

מקבל שאלת שוק, מתשאל את בסיס הידע של החוקר הרלוונטי,
ומחזיר הסתברות מספרית.

**הוא לא רואה את מחיר השוק.** זה לא עניין של סגנון —
זה מה שהופך את זה לניסוי במקום להד של השוק.
"""

import hashlib
import logging
import os

from ..core.evidence import (
    assess_evidence, evidence_fingerprint, should_abstain,
)
from ..core.knowledge_store import extract_entities, knowledge_for_event
from ..core.parsing import extract_probability, parse_json_object

log = logging.getLogger(__name__)

MODEL = "claude-sonnet-4-6"
PROMPT_VERSION = "v2-pit"      # point-in-time

FORECAST_SYSTEM = """You are a calibrated forecaster. You estimate probabilities.

METHOD (follow in order):
1. BASE RATE FIRST. Before anything else, ask: how often do events of this
   reference class occur? Start there and adjust.
2. Apply the specific evidence from the knowledge base as adjustments.
3. Check the resolution criteria carefully. Many forecasts fail not on the
   substance but because the question resolves differently than assumed.
4. Be honest about uncertainty. If the knowledge base doesn't cover this,
   say so via low confidence and stay near the base rate.

BASE RATE IS SUPPLIED TO YOU. You must not invent it.
The system computes it from a defined reference class and passes it in
as BASE_RATE. Start there. You may adjust away from it, but every
adjustment must cite a specific fact from the knowledge base. If you
cannot justify an adjustment with a cited fact, return the base rate.

CALIBRATION DISCIPLINE:
- Avoid 0.5 as a lazy default. If you truly have no information, say so
  with confidence "low" and return the supplied base rate unchanged.
- Avoid extremes (below 0.05, above 0.95) unless the outcome is nearly
  mechanically determined.
- Overconfidence is the most common and most expensive failure mode.

You have NOT been shown any market price, betting odds, or implied
probability. Do not guess at or reference what "the market thinks."
Your number must come from evidence and base rates alone.

If the supplied evidence does not actually bear on this question, set
"abstain": true. An abstention is a valid and valuable output. A weak
forecast pollutes the experiment more than no forecast at all.

Return ONLY this JSON, nothing else:
{"probability": <0.0-1.0>,
 "confidence": "high"|"medium"|"low",
 "base_rate_used": <the BASE_RATE you were given>,
 "adjustments": [{"direction": "up"|"down", "size": <0.0-0.5>,
                  "fact": "<the specific supplied fact justifying this>"}],
 "abstain": true|false,
 "abstain_reason": "<if abstaining>",
 "key_factors": ["<factor>", "..."],
 "resolution_risk": "<what could make this resolve unexpectedly>",
 "rationale": "<2-3 sentences>"}"""


class Forecaster:
    def __init__(self, db, api_key: str | None = None):
        self.db = db
        # ייבוא עצל: מאפשר לייבא ולבדוק את הצינור בלי SDK ובלי מפתח.
        from anthropic import Anthropic
        self.client = Anthropic(api_key=api_key or os.environ["ANTHROPIC_API_KEY"])

    def forecast(self, domain_key: str, question: str,
                 end_date: str, description: str = "",
                 as_of=None, base_rate: float | None = None,
                 sides=None) -> dict | None:
        """
        as_of: נקודת ההחלטה. שום מידע שפורסם אחריה לא נכנס.
               ברירת מחדל = עכשיו (מצב חי). בבקטסט חייב להיות
               מפורש, אחרת התוצאה חסרת ערך.
        base_rate: מחושב בקוד. המודל לא ממציא אותו.
        """
        from datetime import datetime, timezone

        if as_of is None:
            as_of = datetime.now(timezone.utc)

        from ..core.event_sides import parse_sides
        if sides is None:
            sides = parse_sides(question, description)

        entities = extract_entities(question)
        for e in (sides.yes_entity, sides.no_entity):
            if e and e.lower() not in entities:
                entities.append(e.lower())

        # ── אחזור ממוקד-אירוע ונכון-לנקודת-זמן ──
        retrieval = knowledge_for_event(
            self.db, domain=domain_key, question=question,
            as_of=as_of, entity_ids=entities, top_k=20,
        )

        # ── שער הימנעות מבוסס איכות ראיות, לא כמות ──
        eq = assess_evidence(retrieval.records, sides, now=as_of)
        fingerprint = evidence_fingerprint(retrieval.records, sides)

        abstain, reason = should_abstain(eq, sides)
        if abstain:
            log.info("[%s] ABSTAIN: %s | %s", domain_key, reason, question[:45])
            return {"abstain": True, "abstain_reason": reason,
                    "coverage": retrieval.coverage,
                    "n_records": eq.n_records,
                    "n_unique_claims": eq.n_unique_claims,
                    "n_independent_sources": eq.n_independent_sources,
                    "coverage_yes_side": eq.coverage_yes_side,
                    "coverage_no_side": eq.coverage_no_side,
                    "evidence_fingerprint": fingerprint,
                    "yes_entity": sides.yes_entity,
                    "no_entity": sides.no_entity,
                    "entities": entities, "as_of": as_of.isoformat()}

        if base_rate is None:
            base_rate = 0.5

        kb_text = "\n\n".join(
            f"[published {(r.published_at or r.collected_at).date()}] "
            f"(relevance {r.relevance:.2f}) {r.content}"
            for r in retrieval.records
        )

        from ..core.domains import DOMAINS
        dom = DOMAINS.get(domain_key)
        prior_block = ""
        if dom:
            factors = "\n".join(f"  - {f}" for f in dom.structural_factors)
            prior_block = f"""
CALIBRATION PRIOR FOR THIS DOMAIN (from published research):
{dom.prior_note}

STRUCTURAL FACTORS THE LITERATURE IDENTIFIES AS PREDICTIVE:
{factors}

Weigh these explicitly. If none of them clearly apply, that is a
signal to stay at the base rate rather than to reach for a view.
"""

        side_block = (f"YES resolves if: {sides.yes_entity or '(unparsed)'}\n"
                      f"NO resolves if: {sides.no_entity or '(unparsed)'}\n"
                      f"Direction verified: {sides.direction_verified}\n")

        prompt = f"""{side_block}
BASE_RATE (computed by the system, do not invent): {base_rate:.4f}
AS_OF (decision time — you have no information after this): {as_of.isoformat()}
ENTITIES IDENTIFIED: {', '.join(entities) or '(none)'}

EVIDENCE (filtered to this event, published before AS_OF):
{kb_text}
{prior_block}
---
QUESTION TO FORECAST:
{question}

{f"Details: {description}" if description else ""}
Resolves by: {end_date}

Start from BASE_RATE. Justify every adjustment with a cited fact above.
Return JSON only."""

        try:
            resp = self.client.messages.create(
                model=MODEL, max_tokens=1400, temperature=0.0,
                system=FORECAST_SYSTEM,
                messages=[{"role": "user", "content": prompt}],
            )
        except Exception as e:  # noqa: BLE001
            log.error("forecast API call failed: %s", e)
            return None

        text = "".join(b.text for b in resp.content if b.type == "text")
        data = parse_json_object(text)
        if not data:
            return None

        if data.get("abstain"):
            return {"abstain": True,
                    "abstain_reason": data.get("abstain_reason", "model chose"),
                    "coverage": retrieval.coverage,
                    "n_records": len(retrieval.records),
                    "entities": entities, "as_of": as_of.isoformat()}

        p = extract_probability(data)
        if p is None:
            return None

        # ── ולידציה: המודל לא רשאי להחליף את ה-base rate ──
        claimed = data.get("base_rate_used")
        try:
            if claimed is not None and abs(float(claimed) - base_rate) > 0.02:
                log.warning("model altered base rate: %.3f vs supplied %.3f",
                            float(claimed), base_rate)
                data["base_rate_violation"] = True
        except (TypeError, ValueError):
            data["base_rate_violation"] = True

        data["probability"] = p
        data["abstain"] = False
        data["base_rate"] = base_rate
        data["coverage"] = retrieval.coverage
        data["n_records"] = eq.n_records
        data["n_unique_claims"] = eq.n_unique_claims
        data["n_independent_sources"] = eq.n_independent_sources
        data["coverage_yes_side"] = eq.coverage_yes_side
        data["coverage_no_side"] = eq.coverage_no_side
        data["source_diversity"] = eq.source_diversity
        data["freshness_hours"] = eq.freshness_hours
        data["evidence_fingerprint"] = fingerprint
        data["yes_entity"] = sides.yes_entity
        data["no_entity"] = sides.no_entity
        data["direction_verified"] = sides.direction_verified
        data["excluded_by_time"] = retrieval.n_excluded_by_time
        data["excluded_by_entity"] = retrieval.n_excluded_by_entity
        data["entities"] = entities
        data["as_of"] = as_of.isoformat()
        data["model_version"] = MODEL
        data["prompt_hash"] = hashlib.sha256(
            (FORECAST_SYSTEM + PROMPT_VERSION).encode()).hexdigest()[:16]
        data["knowledge_ids"] = [r.id for r in retrieval.records]
        return data

