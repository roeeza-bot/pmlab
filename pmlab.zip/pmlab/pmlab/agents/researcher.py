"""
סוכן-חוקר. אחד לכל תחום.

עיקרון קריטי: החוקר **לא רואה מחירי שוק, לעולם**.
אם הוא יראה אותם, הוא יעגן אליהם ונאבד את כל הניסוי.
הוא רק אוסף עובדות, מגמות ושיקולים על התחום.
"""

import json
import logging
import os

from ..core.domains import Domain
from ..core.parsing import parse_json_array

log = logging.getLogger(__name__)

MODEL = "claude-sonnet-4-6"

RESEARCH_SYSTEM = """You are a domain research analyst building a knowledge base.

Your job is to gather CURRENT, SPECIFIC, DECISION-RELEVANT facts about your domain.

CRITICAL RULES:
- Never search for, reference, or record betting odds, prediction market prices,
  bookmaker lines, or implied probabilities. If you encounter them, ignore them
  entirely. Your value comes from independent analysis.
- Prioritize base rates, historical frequencies, and structural factors over
  narrative and punditry.
- Record what is KNOWN and what is UNCERTAIN, separately.
- Prefer primary sources and quantitative data.

TIMESTAMPS ARE MANDATORY. For every fact you must report when the
underlying information was PUBLISHED, not when you found it. If you
cannot determine a publication date, set published_at to null — do
not guess. A fact with an unknown publication date will be excluded
from point-in-time analysis, which is correct behaviour.

ENTITIES ARE MANDATORY. List the specific teams, fighters, or players
each fact concerns. A fact with no named entity cannot be matched to
an event.

Return ONLY a JSON array, no preamble, no markdown fences:
[
  {"fact": "<one specific, dated, decision-relevant fact>",
   "why_it_matters": "<how this shifts probabilities>",
   "source": "<url>",
   "published_at": "<ISO 8601 date the source was published, or null>",
   "entities": ["<team/fighter/player this concerns>", "..."],
   "salience": <0.0-1.0>,
   "confidence": "high"|"medium"|"low"}
]
Aim for 5-12 entries. Quality over quantity."""


class Researcher:
    def __init__(self, domain: Domain, db, api_key: str | None = None):
        self.domain = domain
        self.db = db
        # ייבוא עצל: מאפשר לייבא ולבדוק את הצינור בלי SDK ובלי מפתח.
        from anthropic import Anthropic
        self.client = Anthropic(api_key=api_key or os.environ["ANTHROPIC_API_KEY"])

    def research_event(self, sides, market=None) -> int:
        """
        [ביקורת 6, 3.1] מחקר ממוקד-אירוע.

        סריקת תחום רחבה ("UFC upcoming card") אינה תחליף למחקר
        על שני הלוחמים הספציפיים ועל האירוע המשותף שלהם.
        """
        from ..core.event_sides import event_research_queries

        added = 0
        for spec in event_research_queries(sides, self.domain.key):
            try:
                added += self._research_one(spec["query"])
            except Exception as e:  # noqa: BLE001
                log.error("[%s] event research failed on %s: %s",
                          self.domain.key, spec["side"], e)
        self.db.log_run("research_event", self.domain.key, added,
                        f"{sides.yes_entity} vs {sides.no_entity}")
        return added

    def run_cycle(self) -> int:
        """סבב מחקר אחד. מריצים כמה פעמים ביום, ימים ברצף."""
        added = 0
        for query in self.domain.research_queries:
            try:
                added += self._research_one(query)
            except Exception as e:  # noqa: BLE001
                log.error("[%s] research failed on '%s': %s",
                          self.domain.key, query, e)
        self.db.log_run("research", self.domain.key, added)
        log.info("[%s] +%d knowledge items (total %d)",
                 self.domain.key, added, self.db.knowledge_count(self.domain.key))
        return added

    def _research_one(self, query: str) -> int:
        existing = self.db.knowledge_for(self.domain.key, limit=15)
        known = "\n".join(f"- {r['content'][:160]}" for r in existing)

        factors = "\n".join(f"  - {f}" for f in self.domain.structural_factors)
        prompt = f"""Domain: {self.domain.key}
Research focus: {query}

STRUCTURAL FACTORS THIS DOMAIN IS KNOWN TO TURN ON.
Prioritise facts that bear on these:
{factors}

Already in the knowledge base (do NOT duplicate these):
{known or "(empty - this is the first cycle)"}

Search the web for current information and return NEW facts as JSON."""

        resp = self.client.messages.create(
            model=MODEL,
            max_tokens=3000,
            system=RESEARCH_SYSTEM,
            messages=[{"role": "user", "content": prompt}],
            tools=[{"type": "web_search_20250305", "name": "web_search"}],
        )

        text = "".join(b.text for b in resp.content if b.type == "text")
        items = parse_json_array(text)

        n = 0
        for it in items:
            fact = it.get("fact", "").strip()
            if not fact:
                continue
            content = f"{fact}\n→ {it.get('why_it_matters', '')}"
            # [3.4] שמירת זמן פרסום וישויות — בלעדיהם אין point-in-time
            ents = it.get("entities") or []
            if isinstance(ents, str):
                ents = [ents]
            ents = [str(e).lower().strip() for e in ents if e]

            self.db.add_knowledge(
                self.domain.key,
                it.get("source", ""),
                query,
                content,
                float(it.get("salience", 0.5)),
                published_at=it.get("published_at") or None,
                entity_ids=ents or None,
            )
            n += 1
        return n

