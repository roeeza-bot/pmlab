"""
בקטסט על שווקים שכבר הוכרעו.

הרעיון: במקום לחכות שנה לאלפי תחזיות, לוקחים שווקים
שכבר נסגרו ומבקשים מהסוכן לחזות אותם רטרואקטיבית.

הבעיה הקטלנית: המודל אומן על מידע עד תאריך מסוים.
אם נבקש ממנו לחזות אירוע שקרה *לפני* התאריך הזה,
הוא פשוט יזכור את התשובה. הציון יהיה מושלם וחסר ערך.

הבקרות שמיושמות כאן:
  1. חלון נקי בלבד — רק שווקים שהוכרעו אחרי נקודת החיתוך
  2. חיפוש רשת מנוטרל למעריך
  3. בסיס ידע לא זמין במצב בקטסט (אחרת הוא מזוהם בדיעבד)
  4. גלאי זיהום — משווה ביצועים בחלון מזוהם מול נקי
"""

import logging
import time
from datetime import datetime, timedelta, timezone

from .core.db import DB, utcnow
from .core.parsing import extract_probability, parse_json_object
from .core.domains import DOMAINS
from .core.stats import brier
from .platforms.polymarket import Polymarket, is_binary, match_domain

log = logging.getLogger(__name__)

# נקודת החיתוך של המודל. שווקים שהוכרעו אחריה הם "נקיים".
MODEL_CUTOFF = datetime(2026, 5, 31, tzinfo=timezone.utc)

# חלון בקרה מזוהם בכוונה — לגלאי הזיהום
CONTROL_WINDOW_START = datetime(2025, 1, 1, tzinfo=timezone.utc)
CONTROL_WINDOW_END = datetime(2025, 6, 30, tzinfo=timezone.utc)


BACKTEST_SYSTEM = """You are a calibrated forecaster estimating a probability
for an event whose outcome you must treat as UNKNOWN.

CRITICAL INTEGRITY REQUIREMENT:
You may have encountered information about this event during training. If you
find yourself recalling the actual outcome, you MUST NOT use it. Set
"recalled_outcome": true and give the probability you would have assigned
using only information available BEFORE the event, reasoning from base rates
and structural factors.

Honesty here is the entire point of the exercise. A forecast contaminated by
hindsight is worse than useless — it produces a false signal of skill.

METHOD:
1. Identify the reference class. What is the base rate for this kind of event?
2. Adjust using only pre-event structural factors.
3. Check the resolution criteria carefully.
4. Avoid extremes unless mechanically determined.

Return ONLY this JSON:
{"probability": <0.0-1.0>,
 "confidence": "high"|"medium"|"low",
 "base_rate_used": <0.0-1.0>,
 "recalled_outcome": true|false,
 "rationale": "<2-3 sentences>"}"""


def parse_dt(s):
    if not s:
        return None
    try:
        return datetime.fromisoformat(str(s).replace("Z", "+00:00"))
    except ValueError:
        return None


def resolution_window(market: dict) -> str | None:
    """מסווג שוק ל'נקי' / 'מזוהם' / None."""
    end = parse_dt(market.get("endDate"))
    if not end:
        return None
    if end > MODEL_CUTOFF:
        return "clean"
    if CONTROL_WINDOW_START <= end <= CONTROL_WINDOW_END:
        return "contaminated_control"
    return None


def fetch_resolved(pm: Polymarket, pages: int = 12) -> list[dict]:
    """שווקים סגורים. הפרמטר closed=true."""
    out = []
    for i in range(pages):
        batch = pm._get("/markets", {
            "closed": "true", "archived": "false",
            "limit": 250, "offset": i * 250,
            "order": "endDate", "ascending": "false",
        })
        if not batch:
            break
        out.extend(batch)
        time.sleep(0.4)
    return out


# שוק שנפתר ל-0.5/0.5, בוטל, או שנוי במחלוקת — אינו תוצאה בינארית.
# מיפוי שלו ל-NO מזהם את המדגם עם "הפסדים" מדומים.
VOID_TOLERANCE = 0.02


def actual_outcome(market: dict) -> int | None:
    """
    מחזיר 1 / 0, או None אם השוק void, שנוי במחלוקת, או לא הוכרע חד-משמעית.
    None = לדלג על השוק, לא "הפסיד".
    """
    import json

    if market.get("umaResolutionStatus") in ("disputed", "proposed", "void"):
        return None

    # ההכרעה נקראת לפי התווית, לא לפי מיקום — אותה סיבה
    # בדיוק כמו במחיר. אינדקס קשיח מתהפך בשקט.
    from .platforms.polymarket import yes_index
    idx = yes_index(market)
    if idx is None:
        return None

    pr = market.get("outcomePrices")
    if isinstance(pr, str):
        try:
            pr = json.loads(pr)
        except json.JSONDecodeError:
            return None
    if not isinstance(pr, list) or len(pr) != 2:
        return None

    try:
        yes = float(pr[idx])
        no = float(pr[1 - idx])
    except (TypeError, ValueError):
        return None

    if not (0.0 <= yes <= 1.0 and 0.0 <= no <= 1.0):
        return None
    if abs(yes + no - 1.0) > 0.05:      # לא מסתכם ל-1 → לא הכרעה תקפה
        return None
    if abs(yes - 0.5) <= VOID_TOLERANCE:  # תיקו / void
        return None

    return 1 if yes > 0.5 else 0


# [CRIT-3 fix] כמה שעות לפני ההכרעה לוקחים את מחיר ההשוואה.
# lastTradePrice הוא המחיר האחרון — הוא ראה כמעט את כל המידע
# ולכן מדויק בצורה קיצונית. השוואה מולו מטה את התוצאה נגד
# הסוכן בגודל לא ידוע, כלומר הופכת אותה ללא בת-פירוש.
COMPARISON_LEAD_HOURS = 24

CLOB_HOST = "https://clob.polymarket.com"


def historical_price(session, token_id: str, end_date_iso: str,
                     lead_hours: int = COMPARISON_LEAD_HOURS) -> float | None:
    """
    מחיר השוק בנקודת זמן קבועה לפני ההכרעה.
    זו ההשוואה ההוגנת: הסוכן והשוק מקבלים את אותו אופק.
    """
    end = parse_dt(end_date_iso)
    if not end:
        return None
    target = end - timedelta(hours=lead_hours)
    ts = int(target.timestamp())
    try:
        r = session.get(f"{CLOB_HOST}/prices-history",
                        params={"market": token_id,
                                "startTs": ts - 7200,
                                "endTs": ts + 7200,
                                "fidelity": 60},
                        timeout=20)
        r.raise_for_status()
        hist = (r.json() or {}).get("history") or []
    except Exception:  # noqa: BLE001
        return None
    if not hist:
        return None
    # הנקודה הקרובה ביותר ליעד
    best = min(hist, key=lambda h: abs(int(h.get("t", 0)) - ts))
    try:
        p = float(best["p"])
    except (KeyError, TypeError, ValueError):
        return None
    return p if 0 < p < 1 else None


def token_ids(market: dict) -> list[str]:
    import json as _j
    v = market.get("clobTokenIds")
    if isinstance(v, str):
        try:
            v = _j.loads(v)
        except _j.JSONDecodeError:
            return []
    return [str(x) for x in v] if isinstance(v, list) else []


def cluster_id(market: dict, domain: str) -> str:
    """אשכול = תחום + יום ההכרעה. שווקים כאלה אינם עצמאיים."""
    day = str(market.get("endDate") or "")[:10]
    return f"{domain}|{day}"


class BacktestForecaster:
    def __init__(self, api_key=None):
        import os

        from anthropic import Anthropic     # ייבוא עצל
        self.client = Anthropic(api_key=api_key or os.environ["ANTHROPIC_API_KEY"])

    def forecast(self, question: str, end_date: str, description: str = ""):
        prompt = f"""QUESTION:
{question}

{f"Details: {description}" if description else ""}
Resolution date: {end_date}

Estimate the probability this resolved YES. JSON only."""

        try:
            resp = self.client.messages.create(
                model="claude-sonnet-4-6",
                max_tokens=900,
                system=BACKTEST_SYSTEM,
                messages=[{"role": "user", "content": prompt}],
                # שים לב: אין tools. חיפוש רשת מנוטרל בכוונה.
            )
        except Exception as e:  # noqa: BLE001
            log.error("backtest forecast failed: %s", e)
            return None

        text = "".join(b.text for b in resp.content if b.type == "text")
        data = parse_json_object(text)
        p = extract_probability(data)
        if p is None:
            return None
        data["probability"] = p
        return data


def run(limit_per_window: int = 150):
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(message)s",
                        datefmt="%H:%M:%S")
    db = DB("backtest.db")
    pm = Polymarket()
    fc = BacktestForecaster()

    markets = fetch_resolved(pm, pages=12)
    log.info("fetched %d resolved markets", len(markets))

    counts = {"clean": 0, "contaminated_control": 0}

    for m in markets:
        win = resolution_window(m)
        if not win or counts[win] >= limit_per_window:
            continue
        if not is_binary(m):
            continue

        domain = match_domain(m, DOMAINS)
        if not domain:
            continue

        outcome = actual_outcome(m)
        toks = token_ids(m)
        mkt_p = (historical_price(pm.s, toks[0], str(m.get("endDate") or ""))
                 if toks else None)
        if outcome is None or mkt_p is None:
            continue

        mid = f"bt-{win}-{m.get('id')}"
        if db.has_forecast("backtest", mid):
            continue

        q = (m.get("question") or "").strip()
        if not q:
            continue

        res = fc.forecast(q, str(m.get("endDate") or ""),
                          (m.get("description") or "")[:600])
        if not res:
            continue

        ba = brier(res["probability"], outcome)
        bm = brier(mkt_p, outcome)

        db.exec(
            """INSERT INTO forecasts
               (created_at, domain, platform, market_id, condition_id, question,
                end_date, cluster_id, agent_prob, agent_confidence,
                agent_rationale, market_prob, resolved_at, outcome,
                brier_agent, brier_market, status)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'resolved')""",
            (utcnow(), f"{domain}|{win}", "backtest", mid,
             str(m.get("conditionId") or ""), q, str(m.get("endDate") or ""),
             cluster_id(m, domain),
             res["probability"], res.get("confidence"),
             f"[recalled={res.get('recalled_outcome')}] {res.get('rationale','')}"[:900],
             mkt_p, utcnow(), outcome, ba, bm),
        )

        counts[win] += 1
        flag = "!" if res.get("recalled_outcome") else " "
        log.info("%s [%s|%s] agent=%.2f mkt=%.2f out=%d | %s",
                 flag, domain, win[:5], res["probability"], mkt_p, outcome, q[:44])
        time.sleep(0.7)

        if all(counts[k] >= limit_per_window for k in counts):
            break

    log.info("done — clean:%d contaminated_control:%d",
             counts["clean"], counts["contaminated_control"])
    log.info("run: python -m pmlab.backtest_report")


if __name__ == "__main__":
    run()
