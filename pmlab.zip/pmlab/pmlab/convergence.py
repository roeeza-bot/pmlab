"""
סורק התכנסות.  ./venv/bin/python -m pmlab.convergence

התזה, אחרי הביקורת:

    לא "פולימרקט חולק על Pinnacle → להמר".
    אלא "Pinnacle **זז**, פולימרקט **טרם** → להמר על ההתכנסות".

ההבדל מהותי. הפער ברמה הוא לרוב מלכודת ערך — פולימרקט
נראה זול כי הוא פשוט טרם התעדכן, ואנחנו הצד האיטי.
תנועה, לעומת זאת, היא סיגנל: מישהו הניח כסף חכם ב-Pinnacle,
והשאלה היחידה היא כמה זמן לוקח לזה להגיע לשוק החיזוי.

**מה שנמדד כאן אינו רווח.** נמדד CLV — האם המחיר זז לכיווננו
אחרי הכניסה. זה מתגלה תוך שעות במקום חודשיים, ולפי הספרות
הוא המדד המקדים החזק ביותר ל-edge אמיתי.

  ./venv/bin/python -m pmlab.convergence collect   # אוסף תמונות מצב
  ./venv/bin/python -m pmlab.convergence report    # מנתח
"""

import logging
import os
import sys
import time
from datetime import datetime, timedelta, timezone

import numpy as np
import requests

log = logging.getLogger(__name__)

ODDSPAPI = "https://api.oddspapi.io/v4"

# ── פרמטרים, ננעלים מראש ──
MOVE_THRESHOLD = 0.02      # תנועה מינימלית ב-Pinnacle שנחשבת סיגנל
LAG_THRESHOLD = 0.015      # פער מינימלי מול שוק החיזוי אחרי התנועה
POLL_SECONDS = 120
HORIZONS_MIN = [5, 15, 30, 60, 120]   # מתי בודקים התכנסות

# שווקים ראשיים בלבד. הביקורת הראתה שבעתידיים הוויג של
# Pinnacle מגיע ל-15% ובפרופס הוא לא הבנצ'מרק בכלל.
#
# sportId מספרי, מאומת מול /v4/sports:
SPORTS = {
    10: "soccer",
    11: "basketball",
    12: "tennis",
    13: "baseball",
    15: "ice-hockey",
    20: "mma",
}

VENUES = ["pinnacle", "polymarket", "sx.bet", "limitless-ex", "betfair-ex"]

DB_PATH = "convergence.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS snaps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    fixture_id TEXT NOT NULL,
    venue TEXT NOT NULL,
    side TEXT NOT NULL,
    decimal_odds REAL,
    implied REAL,
    novig REAL
);
CREATE INDEX IF NOT EXISTS idx_snap ON snaps(fixture_id, venue, ts);

CREATE TABLE IF NOT EXISTS signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    detected_at TEXT NOT NULL,
    fixture_id TEXT NOT NULL,
    venue TEXT NOT NULL,
    side TEXT NOT NULL,
    pin_before REAL,
    pin_after REAL,
    pin_move REAL,
    venue_at_signal REAL,
    lag REAL,
    direction TEXT,
    resolved INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS followups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    signal_id INTEGER NOT NULL,
    horizon_min INTEGER NOT NULL,
    venue_price REAL,
    converged REAL,          -- כמה מהפער נסגר, 0..1
    clv REAL                 -- תנועה לכיווננו במונחי הסתברות
);
"""


# ─────────────────────────────────────────────────────────────
# מתמטיקה
# ─────────────────────────────────────────────────────────────

def implied(decimal):
    """יחס עשרוני → הסתברות משתמעת (כולל ויג)."""
    try:
        d = float(decimal)
        return 1.0 / d if d > 1.0 else None
    except (TypeError, ValueError):
        return None


def devig_two_way(p_home, p_away, method="multiplicative"):
    """
    הפשטת ויג משוק דו-כיווני.

    הביקורת הזכירה ששיטת המרווח השווה גסה ולא מדויקת.
    ברירת המחדל כאן היא נורמליזציה כפלית — פשוטה ועמידה.
    שיטת Shin טובה יותר בנוכחות הטיית favorite-longshot,
    אבל דורשת פרמטר נוסף ואינה יציבה במדגם קטן.
    """
    if p_home is None or p_away is None:
        return None, None
    total = p_home + p_away
    if total <= 0:
        return None, None
    if method == "multiplicative":
        return p_home / total, p_away / total
    # additive: מחלק את הוויג שווה בשווה
    margin = total - 1.0
    return p_home - margin / 2, p_away - margin / 2


def prediction_market_novig(p_yes, p_no):
    """
    שוק חיזוי בינארי: המחירים אמורים להסתכם ל-1.
    סטייה היא ספרד, לא ויג — אבל הנרמול זהה.
    """
    return devig_two_way(p_yes, p_no)


# ─────────────────────────────────────────────────────────────
# לקוח
# ─────────────────────────────────────────────────────────────

class OddsPapi:
    def __init__(self, api_key=None):
        self.key = api_key or os.environ.get("ODDSPAPI_KEY", "")
        self.s = requests.Session()

    def _get(self, path, params, retries=3):
        params = dict(params or {})
        params["apiKey"] = self.key
        for i in range(retries):
            try:
                r = self.s.get(f"{ODDSPAPI}{path}", params=params, timeout=25)
                if r.status_code == 429:
                    time.sleep(2 ** i)
                    continue
                r.raise_for_status()
                return r.json()
            except Exception as e:  # noqa: BLE001
                if i == retries - 1:
                    log.error("GET %s failed: %s", path, e)
                time.sleep(1.5 * (i + 1))
        return None

    def fixtures(self, sport_id, hours_ahead=48):
        """
        הפרמטרים הם from/to (לא startDate/endDate), והם חובה
        כשמסופק רק sportId. חלון מקסימלי: 10 ימים.
        התשובה היא מערך ישיר, בלי מעטפת.
        """
        now = datetime.now(timezone.utc)
        data = self._get("/fixtures", {
            "sportId": sport_id,
            "from": now.strftime("%Y-%m-%d"),
            "to": (now + timedelta(hours=hours_ahead)).strftime("%Y-%m-%d"),
        })
        if data is None:
            return []
        items = data if isinstance(data, list) else (
            data.get("fixtures") or data.get("data") or [])
        if not isinstance(items, list):
            return []

        out = []
        for f in items:
            if not isinstance(f, dict):
                continue
            # רק משחקים שטרם התחילו ושיש עליהם יחסים
            if not f.get("hasOdds"):
                continue
            if str(f.get("statusName", "")).lower() in (
                    "finished", "cancelled", "postponed", "abandoned"):
                continue
            st = f.get("trueStartTime") or f.get("startTime")
            if st:
                try:
                    dt = datetime.fromisoformat(str(st).replace("Z", "+00:00"))
                    if dt <= now:          # כבר התחיל
                        continue
                except ValueError:
                    pass
            out.append(f)
        return out

    def odds(self, fixture_id, venues):
        return self._get("/odds", {
            "fixtureId": fixture_id,
            "bookmakers": ",".join(venues),
        })


def extract_two_way(book):
    """
    מוציא (home, away) ביחסים עשרוניים ממבנה התשובה.
    המבנה משתנה בין מקומות, לכן זה סלחני בכוונה.
    """
    try:
        m = (book.get("markets") or {}).get("101") or {}
        outs = m.get("outcomes") or {}
        o = (outs.get("101") or {}).get("players") or {}
        home = (o.get("0") or {}).get("price")
        away = (o.get("1") or {}).get("price")
        if home is None or away is None:
            vals = [v.get("price") for v in o.values() if isinstance(v, dict)]
            vals = [v for v in vals if v]
            if len(vals) >= 2:
                home, away = vals[0], vals[1]
        return home, away
    except (AttributeError, TypeError):
        return None, None


# ─────────────────────────────────────────────────────────────
# איסוף
# ─────────────────────────────────────────────────────────────

def collect(minutes=180):
    import sqlite3
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    conn.commit()

    api = OddsPapi()
    if not api.key:
        print("\n  חסר ODDSPAPI_KEY. הרשמה חינם: oddspapi.io\n")
        return

    deadline = datetime.now(timezone.utc) + timedelta(minutes=minutes)
    cycle = 0

    while datetime.now(timezone.utc) < deadline:
        cycle += 1
        fixtures = []
        for sid in SPORTS:
            fixtures.extend(api.fixtures(sid)[:20])
        log.info("cycle %d: %d fixtures", cycle, len(fixtures))

        for fx in fixtures:
            fid = str(fx.get("id") or fx.get("fixtureId") or "")
            if not fid:
                continue
            data = api.odds(fid, VENUES)
            if not data:
                continue
            books = data.get("bookmakerOdds") or {}
            now = datetime.now(timezone.utc).isoformat()

            prices = {}
            for slug, book in books.items():
                h, a = extract_two_way(book)
                ph, pa = implied(h), implied(a)
                nh, na = devig_two_way(ph, pa)
                if nh is None:
                    continue
                prices[slug] = nh
                for side, dec, imp, nov in (("home", h, ph, nh),
                                            ("away", a, pa, na)):
                    conn.execute(
                        "INSERT INTO snaps (ts, fixture_id, venue, side, "
                        "decimal_odds, implied, novig) VALUES (?,?,?,?,?,?,?)",
                        (now, fid, slug, side, dec, imp, nov))
            conn.commit()

            if "pinnacle" in prices:
                detect_signal(conn, fid, prices)
            time.sleep(0.4)

        resolve_followups(conn, api)
        log.info("sleeping %ds", POLL_SECONDS)
        time.sleep(POLL_SECONDS)

    conn.close()


def detect_signal(conn, fid, prices):
    """
    סיגנל = Pinnacle זז מעל הסף, ושוק החיזוי עדיין לא.

    שים לב: הסיגנל אינו "יש פער". הפער לבדו הוא לרוב
    מלכודת ערך. הסיגנל הוא **תנועה ב-Pinnacle שטרם הועתקה**.
    """
    rows = conn.execute(
        "SELECT novig, ts FROM snaps WHERE fixture_id=? AND venue='pinnacle' "
        "AND side='home' ORDER BY ts DESC LIMIT 2", (fid,)).fetchall()
    if len(rows) < 2:
        return
    pin_now, pin_prev = rows[0]["novig"], rows[1]["novig"]
    if pin_now is None or pin_prev is None:
        return
    move = pin_now - pin_prev
    if abs(move) < MOVE_THRESHOLD:
        return

    for slug, price in prices.items():
        if slug == "pinnacle":
            continue
        lag = pin_now - price
        # הפער חייב להיות **באותו כיוון** שאליו Pinnacle זז.
        # אחרת זו לא השהיה — זו אי-הסכמה אמיתית, וזו מלכודת.
        if abs(lag) < LAG_THRESHOLD or np.sign(lag) != np.sign(move):
            continue
        conn.execute(
            """INSERT INTO signals (detected_at, fixture_id, venue, side,
               pin_before, pin_after, pin_move, venue_at_signal, lag, direction)
               VALUES (?,?,?,'home',?,?,?,?,?,?)""",
            (datetime.now(timezone.utc).isoformat(), fid, slug,
             pin_prev, pin_now, move, price, lag,
             "up" if move > 0 else "down"))
        conn.commit()
        log.info("SIGNAL %s fid=%s pin %.3f→%.3f (%+.3f) venue=%.3f lag=%+.3f",
                 slug, fid[:10], pin_prev, pin_now, move, price, lag)


def resolve_followups(conn, api):
    """בודק אם המחיר בשוק החיזוי התכנס לכיוון Pinnacle."""
    open_sigs = conn.execute(
        "SELECT * FROM signals WHERE resolved=0").fetchall()
    now = datetime.now(timezone.utc)

    for s in open_sigs:
        t0 = datetime.fromisoformat(s["detected_at"])
        age = (now - t0).total_seconds() / 60
        done = {r["horizon_min"] for r in conn.execute(
            "SELECT horizon_min FROM followups WHERE signal_id=?",
            (s["id"],))}

        for h in HORIZONS_MIN:
            if h in done or age < h:
                continue
            row = conn.execute(
                "SELECT novig FROM snaps WHERE fixture_id=? AND venue=? "
                "AND side='home' ORDER BY ts DESC LIMIT 1",
                (s["fixture_id"], s["venue"])).fetchone()
            if not row or row["novig"] is None:
                continue
            price_now = row["novig"]
            lag0 = s["lag"]
            moved = price_now - s["venue_at_signal"]
            converged = moved / lag0 if lag0 else 0.0
            # CLV: תנועה לכיווננו. חיובי = המחיר הלך לכיוון שהמרנו.
            clv = moved * np.sign(lag0)
            conn.execute(
                "INSERT INTO followups (signal_id, horizon_min, venue_price, "
                "converged, clv) VALUES (?,?,?,?,?)",
                (s["id"], h, price_now, float(converged), float(clv)))
            conn.commit()

        if age > max(HORIZONS_MIN):
            conn.execute("UPDATE signals SET resolved=1 WHERE id=?", (s["id"],))
            conn.commit()


# ─────────────────────────────────────────────────────────────
# דוח
# ─────────────────────────────────────────────────────────────

def report():
    import sqlite3
    if not os.path.exists(DB_PATH):
        print("\n  אין נתונים. הרץ קודם: convergence collect\n")
        return
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row

    W = 68
    print("=" * W)
    print("  סורק התכנסות — האם שוקי חיזוי מפגרים אחרי Pinnacle?")
    print("=" * W)

    sigs = conn.execute("SELECT * FROM signals").fetchall()
    snaps = conn.execute("SELECT COUNT(*) c FROM snaps").fetchone()["c"]
    print(f"\n  תמונות מצב: {snaps}   סיגנלים: {len(sigs)}")

    if not sigs:
        print("\n  לא נמצאו סיגנלים. אפשרויות:")
        print("   • Pinnacle לא זז מספיק בחלון שנדגם")
        print("   • שוקי החיזוי מתעדכנים מיד — אין השהיה")
        print("   • אין חפיפה בין המשחקים שהמקומות מכסים")
        print("=" * W)
        return

    by_venue = {}
    for s in sigs:
        by_venue.setdefault(s["venue"], []).append(s)
    print("\n[ סיגנלים לפי מקום ]")
    for v, lst in sorted(by_venue.items(), key=lambda x: -len(x[1])):
        lags = [abs(x["lag"]) for x in lst]
        print(f"  {v:<14} {len(lst):>4} סיגנלים   פער ממוצע {np.mean(lags):.3f}")

    print("\n[ התכנסות לפי אופק ]")
    print("  converged = איזה חלק מהפער נסגר. 1.0 = התכנסות מלאה.")
    print("  CLV חיובי = המחיר זז לכיוון שהמרנו.\n")
    print(f"  {'דקות':>6} {'n':>5} {'converged':>11} {'CLV ממוצע':>11} "
          f"{'CLV>0':>8}")
    print("  " + "-" * 46)

    any_rows = False
    for h in HORIZONS_MIN:
        rows = conn.execute(
            "SELECT converged, clv FROM followups WHERE horizon_min=?",
            (h,)).fetchall()
        if not rows:
            continue
        any_rows = True
        cv = np.array([r["converged"] for r in rows], float)
        clv = np.array([r["clv"] for r in rows], float)
        print(f"  {h:>6} {len(rows):>5} {np.mean(cv):>11.2f} "
              f"{np.mean(clv):>+11.4f} {np.mean(clv > 0)*100:>7.0f}%")

    if not any_rows:
        print("  אין עדיין מעקבים. צריך זמן ריצה ארוך יותר.")
        print("=" * W)
        return

    print("\n[ פסק דין ]")
    rows = conn.execute(
        "SELECT clv, converged FROM followups WHERE horizon_min=?",
        (max(h for h in HORIZONS_MIN),)).fetchall()
    if len(rows) < 20:
        print(f"  רק {len(rows)} מעקבים באופק הארוך. צריך 20+ למסקנה.")
    else:
        clv = np.array([r["clv"] for r in rows], float)
        se = clv.std(ddof=1) / np.sqrt(len(clv))
        lo = clv.mean() - 1.96 * se
        print(f"  CLV ממוצע: {clv.mean():+.4f}   גבול תחתון 95%: {lo:+.4f}")
        print()
        if lo > 0.005:
            print("  ★ יש השהיה מדידה. המחיר מתכנס לכיוון Pinnacle.")
            print("    זה ה-edge. הצעד הבא: לבדוק אם הוא שורד ספרד.")
        elif lo > 0:
            print("  התכנסות חיובית אך קטנה. צריך לבדוק מול עלויות.")
        else:
            print("  אין השהיה מדידה. שוקי החיזוי מתעדכנים מהר כמו")
            print("  Pinnacle, או שהפערים הם אי-הסכמה אמיתית ולא פיגור.")

    print("\n[ אזהרה ]")
    print("  CLV חיובי מראה שהמחיר זז לכיוונך — לא שהרווחת.")
    print("  הספרד, גודל הפוזיציה והמילוי עדיין יכולים למחוק הכל.")
    print("=" * W)


def main():
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(message)s",
                        datefmt="%H:%M:%S")
    cmd = sys.argv[1] if len(sys.argv) > 1 else "report"
    if cmd == "collect":
        mins = int(sys.argv[2]) if len(sys.argv) > 2 else 180
        collect(mins)
    else:
        report()


if __name__ == "__main__":
    main()
