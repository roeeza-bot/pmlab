"""
מנצח התזמורת.

  python -m pmlab.run research    # סבב מחקר לכל 5 החוקרים
  python -m pmlab.run forecast    # מייצר תחזיות על שווקים חדשים
  python -m pmlab.run resolve     # בודק הכרעות ומחשב Brier
  python -m pmlab.run loop        # הכל, בלולאה

סדר עבודה מומלץ:
  יום 1-3:  רק research  (בונים בסיס ידע)
  יום 4+:   loop
"""

import logging
import sys
import time
from datetime import datetime, timedelta, timezone

from .agents.forecaster import Forecaster
from .agents.researcher import Researcher
from .backtest import actual_outcome          # [3.8] מקור אמת יחיד להכרעה
from .core.base_rates import get_base_rate    # [3.2] חיבור מנוע ה-base rate
from .core.event_sides import (
    event_research_queries, parse_sides, verify_direction,
)
from .core.evidence import evidence_fingerprint
from .core.knowledge_store import knowledge_for_event
from .core.db import DB, utcnow
from .core.domains import (
    ABSTAIN_RETRY_HOURS, DOMAINS, horizon_eligible,
)
from .core.stats import brier
from .platforms.polymarket import (
    Polymarket, event_time, is_binary, liquid_enough, market_prob,
    match_domain,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-7s %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("pmlab")

MAX_FORECASTS_PER_CYCLE = 12



def cmd_research(db):
    total = 0
    for key, dom in DOMAINS.items():
        log.info("--- researching: %s ---", dom.label_he)
        total += Researcher(dom, db).run_cycle()
        time.sleep(2)
    log.info("research cycle done: +%d items", total)


def cmd_forecast(db):
    pm = Polymarket()
    fc = Forecaster(db)

    markets = pm.active_markets(pages=4)
    log.info("fetched %d active markets", len(markets))

    made, abstained = 0, 0
    researchers = {k: Researcher(d, db) for k, d in DOMAINS.items()}

    for m in markets:
        if made >= MAX_FORECASTS_PER_CYCLE:
            break
        mid = str(m.get("id"))
        if not is_binary(m) or not liquid_enough(m):
            continue

        domain = match_domain(m, DOMAINS)
        if not domain:
            continue

        question = (m.get("question") or "").strip()
        if not question:
            continue

        # [4.5] האופק נמדד מזמן האירוע, לא מדדליין השוק
        d, time_src = event_time(m)
        if d is None:
            continue
        hours_out = d * 24
        if not horizon_eligible(hours_out):
            continue

        # ---- [דרישה 1] פירוק לצדדים ואימות כיוון ----
        sides = parse_sides(question, m.get("description") or "")
        # אין לנו מקור אמין לזהות הפייבוריט (מחירים חסומים לנו
        # בכוונה), לכן הכיוון נשאר לא-מאומת וה-prior יהיה 0.50.
        sides = verify_direction(sides, reference_side="")

        # ---- [3.1] מחקר ממוקד-אירוע, לפני החיזוי ----
        #
        # קודם הצינור הריץ רק סריקות תחום רחבות והתפלל שיהיה
        # מספיק מידע רלוונטי. עכשיו: צד YES, צד NO, ומשותף.
        eq = event_research_queries(sides, domain)
        if eq:
            researchers[domain].research_event(sides, m)

        # ---- [3.2] טביעת אצבע *לפני* שער הכפילות ----
        #
        # קודם השער בדק את השוק לפני שהראיות נשלפו, ולכן
        # מידע חדש אף פעם לא הגיע אליו. עכשיו: שולפים ראיות,
        # מחשבים טביעת אצבע, ורק אז מחליטים.
        as_of = datetime.now(timezone.utc)
        retr = knowledge_for_event(db, domain=domain, question=question,
                                   as_of=as_of)
        fingerprint = evidence_fingerprint(retr.records, sides)
        if db.has_forecast(pm.name, mid, fingerprint):
            continue

        # ---- [3.2] base rate מחושב בקוד, לא מומצא ע"י המודל ----
        br = get_base_rate(db, domain, question, sides=sides)

        # ---- שלב 1: הסוכן מעריך, עיוור למחיר ----
        result = fc.forecast(
            domain, question,
            str(m.get("endDate") or ""),
            (m.get("description") or "")[:800],
            base_rate=br.value,
            sides=sides,
        )
        if not result:
            continue

        cid = f"{domain}|{str(m.get('endDate') or '')[:10]}"
        locked_at = utcnow()      # [דרישה 6] רגע נעילת התחזית

        # ---- [3.1] הימנעות: נרשמת, לא נזרקת ולא מקריסה ----
        if result.get("abstain"):
            db.insert_row("forecasts", {
                "created_at": utcnow(),
                "domain": domain,
                "platform": pm.name,
                "market_id": mid,
                "condition_id": str(m.get("conditionId") or ""),
                "question": question,
                "end_date": str(m.get("endDate") or ""),
                "cluster_id": cid,
                "as_of": result.get("as_of"),
                "entity_ids": "|".join(result.get("entities", [])),
                "coverage": result.get("coverage"),
                "n_records": result.get("n_records"),
                "n_unique_claims": result.get("n_unique_claims"),
                "n_independent_sources": result.get("n_independent_sources"),
                "coverage_yes_side": result.get("coverage_yes_side"),
                "coverage_no_side": result.get("coverage_no_side"),
                # טביעת האצבע שנשמרת חייבת להיות *אותה אחת* שהשער השתמש בה,
                # אחרת השוואת "השתנה / לא השתנה" משווה בין שני חישובים שונים.
                "evidence_fingerprint": fingerprint,
                "yes_entity": result.get("yes_entity"),
                "no_entity": result.get("no_entity"),
                "reference_class": br.ref_class,
                "forecast_horizon_hours": hours_out,
                "retry_after": (datetime.now(timezone.utc)
                                + timedelta(hours=ABSTAIN_RETRY_HOURS)
                                ).isoformat(),
                "last_checked_at": utcnow(),
                "evidence_version": db.evidence_version(domain),
                "abstained": 1,
                "abstain_reason": (result.get("abstain_reason") or "")[:300],
                "agent_prob": None,
                "status": "abstained",
            })
            abstained += 1
            log.info("ABSTAIN [%s] %s | %s", domain,
                     result.get("abstain_reason", "")[:40], question[:40])
            continue

        # ---- [3.6] כל המטא-דאטה נשמרת, לא נזרקת ----
        fid = db.insert_row("forecasts", {
            "created_at": utcnow(),
            "domain": domain,
            "platform": pm.name,
            "market_id": mid,
            "condition_id": str(m.get("conditionId") or ""),
            "question": question,
            "end_date": str(m.get("endDate") or ""),
            "cluster_id": cid,
            "as_of": result.get("as_of"),
            "entity_ids": "|".join(result.get("entities", [])),
            "coverage": result.get("coverage"),
            "n_records": result.get("n_records"),
            "n_unique_claims": result.get("n_unique_claims"),
            "n_independent_sources": result.get("n_independent_sources"),
            "coverage_yes_side": result.get("coverage_yes_side"),
            "coverage_no_side": result.get("coverage_no_side"),
            "source_diversity": result.get("source_diversity"),
            "freshness_hours": result.get("freshness_hours"),
            # טביעת האצבע שנשמרת חייבת להיות *אותה אחת* שהשער השתמש בה,
                # אחרת השוואת "השתנה / לא השתנה" משווה בין שני חישובים שונים.
                "evidence_fingerprint": fingerprint,
            "yes_entity": result.get("yes_entity"),
            "no_entity": result.get("no_entity"),
            "direction_verified": 1 if result.get("direction_verified") else 0,
            "reference_class": br.ref_class,
            "base_rate_value": br.value,
            "base_rate_source": br.source,
            "base_rate_n": br.n,
            "base_rate_confidence": br.confidence,
            "forecast_horizon_hours": hours_out,
            "last_checked_at": utcnow(),
            "evidence_version": db.evidence_version(domain),
            "abstained": 0,
            "model_version": result.get("model_version"),
            "prompt_hash": result.get("prompt_hash"),
            "agent_prob": result["probability"],
            "agent_confidence": result.get("confidence"),
            "agent_rationale": (
                f"[base_rate={br.value:.3f} src={br.source} n={br.n} "
                f"conf={br.confidence}] {result.get('rationale', '')}")[:1000],
            "knowledge_ids": ",".join(map(str, result.get("knowledge_ids", []))),
            "status": "open",
        })

        # ---- [דרישה 6] שליפה מחדש *אחרי* שהתחזית ננעלה ----
        #
        # קודם נשמר מחיר מתחילת המחזור עם חותמת זמן מאוחרת —
        # אי-התאמה בין המחיר לזמן שנטען עליו. עכשיו שולפים מחדש
        # מיד אחרי הנעילה, ושומרים את זמן השליפה האמיתי.
        fresh = pm.market_by_condition(str(m.get("conditionId") or ""))
        fetched_at = utcnow()
        mp = market_prob(fresh) if fresh else market_prob(m)
        src = "post-lock refetch" if fresh else "cycle snapshot (refetch failed)"
        if mp is not None:
            db.exec(
                """UPDATE forecasts SET market_prob=?, market_locked_at=?,
                   market_fetched_at=?, market_snapshot_source=? WHERE id=?""",
                (mp, locked_at, fetched_at, src, fid),
            )

        made += 1
        delta = f"{result['probability'] - mp:+.3f}" if mp is not None else "n/a"
        log.info("FORECAST [%s] agent=%.3f market=%s Δ=%s br=%.2f cov=%.2f | %s",
                 domain, result["probability"],
                 f"{mp:.3f}" if mp is not None else "?", delta,
                 br.value, result.get("coverage") or 0, question[:44])
        time.sleep(1)

    db.log_run("forecast", None, made)
    log.info("made %d forecasts, %d abstentions", made, abstained)


def cmd_resolve(db):
    pm = Polymarket()
    n = 0
    for f in db.open_forecasts():
        if not f["condition_id"]:
            continue
        m = pm.market_by_condition(f["condition_id"])
        if not m or not m.get("closed"):
            continue

        # [3.8] אותה פונקציית הכרעה בדיוק כמו בבקטסט.
        # void / disputed / תיקו -> None, ולא "הפסיד".
        outcome = actual_outcome(m)
        if outcome is None:
            db.exec("UPDATE forecasts SET status='void', resolved_at=? WHERE id=?",
                    (utcnow(), f["id"]))
            log.info("VOID  [%s] %s", f["domain"], f["question"][:45])
            continue

        ba = brier(f["agent_prob"], outcome)
        bm = brier(f["market_prob"], outcome) if f["market_prob"] is not None else None

        db.exec(
            """UPDATE forecasts SET status='resolved', resolved_at=?, outcome=?,
               brier_agent=?, brier_market=? WHERE id=?""",
            (utcnow(), outcome, ba, bm, f["id"]),
        )
        mark = "✓" if (bm is not None and ba < bm) else "✗"
        log.info("RESOLVE %s [%s] outcome=%d agent_brier=%.3f market_brier=%s | %s",
                 mark, f["domain"], outcome, ba,
                 f"{bm:.3f}" if bm is not None else "n/a", f["question"][:45])
        n += 1
        time.sleep(0.4)

    db.log_run("resolve", None, n)
    log.info("resolved %d forecasts", n)


def main():
    cmd = sys.argv[1] if len(sys.argv) > 1 else "loop"
    db = DB()

    if cmd == "research":
        cmd_research(db)
    elif cmd == "forecast":
        cmd_forecast(db)
    elif cmd == "resolve":
        cmd_resolve(db)
    elif cmd == "loop":
        cycle = 0
        try:
            while True:
                cycle += 1
                log.info("═══ cycle %d ═══", cycle)
                cmd_resolve(db)
                if cycle % 8 == 1:       # מחקר פעם ב-8 מחזורים
                    cmd_research(db)
                cmd_forecast(db)
                log.info("sleeping 1h")
                time.sleep(3600)
        except KeyboardInterrupt:
            log.info("stopped — state saved to pmlab.db")
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
