"""
דוח בקטסט. python -m pmlab.backtest_report

הפיצ'ר המרכזי כאן הוא **גלאי הזיהום**.

ההיגיון: אם המודל באמת לא יודע את התוצאות, הביצועים שלו
בחלון הנקי ובחלון המזוהם צריכים להיות דומים.

אם הוא הרבה יותר טוב בחלון המזוהם — הוא זוכר, לא חוזה.
במקרה כזה כל תוצאה חיובית בבקטסט חסרת ערך.
"""

import numpy as np

from .core.db import DB
from .core.stats import (
    calibration_bins, cluster_robust_test, is_economically_viable,
    skill_score,
)

W = 70


def split_rows(rows):
    clean = [r for r in rows if r["domain"].endswith("|clean")]
    dirty = [r for r in rows if r["domain"].endswith("|contaminated_control")]
    return clean, dirty


def _cluster_of(row):
    keys = row.keys()
    if "cluster_id" in keys and row["cluster_id"]:
        return row["cluster_id"]
    return f"{row['domain']}|{(row['end_date'] or '')[:10]}"


def summarize(rows, label):
    """[3.11 fix] מחזיר גם cid — בלעדיו ההסקה מתייחסת לתצפיות כבלתי-תלויות."""
    if not rows:
        print(f"  {label:<24} —")
        return None
    a = np.array([r["brier_agent"] for r in rows])
    m = np.array([r["brier_market"] for r in rows])
    cid = np.array([_cluster_of(r) for r in rows])
    probs = np.array([r["agent_prob"] for r in rows], dtype=float)
    mkt = np.array([r["market_prob"] for r in rows], dtype=float)
    out = np.array([r["outcome"] for r in rows], dtype=float)
    ss = skill_score(a.mean(), m.mean())
    n_cl = len(np.unique(cid))
    print(f"  {label:<24} n={len(rows):<5} clusters={n_cl:<5} "
          f"agent={a.mean():.4f}  market={m.mean():.4f}  skill={ss:+.3f}")
    return {"a": a, "m": m, "cid": cid, "ss": ss, "n": len(rows),
            "n_clusters": n_cl, "probs": probs, "mkt": mkt, "out": out}


def main():
    db = DB("backtest.db")
    rows = db.resolved()

    print("=" * W)
    print("  BACKTEST REPORT")
    print("=" * W)

    if not rows:
        print("\n  אין נתונים. הרץ קודם: python -m pmlab.backtest")
        print("=" * W)
        return

    clean, dirty = split_rows(rows)

    print("\n[ ביצועים לפי חלון ]")
    c = summarize(clean, "חלון נקי (post-cutoff)")
    d = summarize(dirty, "חלון בקרה (מזוהם)")

    # ---------- גלאי הזיהום ----------
    print("\n[ גלאי זיהום ]")
    print("  אם המודל לא יודע את התוצאות, שני החלונות אמורים להיות דומים.\n")

    if not c or not d:
        print("  צריך נתונים משני החלונות כדי להריץ את הגלאי.")
    else:
        gap = d["ss"] - c["ss"]
        print(f"  skill בחלון המזוהם:  {d['ss']:+.3f}")
        print(f"  skill בחלון הנקי:    {c['ss']:+.3f}")
        print(f"  פער:                 {gap:+.3f}")
        print()
        if gap > 0.15:
            print("  ⚠⚠ זיהום חמור. המודל זוכר תוצאות ולא חוזה אותן.")
            print("     כל ממצא חיובי מהבקטסט חסר ערך.")
        elif gap > 0.07:
            print("  ⚠ סימני זיהום. התייחס לתוצאות הנקיות בזהירות.")
        else:
            print("  ✓ אין עדות לזיהום. הבקטסט נראה תקף.")

    # ---------- הודאות עצמיות ----------
    recalled = [r for r in rows if "recalled=True" in (r["agent_rationale"] or "")]
    print(f"\n  הסוכן הודה שהוא זוכר את התוצאה ב-{len(recalled)}/{len(rows)} מקרים "
          f"({len(recalled)/len(rows)*100:.1f}%)")
    if recalled:
        rc = [r for r in recalled if r["domain"].endswith("|clean")]
        print(f"    מתוכם בחלון הנקי: {len(rc)} "
              f"(אמור להיות נמוך מאוד — אחרת נקודת החיתוך שגויה)")

    # ---------- התוצאה האמיתית: רק החלון הנקי ----------
    print("\n[ התוצאה — חלון נקי בלבד ]")
    if not clean:
        print("  אין נתונים נקיים.")
        print("=" * W)
        return

    clean_c = c
    res = cluster_robust_test(c["a"], c["m"], c["cid"])   # [3.11]
    print(f"  n = {res['n']}")
    print(f"  יתרון ממוצע על השוק: {res['mean_diff']:+.5f}")
    if res["ci_low"] is not None:
        print(f"  95% CI: [{res['ci_low']:+.5f}, {res['ci_high']:+.5f}]")
    print(f"  ניצח ב-{res['win_rate']*100:.0f}% מהתחזיות   p = {res['p_value']:.4f}")
    print()
    if res["ci_low"] is not None and res["ci_low"] > 0:
        print("  ★ הסוכן מדויק יותר מהשוק, ורווח הסמך לא חוצה אפס.")
        print("    זה הממצא. שווה להעמיק.")
    elif res["ci_high"] is not None and res["ci_high"] < 0:
        print("  הסוכן גרוע מהשוק באופן מובהק.")
    else:
        print("  רווח הסמך חוצה אפס — לא ניתן להבחין מרעש.")

    # ---------- כיול ----------
    probs = np.array([r["agent_prob"] for r in clean])
    outs = np.array([r["outcome"] for r in clean])
    print("\n[ כיול בחלון הנקי ]")
    for b in calibration_bins(probs, outs):
        gap = b["actual"] - b["predicted"]
        flag = "  ←" if abs(gap) > 0.15 and b["n"] >= 5 else ""
        print(f"  {b['range']}  n={b['n']:<4} חזה {b['predicted']:.2f} "
              f"בפועל {b['actual']:.2f}  ({gap:+.2f}){flag}")

    # ---- P&L ברמת אשכול ----
    print("\n[ כלכלה — P&L מדומה ברמת אשכול ]")
    from .core.stats import simulated_pnl
    for spread in (0.0, 0.02, 0.04):
        per = []
        for cc in np.unique(clean_c["cid"]):
            mask = clean_c["cid"] == cc
            r_ = simulated_pnl(clean_c["probs"][mask], clean_c["mkt"][mask],
                               clean_c["out"][mask], spread=spread)
            if r_["n_trades"]:
                per.append(r_["mean_pnl"])
        if per:
            arr = np.array(per)
            agg = {"n_trades": len(arr), "mean_pnl": float(arr.mean()),
                   "sd": float(arr.std(ddof=1)) if len(arr) > 1 else 0.0,
                   "roi": 0.0}
            ok, why = is_economically_viable(agg)
            mark = "✓" if ok else "✗"
            print(f"  ספרד {spread:.2f}: {arr.mean():+.4f} "
                  f"על {len(arr)} אשכולות  {mark} {why}")
        else:
            print(f"  ספרד {spread:.2f}: אין עסקאות")

    print("\n[ אזהרה מבנית ]")
    print("  מחיר השוק כאן הוא המחיר האחרון שנסחר — קרוב להכרעה,")
    print("  ולכן מדויק מדי. זה מטה את ההשוואה *נגד* הסוכן.")
    print("  תוצאה חיובית כאן היא לכן משמעותית במיוחד;")
    print("  תוצאה שלילית פחות חד-משמעית.")
    print("=" * W)


if __name__ == "__main__":
    main()
