"""
כיול פוסט-הוק.  ./venv/bin/python -m pmlab.calibrate

הבעיה שנמדדה בריצה הראשונה:
    אמר 0.05  ->  קרה ב-25%
    אמר 0.69  ->  קרה ב-33%
    אמר 0.82  ->  קרה ב-0%

זה ביטחון-יתר קלאסי. המודל דוחף לקצוות, המציאות באמצע.

התיקון אינו לבקש מהמודל להשתפר — זה לא עובד. התיקון הוא
ללמוד את פונקציית העיוות מהנתונים ולהפוך אותה.

שתי שיטות, שתיהן על נתונים קיימים בלבד. אפס עלות API.

  1. כיווץ ליניארי:  p' = 0.5 + k*(p - 0.5)
     פרמטר אחד. עמיד מאוד. קשה להתאים-יתר.

  2. רגרסיה לוגיסטית על log-odds (Platt scaling):
     גמיש יותר, אבל צריך יותר נתונים.

**אזהרה מתודולוגית:** התאמת הכיול על אותם נתונים שמודדים
עליהם היא הטיה. לכן כאן מיושם cross-validation ברמת אשכול —
מתאימים על K-1 אשכולות ומודדים על הנותר.
"""

import numpy as np

from .core.db import DB
from .core.stats import brier, cluster_robust_test, skill_score


# ─────────────────────────────────────────────────────────────
# פונקציות כיול
# ─────────────────────────────────────────────────────────────

def shrink(p: np.ndarray, k: float) -> np.ndarray:
    """כיווץ לכיוון 0.5. k=1 בלי שינוי, k=0 הכל 0.5."""
    return np.clip(0.5 + k * (np.asarray(p) - 0.5), 0.001, 0.999)


def fit_shrink(p: np.ndarray, y: np.ndarray) -> float:
    """מוצא את k שממזער Brier. חיפוש רשת פשוט — פרמטר אחד."""
    ks = np.linspace(0.0, 1.5, 151)
    scores = [np.mean((shrink(p, k) - y) ** 2) for k in ks]
    return float(ks[int(np.argmin(scores))])


def _logit(p):
    p = np.clip(np.asarray(p, dtype=float), 1e-6, 1 - 1e-6)
    return np.log(p / (1 - p))


def fit_platt(p: np.ndarray, y: np.ndarray) -> tuple[float, float]:
    """
    Platt scaling: p' = sigmoid(a * logit(p) + b)
    a<1 מכווץ, b מזיז. מותאם ב-Newton פשוט.
    """
    x = _logit(p)
    a, b = 1.0, 0.0
    for _ in range(100):
        z = a * x + b
        q = 1 / (1 + np.exp(-z))
        g_a = np.sum((q - y) * x)
        g_b = np.sum(q - y)
        w = q * (1 - q) + 1e-9
        h_aa = np.sum(w * x * x) + 1e-6
        h_bb = np.sum(w) + 1e-6
        h_ab = np.sum(w * x)
        det = h_aa * h_bb - h_ab * h_ab
        if abs(det) < 1e-12:
            break
        da = (h_bb * g_a - h_ab * g_b) / det
        db = (h_aa * g_b - h_ab * g_a) / det
        a -= da
        b -= db
        if abs(da) < 1e-9 and abs(db) < 1e-9:
            break
    return float(a), float(b)


def apply_platt(p, a, b):
    return np.clip(1 / (1 + np.exp(-(a * _logit(p) + b))), 0.001, 0.999)


# ─────────────────────────────────────────────────────────────
# הערכה ביושר: cross-validation ברמת אשכול
# ─────────────────────────────────────────────────────────────

def cv_calibrated(p, y, clusters, method="shrink", folds=5, seed=0):
    """
    מתאים על K-1 קפלים ומחיל על הנותר.
    האשכולות לא מתפצלים בין קפלים — אחרת יש דליפה.
    """
    p, y = np.asarray(p, float), np.asarray(y, float)
    clusters = np.asarray(clusters)
    uniq = np.unique(clusters)
    rng = np.random.default_rng(seed)
    rng.shuffle(uniq)
    groups = np.array_split(uniq, min(folds, len(uniq)))

    out = np.empty_like(p)
    params = []
    for g in groups:
        test = np.isin(clusters, g)
        train = ~test
        if train.sum() < 10 or test.sum() == 0:
            out[test] = p[test]
            continue
        if method == "shrink":
            k = fit_shrink(p[train], y[train])
            out[test] = shrink(p[test], k)
            params.append(round(k, 3))
        else:
            a, b = fit_platt(p[train], y[train])
            out[test] = apply_platt(p[test], a, b)
            params.append((round(a, 3), round(b, 3)))
    return out, params


# ─────────────────────────────────────────────────────────────

def _cluster_of(row):
    keys = row.keys()
    if "cluster_id" in keys and row["cluster_id"]:
        return row["cluster_id"]
    return f"{row['domain']}|{(row['end_date'] or '')[:10]}"


def main():
    db = DB("backtest.db")
    rows = [r for r in db.resolved()
            if r["domain"].endswith("|clean")
            and r["market_prob"] is not None
            and r["agent_prob"] is not None]

    W = 66
    print("=" * W)
    print("  כיול פוסט-הוק — אפס עלות API")
    print("=" * W)

    if len(rows) < 30:
        print(f"\n  רק {len(rows)} תחזיות נקיות. צריך לפחות 30.")
        print("=" * W)
        return

    p = np.array([r["agent_prob"] for r in rows], float)
    m = np.array([r["market_prob"] for r in rows], float)
    y = np.array([r["outcome"] for r in rows], float)
    cid = np.array([_cluster_of(r) for r in rows])

    b_raw = ((p - y) ** 2).mean()
    b_mkt = ((m - y) ** 2).mean()

    print(f"\n  n = {len(rows)}   אשכולות = {len(np.unique(cid))}")
    print("\n[ בסיס ]")
    print(f"  סוכן גולמי : Brier {b_raw:.4f}   skill {skill_score(b_raw, b_mkt):+.3f}")
    print(f"  שוק        : Brier {b_mkt:.4f}")

    # ── כמה עיוות יש בפועל ──
    k_full = fit_shrink(p, y)
    a_full, b_full = fit_platt(p, y)
    print("\n[ מה נלמד מהנתונים ]")
    print(f"  מקדם כיווץ אופטימלי k = {k_full:.3f}")
    if k_full < 1:
        print(f"  -> המודל קיצוני פי {1/max(k_full, 0.01):.1f} ממה שהצדיק.")
    print(f"  Platt: a={a_full:.3f}  b={b_full:+.3f}")

    # ── הערכה ביושר ──
    print("\n[ תוצאה אחרי כיול — cross-validation ברמת אשכול ]")
    print("  (מתאים על חלק מהאשכולות, מודד על השאר — בלי דליפה)\n")

    results = {}
    for method, label in (("shrink", "כיווץ ליניארי"), ("platt", "Platt scaling")):
        pc, params = cv_calibrated(p, y, cid, method=method)
        b_cal = ((pc - y) ** 2).mean()
        ss = skill_score(b_cal, b_mkt)
        res = cluster_robust_test((pc - y) ** 2, (m - y) ** 2, cid)
        results[method] = (b_cal, ss, res, pc)
        ci = (f"[{res['ci_low']:+.4f}, {res['ci_high']:+.4f}]"
              if res["ci_low"] is not None else "—")
        print(f"  {label}")
        print(f"    Brier {b_cal:.4f}   skill {ss:+.3f}   "
              f"(היה {skill_score(b_raw, b_mkt):+.3f})")
        print(f"    p={res['p_value']:.4f}   CI {ci}")
        print(f"    פרמטרים לכל קפל: {params}")
        print()

    # ── כיול אחרי תיקון ──
    best = min(results, key=lambda k: results[k][0])
    pc = results[best][3]
    print(f"[ כיול אחרי {best} ]")
    edges = np.linspace(0, 1, 6)
    for i in range(5):
        lo, hi = edges[i], edges[i + 1]
        msk = (pc >= lo) & (pc < hi if i < 4 else pc <= hi)
        if msk.sum() == 0:
            continue
        print(f"  {lo:.1f}-{hi:.1f}  n={int(msk.sum()):<4} "
              f"חזה {pc[msk].mean():.2f}  בפועל {y[msk].mean():.2f}  "
              f"({y[msk].mean() - pc[msk].mean():+.2f})")

    # ── פסק דין ──
    b_cal, ss, res, _ = results[best]
    print("\n[ שורה תחתונה ]")
    gap_before = skill_score(b_raw, b_mkt)
    print(f"  skill לפני : {gap_before:+.3f}")
    print(f"  skill אחרי : {ss:+.3f}")
    closed = (ss - gap_before) / abs(gap_before) * 100 if gap_before else 0
    print(f"  מהפער נסגר : {closed:.0f}%")
    print()
    if ss > -0.05:
        print("  ** הכיול סגר כמעט את כל הפער. שווה להמשיך לאנסמבל **")
    elif ss > gap_before + 0.10:
        print("  * שיפור משמעותי אך עדיין מתחת לשוק. שווה לנסות אנסמבל.")
    else:
        print("  הכיול לא סגר את הפער. הבעיה אינה ביטחון-יתר בלבד —")
        print("  התוכן עצמו חלש. אנסמבל כנראה לא יציל את זה.")
    print("=" * W)


if __name__ == "__main__":
    main()
