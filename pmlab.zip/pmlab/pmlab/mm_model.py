"""
מודל כדאיות לעשיית שוק.  ./venv/bin/python -m pmlab.mm_model

השאלה היחידה: **ההחזר גדול או קטן מעלות הסלקציה השלילית?**

המשוואה, לפי Glosten-Milgrom:

    רווח לעסקה = (1−α)·(ספרד/2)  −  α·E[הפסד למיודע]  +  החזר

  α        = חלק הזרימה שהיא מיודעת (toxic flow)
  ספרד/2   = מה שנגבה מכל צד כשהצד השני לא-מיודע
  ההפסד    = כמה זז המחיר אחרי שמיודע קנה ממך

הנקודה הקריטית: **הספרד אינו רווח.** בשיווי משקל תחרותי הוא
בדיוק מפצה על הסלקציה השלילית, והרווח מתאפס. ההחזר הוא
התוספת שהופכת את זה מאפס לחיובי — או לא.

כל הפרמטרים מתועדים למקור. אין מספרים מומצאים.
"""

import numpy as np

# ─────────────────────────────────────────────────────────────
# פרמטרים — כולם ממקורות שנבדקו
# ─────────────────────────────────────────────────────────────

# פולימרקט, לוח עמלות מ-3.4.2026: עמלת טייקר אחידה 0.05,
# החזר מייקר 0.0125 (כלומר 25% מהעמלה חוזר למייקר).
PM_TAKER_FEE = 0.05
PM_MAKER_REBATE_SHARE = 0.25      # 20% בקריפטו

# Kalshi: החזרים עד 1% במערכת מדורגת, תקרה 7,000$ שבועית.
KALSHI_REBATE_MAX = 0.01
KALSHI_REBATE_WEEKLY_CAP = 7000.0

# עמלות טייקר דינמיות בפולימרקט (ינואר 2026):
# שיא 1.56% ב-0.50, יורד לכיוון אפס בקצוות.
def taker_fee_at(price: float) -> float:
    """
    קירוב לעמלה הדינמית. השיא ב-0.50, דועך לקצוות.
    צורת פעמון פשוטה שמכוילת לשיא המדווח.
    """
    peak = 0.0156
    return peak * (4 * price * (1 - price))     # =peak ב-0.5, =0 בקצוות


# ─────────────────────────────────────────────────────────────
# המודל
# ─────────────────────────────────────────────────────────────

def informed_loss(spread: float, jump: float) -> float:
    """
    כמה מפסידים כשמיודע סוחר נגדך.

    הוא קונה ממך ב-(mid + spread/2), והמחיר האמיתי מתברר
    כ-(mid + jump). ההפסד הוא ההפרש.

    jump = גודל התנועה האינפורמטיבית הטיפוסית.
    """
    return max(0.0, jump - spread / 2)


def profit_per_trade(spread, alpha, jump, rebate_per_trade):
    """
    תוחלת רווח לעסקה, במונחי הסתברות (סנטים לדולר).

      (1−α) · ספרד/2      ← נגבה מזרימה לא-מיודעת
      − α · הפסד למיודע   ← משולם לזרימה מיודעת
      + החזר
    """
    gain = (1 - alpha) * (spread / 2)
    loss = alpha * informed_loss(spread, jump)
    return gain - loss + rebate_per_trade


def breakeven_spread(alpha, jump, rebate_per_trade, hi=0.20):
    """הספרד המינימלי שבו הרווח מתאפס. None אם רווחי תמיד."""
    if profit_per_trade(0.0, alpha, jump, rebate_per_trade) >= 0:
        return 0.0
    lo = 0.0
    for _ in range(200):
        mid = (lo + hi) / 2
        if profit_per_trade(mid, alpha, jump, rebate_per_trade) < 0:
            lo = mid
        else:
            hi = mid
    return hi if hi < 0.199 else None


def rebate_per_trade(price=0.5, share=PM_MAKER_REBATE_SHARE):
    """
    ההחזר שמייקר מקבל על עסקה, במונחי הסתברות.
    הטייקר משלם עמלה, ונתח ממנה חוזר למייקר.
    """
    return taker_fee_at(price) * share


# ─────────────────────────────────────────────────────────────

def main():
    W = 70
    print("=" * W)
    print("  מודל כדאיות לעשיית שוק — האם ההחזר מכסה סלקציה שלילית?")
    print("=" * W)

    reb = rebate_per_trade(0.5)
    print(f"\n[ ההחזר ]")
    print(f"  עמלת טייקר ב-0.50 : {taker_fee_at(0.5)*100:.2f}%")
    print(f"  נתח המייקר         : {PM_MAKER_REBATE_SHARE*100:.0f}%")
    print(f"  החזר לעסקה         : {reb*100:.3f}%  ({reb*10000:.1f} נקודות בסיס)")
    print(f"\n  משמעות: על 1,000$ מחזור, ההחזר לבדו הוא {reb*1000:.2f}$")

    # ── רגישות לרעילות הזרימה ──
    print(f"\n[ הספרד הדרוש לאיזון, לפי רעילות הזרימה ]")
    print("  alpha = איזה חלק מהזרימה מיודעת")
    print("  jump  = כמה זז המחיר אחרי מסחר מיודע\n")
    print(f"  {'alpha':>7} {'jump=0.02':>12} {'jump=0.05':>12} {'jump=0.10':>12}")
    print("  " + "-" * 46)
    for alpha in (0.05, 0.10, 0.20, 0.30, 0.40, 0.50):
        row = []
        for jump in (0.02, 0.05, 0.10):
            be = breakeven_spread(alpha, jump, reb)
            row.append("רווחי תמיד" if be == 0.0 else
                       ("לא ניתן" if be is None else f"{be*100:.1f}%"))
        print(f"  {alpha:>7.0%} {row[0]:>12} {row[1]:>12} {row[2]:>12}")

    # ── מה קורה בלי החזר ──
    print(f"\n[ אותו דבר בלי החזר — כדי לראות כמה ההחזר שווה ]")
    print(f"  {'alpha':>7} {'jump=0.02':>12} {'jump=0.05':>12} {'jump=0.10':>12}")
    print("  " + "-" * 46)
    for alpha in (0.05, 0.10, 0.20, 0.30, 0.40, 0.50):
        row = []
        for jump in (0.02, 0.05, 0.10):
            be = breakeven_spread(alpha, jump, 0.0)
            row.append("רווחי תמיד" if be == 0.0 else
                       ("לא ניתן" if be is None else f"{be*100:.1f}%"))
        print(f"  {alpha:>7.0%} {row[0]:>12} {row[1]:>12} {row[2]:>12}")

    # ── תרחיש מציאותי ──
    print(f"\n[ תרחיש: מה מרוויחים בפועל ]")
    print("  הנחות: ספרד 2%, 200 עסקאות ביום, 50$ לעסקה\n")
    spread, trades_day, size = 0.02, 200, 50.0
    print(f"  {'alpha':>7} {'jump':>7} {'לעסקה':>10} {'ליום':>10} {'לחודש':>11}")
    print("  " + "-" * 48)
    for alpha, jump in ((0.05, 0.03), (0.10, 0.03), (0.20, 0.03),
                        (0.10, 0.06), (0.20, 0.06), (0.30, 0.08)):
        p = profit_per_trade(spread, alpha, jump, reb)
        daily = p * size * trades_day
        print(f"  {alpha:>7.0%} {jump:>7.0%} {p*size:>9.3f}$ "
              f"{daily:>9.2f}$ {daily*30:>10.2f}$")

    # ── הנקודה הקריטית ──
    print(f"\n[ הנקודה הקריטית ]")
    print("  ההחזר מכסה סלקציה שלילית רק כאשר:")
    print("     alpha · max(0, jump − ספרד/2)  <  ההחזר + (1−alpha)·ספרד/2")
    print()
    crit = []
    for alpha in np.arange(0.02, 0.61, 0.02):
        p = profit_per_trade(0.02, alpha, 0.05, reb)
        crit.append((alpha, p))
    flip = next((a for a, p in crit if p < 0), None)
    if flip:
        print(f"  בספרד 2% ו-jump 5%: רווחי עד alpha={flip-0.02:.0%},")
        print(f"  ומעבר לזה מפסיד.")
    else:
        print("  בספרד 2% ו-jump 5%: רווחי בכל רמת רעילות שנבדקה.")

    print(f"\n[ מה שהמודל לא יודע ]")
    print("  • את alpha האמיתי בשווקים שלנו — צריך למדוד VPIN")
    print("  • תדירות מילוי: פקודה שלא מתמלאת לא מרוויחה כלום")
    print("  • סיכון מלאי: פוזיציה פתוחה כשהאירוע מוכרע")
    print("  • תחרות: מייקרים אחרים מצטטים צמוד יותר")
    print()
    print("  המודל אומר **האם זה יכול לעבוד**, לא **שזה יעבוד**.")
    print("=" * W)


if __name__ == "__main__":
    main()
