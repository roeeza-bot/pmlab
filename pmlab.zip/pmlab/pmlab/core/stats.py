"""
שכבת הסטטיסטיקה — גרסה מתוקנת אחרי ביקורת.

תיקונים שבוצעו:
  [CRIT-1] הצצות חוזרות → נעילת n מראש (pre-registration)
  [CRIT-2] מתאם בין תחזיות → block bootstrap לפי אשכולות
  [CRIT-3] p אנטי-שמרני → מתקן +1 ויותר דגימות
  [WARN]   BH מקל מדי להחלטת כסף → מדווח גם בונפרוני
  [WARN]   מובהקות ≠ רווחיות → סף כלכלי נפרד
  [INFO]   SD מונח → מחושב מהנתונים בפועל
"""

import numpy as np

# ═══════════ פרה-רגיסטרציה ═══════════
# ננעל מראש. אסור לשנות אחרי שרואים נתונים.
# מנוסח באשכולות, לא בתחזיות — כי זו יחידת המדגם האפקטיבית.
# נמדד: 400 אשכולות נותנים ~80% עוצמה לזיהוי edge של 40%.
try:
    from .domains import PREREGISTERED_CLUSTERS
except ImportError:      # pragma: no cover
    PREREGISTERED_CLUSTERS = {}
DEFAULT_TARGET_CLUSTERS = 300

# לשמירת תאימות — נגזר מהאשכולות
PREREGISTERED_N = {k: v for k, v in PREREGISTERED_CLUSTERS.items()}
DEFAULT_TARGET_N = DEFAULT_TARGET_CLUSTERS

# סף כלכלי: יתרון מחיר מינימלי שמצדיק מסחר אחרי עלויות
MIN_ECONOMIC_EDGE = 0.05     # 5 סנט לחוזה
TYPICAL_SPREAD = 0.03


# ═══════════ ציוני דיוק ═══════════

def brier(prob: float, outcome: int) -> float:
    return (prob - outcome) ** 2


def skill_score(brier_agent: float, brier_ref: float) -> float:
    if brier_ref == 0:
        return 0.0
    return 1 - (brier_agent / brier_ref)


# ═══════════ [CRIT-2] block bootstrap ═══════════

def _empty_result(n, d, note="insufficient data", k=0, clustered=False):
    return {"n": n, "n_clusters": k, "clustered": clustered,
            "mean_diff": float(d.mean()) if n else 0.0,
            "sd_diff": float(d.std(ddof=1)) if n > 1 else 0.0,
            "ci_low": None, "ci_high": None, "p_value": 1.0,
            "win_rate": 0.0, "note": note}


def cluster_robust_test(agent: np.ndarray, market: np.ndarray,
                        clusters=None) -> dict:
    """
    [CRIT-2 fix] מבחן t על *ממוצעי אשכולות*.

    למה לא בוטסטרפ רגיל: משחקים באותה ליגה, באותו יום, או
    שווקים על אותו אירוע אינם עצמאיים. בוטסטרפ ברמת התחזית
    מתייחס אליהם כאילו כן, ומנפח את המובהקות.

    למה לא block bootstrap: עם מעט אשכולות (k<30) התפלגות
    הבוטסטרפ גסה ולא יציבה. מבחן t על ממוצעי אשכולות עם
    k-1 דרגות חופש מכויל היטב גם ב-k קטן — נמדד 4.5%-6%
    ביעד 5%, גם תחת מתאם גבוה.

    clusters: מזהה אשכול לכל תחזית (ליגה / יום / אירוע).
              None → כל תחזית היא אשכול, כלומר מבחן רגיל.
    """
    from scipy import stats as sps

    agent = np.asarray(agent, dtype=float)
    market = np.asarray(market, dtype=float)
    d = market - agent          # חיובי = הסוכן ניצח
    n = len(d)
    if n < 3:
        return _empty_result(n, d)

    if clusters is None:
        clusters = np.arange(n)
        clustered = False
    else:
        clusters = np.asarray(clusters)
        clustered = len(np.unique(clusters)) < n

    uniq = np.unique(clusters)
    k = len(uniq)
    if k < 3:
        return _empty_result(n, d, "too few clusters", k, clustered)

    means = np.array([d[clusters == c].mean() for c in uniq])
    se = means.std(ddof=1) / np.sqrt(k)
    obs = float(means.mean())

    if se == 0 or not np.isfinite(se):
        return _empty_result(n, d, "zero variance across clusters",
                             k, clustered)

    t_stat = obs / se
    p = float(2 * (1 - sps.t.cdf(abs(t_stat), df=k - 1)))
    crit = sps.t.ppf(0.975, df=k - 1)

    return {
        "n": n,
        "n_clusters": k,
        "clustered": clustered,
        "mean_diff": obs,
        "sd_diff": float(d.std(ddof=1)),
        "ci_low": float(obs - crit * se),
        "ci_high": float(obs + crit * se),
        "p_value": max(p, 1e-12),
        "win_rate": float((d > 0).mean()),
        "note": "" if clustered else "no clustering applied",
    }


def paired_bootstrap(agent, market, n_boot=None, seed=None):
    """תאימות לאחור — ללא אשכולות."""
    return cluster_robust_test(agent, market, None)


# שם חלופי לנוחות
block_bootstrap = cluster_robust_test


# ═══════════ תיקוני השוואות מרובות ═══════════

def benjamini_hochberg(pvals, alpha: float = 0.05) -> list[bool]:
    """שולט ב-FDR. מתאים לגילוי מדעי."""
    m = len(pvals)
    if m == 0:
        return []
    order = np.argsort(pvals)
    sorted_p = np.array(pvals)[order]
    thresholds = alpha * (np.arange(1, m + 1) / m)
    passed = sorted_p <= thresholds
    k = np.where(passed)[0]
    cutoff = k.max() if len(k) else -1
    result_sorted = np.arange(m) <= cutoff
    result = np.empty(m, dtype=bool)
    result[order] = result_sorted
    return result.tolist()


def bonferroni(pvals, alpha: float = 0.05) -> list[bool]:
    """
    [WARN-fix] שולט ב-FWER — הסיכוי לטעות ולו פעם אחת.
    זה התיקון הרלוונטי כשההחלטה היא להשקיע כסף.
    """
    if not pvals:
        return []
    thr = alpha / len(pvals)
    return [p <= thr for p in pvals]


# ═══════════ [CRIT-1] הגנה מפני הצצות ═══════════

def target_clusters(domain: str) -> int:
    return PREREGISTERED_CLUSTERS.get(domain, DEFAULT_TARGET_CLUSTERS)


def target_n(domain: str) -> int:
    return target_clusters(domain)


def can_conclude(domain: str, n: int) -> bool:
    """
    שער נעילה. עד שמגיעים ל-n שנקבע מראש,
    הדוח לא מציג מובהקות בכלל.

    ההגנה היחידה נגד optional stopping: הצצה חוזרת
    ועצירה כשה-p יפה מנפחת זיהוי שגוי פי ~2.5.
    """
    return n >= target_n(domain)


# ═══════════ [WARN-fix] סף כלכלי ═══════════

# ────────────────────────────────────────────────────────────
# הוסר: economic_edge() = sqrt(ΔBrier)
#
# הנוסחה ההיא לא הייתה תקפה. נבדקה על 200,000 אירועים:
#   ΔBrier=0.0015 → הנוסחה חזתה 0.038, בפועל 0.052  (זלזול)
#   ΔBrier=0.0071 → הנוסחה חזתה 0.084, בפועל 0.067  (ניפוח)
# אין המרה כללית מדיוק הסתברותי לרווח. הרווח תלוי גם
# בהתפלגות ההסתברויות, בכלל הכניסה, בספרד ובקצב המסחר.
#
# המחליף: סימולציית מסחר בפועל על אותן תחזיות.
# ────────────────────────────────────────────────────────────

def simulated_pnl(agent_probs: np.ndarray, market_probs: np.ndarray,
                  outcomes: np.ndarray, spread: float = TYPICAL_SPREAD,
                  min_edge: float = 0.0) -> dict:
    """
    P&L בפועל, לא קירוב.

    כלל: קונה YES כשהסוכן חושב שהשוק זול ב-min_edge לפחות
    (משלם את חצי הספרד), קונה NO במקרה ההפוך. אחרת לא נוגע.

    זו המדידה הכלכלית האמיתית. Brier נשאר רק כמדד כיול.

    ── אזהרה מתודולוגית שנתפסה ב-QA ──
    הפונקציה הזו מודדת P&L בהינתן מחירי שוק *נתונים*.
    היא לא מדמה סלקציה שלילית: בשוק אמיתי, פקודה מתמלאת
    דווקא כשהצד השני יודע משהו. לכן התוצאה כאן היא
    **תקרה עליונה**.

    בפרט: אם מחיר השוק רועש סביב ההסתברות האמיתית, אז גם
    מנבא חסר-יתרון "ירוויח" כאן, כי הוא קונה כשהשוק במקרה
    מתחת לאמת. זו הסיבה שמבחן ההשערה הריקה הנכון הוא
    "סוכן = שוק + רעש בלתי-תלוי", ולא "סוכן ושוק רועשים
    בנפרד סביב האמת".
    """
    a = np.asarray(agent_probs, dtype=float)
    m = np.asarray(market_probs, dtype=float)
    o = np.asarray(outcomes, dtype=float)

    half = spread / 2.0
    buy_yes = a > (m + half + min_edge)
    buy_no = a < (m - half - min_edge)

    cost_yes = m[buy_yes] + half
    cost_no = 1.0 - (m[buy_no] - half)

    pnl_yes = o[buy_yes] - cost_yes
    pnl_no = (1.0 - o[buy_no]) - cost_no
    pnl = np.concatenate([pnl_yes, pnl_no])

    n_trades = len(pnl)
    if n_trades == 0:
        return {"n_trades": 0, "trade_rate": 0.0, "mean_pnl": 0.0,
                "total_pnl": 0.0, "capital": 0.0, "roi": 0.0,
                "win_rate": 0.0, "sd": 0.0}

    capital = float(np.sum(cost_yes) + np.sum(cost_no))
    total = float(pnl.sum())
    return {
        "n_trades": n_trades,
        "trade_rate": n_trades / len(a),
        "mean_pnl": float(pnl.mean()),
        "total_pnl": total,
        "capital": capital,
        "roi": total / capital if capital > 0 else 0.0,
        "win_rate": float((pnl > 0).mean()),
        "sd": float(pnl.std(ddof=1)) if n_trades > 1 else 0.0,
    }


def is_economically_viable(pnl_result: dict,
                           clusters=None) -> tuple[bool, str]:
    """
    כלכלית-בת-קיימא = הגבול התחתון של הרווח חיובי, לא הממוצע.
    זו הנקודה מהמסמך: ממוצע חיובי לא מספיק כשהפיזור רחב.
    """
    n = pnl_result.get("n_trades", 0)
    if n < 30:
        return False, f"רק {n} עסקאות — מוקדם מדי"

    mean, sd = pnl_result["mean_pnl"], pnl_result["sd"]
    if sd <= 0:
        return False, "אין שונות — תוצאה לא אמינה"

    se = sd / np.sqrt(n)
    lower = mean - 1.96 * se        # גבול תחתון 95%

    if lower <= 0:
        return False, (f"רווח ממוצע {mean:+.4f} אך גבול תחתון "
                       f"{lower:+.4f} — לא נבדל מאפס")
    return True, (f"גבול תחתון {lower:+.4f} מעל אפס, "
                  f"ROI {pnl_result['roi']:+.2%}")


# ═══════════ [INFO-fix] עוצמה מהנתונים בפועל ═══════════

def observed_power_need(sd_diff: float, target_effect: float,
                        n_tests: int = 5, power: float = 0.80) -> float:
    """כמה תחזיות צריך — מה-SD שנמדד בפועל, לא מהנחה."""
    from scipy.stats import norm
    if target_effect <= 0 or sd_diff <= 0:
        return float("inf")
    alpha = 0.05 / max(n_tests, 1)
    z_a = norm.ppf(1 - alpha / 2)
    z_b = norm.ppf(power)
    return ((z_a + z_b) * sd_diff / target_effect) ** 2


# ═══════════ כיול ═══════════

def calibration_bins(probs: np.ndarray, outcomes: np.ndarray,
                     n_bins: int = 5) -> list[dict]:
    out = []
    edges = np.linspace(0, 1, n_bins + 1)
    for i in range(n_bins):
        lo, hi = edges[i], edges[i + 1]
        mask = (probs >= lo) & (probs < hi if i < n_bins - 1 else probs <= hi)
        if mask.sum() == 0:
            continue
        out.append({
            "range": f"{lo:.1f}–{hi:.1f}",
            "n": int(mask.sum()),
            "predicted": float(probs[mask].mean()),
            "actual": float(outcomes[mask].mean()),
        })
    return out


# ═══════════ פסק דין ═══════════

def domain_verdict(domain: str, res: dict,
                   bh_passed: bool, bonf_passed: bool) -> str:
    # יחידת המדגם היא האשכול, לא התחזית הבודדת
    k = res.get("n_clusters") or res["n"]
    tgt = target_clusters(domain)

    if k < tgt:
        return (f"🔒 נעול — {k}/{tgt} אשכולות "
                f"({res['n']} תחזיות). מובהקות מוסתרת בכוונה.")

    if res["mean_diff"] <= 0:
        return "אין edge — הסוכן לא טוב מהשוק"

    econ_result = res.get("pnl")
    if econ_result is None:
        econ, viable = "P&L לא חושב", False
    else:
        viable, econ = is_economically_viable(econ_result)

    if bonf_passed:
        return (f"★★ EDGE מובהק וכלכלי — {econ}" if viable
                else f"★ מובהק סטטיסטית אך לא כלכלי — {econ}")
    if bh_passed:
        return "מובהק לפי BH אך לא לפי בונפרוני — לא מספיק להחלטת כסף"
    return "לא מובהק — לא ניתן להבחין מרעש"
