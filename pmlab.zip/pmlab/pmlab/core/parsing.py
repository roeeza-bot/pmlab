"""
פרסרים ל-JSON שמגיע ממודל.

מופרד בכוונה למודול חסר-תלויות: אפשר לבדוק אותו
בלי להתקין את ה-SDK, ובלי מפתח API.
"""

import json
import logging

log = logging.getLogger(__name__)


def _strip_fences(text: str, opener: str) -> str:
    t = text.strip()
    if "```" in t:
        for part in t.split("```"):
            p = part.strip()
            if p.startswith("json"):
                p = p[4:].strip()
            if p.startswith(opener):
                return p
    return t


def parse_json_object(text: str) -> dict | None:
    """מחלץ אובייקט JSON מתשובת מודל, גם אם עטוף בטקסט או בגדרות."""
    if not text:
        return None
    t = _strip_fences(text, "{")
    start, end = t.find("{"), t.rfind("}")
    if start == -1 or end == -1 or end < start:
        return None
    try:
        obj = json.loads(t[start:end + 1])
    except json.JSONDecodeError:
        return None
    return obj if isinstance(obj, dict) else None


def parse_json_array(text: str) -> list[dict]:
    """מחלץ מערך JSON. מחזיר רשימה ריקה בכל מקרה של כשל."""
    if not text:
        return []
    t = _strip_fences(text, "[")
    start, end = t.find("["), t.rfind("]")
    if start == -1 or end == -1 or end < start:
        return []
    try:
        data = json.loads(t[start:end + 1])
    except json.JSONDecodeError:
        log.warning("could not parse JSON array from model output")
        return []
    if not isinstance(data, list):
        return []
    return [x for x in data if isinstance(x, dict)]


def extract_probability(data: dict | None) -> float | None:
    """
    שולף ומאמת הסתברות.
    מחזיר None על כל ערך לא חוקי — עדיף לדלג על תחזית
    מאשר לרשום מספר שגוי לניסוי.
    """
    if not data:
        return None
    try:
        p = float(data["probability"])
    except (KeyError, TypeError, ValueError):
        return None
    if not (0.0 <= p <= 1.0):
        return None
    if p != p:  # NaN
        return None
    return p
