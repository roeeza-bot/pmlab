"""
אחסון ידע נכון-לנקודת-זמן (point-in-time).

זה התיקון הקריטי ביותר. הבעיה הקודמת:

    knowledge_for(domain_key, limit=30)

הסוכן קיבל 30 פריטי ידע כלליים על התחום — לא על האירוע,
לא על שני הצדדים, ובלי שום מגבלת זמן. שני כשלים בבת אחת:

  1. **רלוונטיות** — עובדות על ליגה אחרת נכנסו לתחזית
  2. **זיהום זמן** — ידע שנאסף *אחרי* נקודת ההחלטה נכנס פנימה,
     מה שהופך כל בקטסט לחסר ערך

שני התיקונים כאן:
  • הפרדה בין published_at (מתי המידע פורסם) לבין
    collected_at (מתי אנחנו אספנו אותו). רק הראשון קובע.
  • אחזור לפי entity_ids + as_of + רלוונטיות, לא לפי תחום.
"""

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone

SCHEMA_ADDITIONS = """
-- הרחבת טבלת הידע לתמיכה ב-point-in-time
ALTER TABLE knowledge ADD COLUMN published_at TEXT;
ALTER TABLE knowledge ADD COLUMN entity_ids TEXT;
ALTER TABLE knowledge ADD COLUMN source_hash TEXT;
ALTER TABLE knowledge ADD COLUMN claim_key TEXT;
"""


@dataclass
class KnowledgeRecord:
    id: int
    domain: str
    content: str
    published_at: datetime | None
    collected_at: datetime | None
    entity_ids: list[str]
    source_url: str
    salience: float
    relevance: float = 0.0


def parse_ts(s) -> datetime | None:
    if not s:
        return None
    try:
        dt = datetime.fromisoformat(str(s).replace("Z", "+00:00"))
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


# ─────────────────────────────────────────────────────────────
# זיהוי ישויות
# ─────────────────────────────────────────────────────────────

_STOP = {
    "will", "the", "a", "an", "win", "beat", "vs", "versus", "against",
    "match", "game", "fight", "bout", "and", "or", "in", "on", "at",
    "by", "to", "of", "be", "is", "who", "what", "which", "wins",
    "defeat", "defeats", "before", "after", "next", "this",
}


def extract_entities(text: str) -> list[str]:
    """
    מזהה ישויות (קבוצות, שחקנים, לוחמים) מטקסט השאלה.
    גישה שמרנית: מילים באות גדולה ורצפים שלהן.

    לא מושלם — אבל הרבה יותר טוב מלהתעלם מהישויות לגמרי,
    שזה מה שהיה קודם.
    """
    if not text:
        return []
    # רצפים של מילים באות גדולה
    seqs = re.findall(r"\b[A-Z][a-zA-Z'’\-]+(?:\s+[A-Z][a-zA-Z'’\-]+)*", text)
    out = set()
    for seq in seqs:
        toks = [t for t in seq.split() if t.lower() not in _STOP]
        if not toks:
            continue
        full = " ".join(toks)
        if len(full) >= 3:
            out.add(full.lower())
        for t in toks:                      # גם מילים בודדות
            if len(t) >= 4 and t.lower() not in _STOP:
                out.add(t.lower())
    return sorted(out)


def entity_overlap(record_entities: list[str],
                   query_entities: list[str]) -> float:
    """כמה מהישויות בשאלה מופיעות ברשומה. 0..1"""
    if not query_entities:
        return 0.0
    rec = {e.lower() for e in record_entities}
    hits = 0
    for q in query_entities:
        ql = q.lower()
        if ql in rec or any(ql in r or r in ql for r in rec):
            hits += 1
    return hits / len(query_entities)


# ─────────────────────────────────────────────────────────────
# האחזור עצמו
# ─────────────────────────────────────────────────────────────

@dataclass
class RetrievalResult:
    records: list[KnowledgeRecord] = field(default_factory=list)
    n_excluded_by_time: int = 0
    n_excluded_by_entity: int = 0
    coverage: float = 0.0          # איכות הכיסוי — משמש לשער ההימנעות


def knowledge_for_event(db, *, domain: str, question: str,
                        as_of: datetime, entity_ids: list[str] | None = None,
                        top_k: int = 20,
                        min_relevance: float = 0.15) -> RetrievalResult:
    """
    אחזור נכון-לנקודת-זמן, ממוקד-אירוע.

    as_of: נקודת ההחלטה. שום דבר שפורסם אחריה לא ייכנס.
           זה נאכף בקוד, לא בבקשה מהמודל.
    """
    if entity_ids is None:
        entity_ids = extract_entities(question)

    rows = db.q(
        "SELECT * FROM knowledge WHERE domain=? AND superseded=0",
        (domain,),
    )

    kept, dropped_time, dropped_entity = [], 0, 0

    for r in rows:
        keys = r.keys()
        pub = parse_ts(r["published_at"] if "published_at" in keys else None)
        col = parse_ts(r["collected_at"])

        # ── שער הזמן ──
        # אם אין published_at, נופלים חזרה ל-collected_at.
        # אם אין אף אחד — פוסלים. עדיף לאבד רשומה מלזהם ניסוי.
        effective = pub or col
        if effective is None or effective > as_of:
            dropped_time += 1
            continue

        raw_ents = (r["entity_ids"] if "entity_ids" in keys else "") or ""
        rec_ents = [e for e in raw_ents.split("|") if e]
        if not rec_ents:
            rec_ents = extract_entities(r["content"])

        rel = entity_overlap(rec_ents, entity_ids)
        if rel < min_relevance:
            dropped_entity += 1
            continue

        kept.append(KnowledgeRecord(
            id=r["id"], domain=r["domain"], content=r["content"],
            published_at=pub, collected_at=col, entity_ids=rec_ents,
            source_url=r["source_url"] or "",
            salience=float(r["salience"] or 0.5),
            relevance=rel,
        ))

    # דירוג: רלוונטיות לישות קודמת לכל השאר, ואז חשיבות, ואז טריות
    kept.sort(key=lambda k: (k.relevance, k.salience,
                             k.published_at or datetime.min.replace(
                                 tzinfo=timezone.utc)),
              reverse=True)

    selected = kept[:top_k]
    coverage = (sum(k.relevance for k in selected) / len(selected)
                if selected else 0.0)

    return RetrievalResult(
        records=selected,
        n_excluded_by_time=dropped_time,
        n_excluded_by_entity=dropped_entity,
        coverage=coverage,
    )


# ─────────────────────────────────────────────────────────────
# שער הימנעות
# ─────────────────────────────────────────────────────────────

MIN_RECORDS = 4
MIN_COVERAGE = 0.30


def should_abstain(result: RetrievalResult) -> tuple[bool, str]:
    """
    אין מספיק מידע → לא לחזות בכלל.

    זו נקודה מהותית: תחזית חלשה שנכנסת לניסוי מזהמת אותו
    יותר מאשר היעדר תחזית. עדיף פחות החלטות איכותיות.
    """
    if len(result.records) < MIN_RECORDS:
        return True, f"רק {len(result.records)} רשומות רלוונטיות (מינימום {MIN_RECORDS})"
    if result.coverage < MIN_COVERAGE:
        return True, f"כיסוי ישויות {result.coverage:.2f} מתחת ל-{MIN_COVERAGE}"
    return False, ""
