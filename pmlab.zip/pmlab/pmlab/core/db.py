"""
אחסון. הטבלה הקריטית היא forecasts —
היא רושמת את הערכת הסוכן *לפני* שהמחיר נראה, ואת מחיר השוק
בנפרד. בלי ההפרדה הזו כל הניסוי חסר ערך.
"""

import sqlite3
from datetime import datetime, timezone

SCHEMA = """
-- בסיס הידע שהחוקרים צוברים לאורך ימים
CREATE TABLE IF NOT EXISTS knowledge (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    domain TEXT NOT NULL,
    collected_at TEXT NOT NULL,
    published_at TEXT,            -- מתי המידע *פורסם*. זה מה שקובע ל-as_of.
    source_url TEXT,
    source_title TEXT,
    content TEXT NOT NULL,
    entity_ids TEXT,              -- ישויות, מופרדות ב-|
    salience REAL DEFAULT 0.5,
    source_hash TEXT,
    superseded INTEGER DEFAULT 0
);

-- התחזיות. הלב של הניסוי.
CREATE TABLE IF NOT EXISTS forecasts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    domain TEXT NOT NULL,
    platform TEXT NOT NULL,
    market_id TEXT NOT NULL,
    condition_id TEXT,
    question TEXT NOT NULL,
    end_date TEXT,
    cluster_id TEXT,              -- ליגה/יום/אירוע — יחידת המדגם האמיתית
    reference_class TEXT,         -- [3.1] מחלקת הייחוס ל-base rate
    yes_entity TEXT,              -- [דרישה 1] מי מיוצג ע"י YES
    no_entity TEXT,
    direction_verified INTEGER DEFAULT 0,
    n_unique_claims INTEGER,      -- [דרישה 2] טענות ייחודיות, לא רשומות
    n_independent_sources INTEGER,
    coverage_yes_side REAL,       -- [דרישה 3] כיסוי לכל צד בנפרד
    coverage_no_side REAL,
    source_diversity REAL,
    freshness_hours REAL,
    evidence_fingerprint TEXT,    -- [דרישה 5] טריגר לניסיון חוזר
    market_fetched_at TEXT,       -- [דרישה 6] חותמת אמיתית של המחיר
    market_snapshot_source TEXT,
    base_rate_value REAL,
    base_rate_source TEXT,
    base_rate_n INTEGER,
    base_rate_confidence TEXT,
    forecast_horizon_hours REAL,  -- [3.4] אופק קבוע
    as_of TEXT,                   -- נקודת ההחלטה. שום מידע מאוחר יותר לא נכנס.
    entity_ids TEXT,
    coverage REAL,                -- איכות הכיסוי בזמן האחזור
    n_records INTEGER,
    abstained INTEGER DEFAULT 0,
    abstain_reason TEXT,
    retry_after TEXT,             -- [3.3] הימנעות אינה סופית
    last_checked_at TEXT,
    evidence_version INTEGER DEFAULT 0,
    model_version TEXT,
    prompt_hash TEXT,

    -- נרשם ראשון, לפני שנראה מחיר:
    agent_prob REAL,              -- NULL בהימנעות. אין הסתברות ואסור להמציא.
    agent_confidence REAL,
    agent_rationale TEXT,
    knowledge_ids TEXT,

    -- נרשם רק אחרי שההערכה ננעלה:
    market_prob REAL,
    market_locked_at TEXT,

    -- אחרי הכרעה:
    resolved_at TEXT,
    outcome INTEGER,              -- 1 / 0
    brier_agent REAL,
    brier_market REAL,
    status TEXT DEFAULT 'open'    -- open | resolved | void
);

CREATE TABLE IF NOT EXISTS runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    kind TEXT NOT NULL,           -- research | forecast | resolve
    domain TEXT,
    n_items INTEGER,
    notes TEXT
);

CREATE INDEX IF NOT EXISTS idx_fc_status ON forecasts(status);
CREATE INDEX IF NOT EXISTS idx_fc_domain ON forecasts(domain);
CREATE INDEX IF NOT EXISTS idx_kb_domain ON knowledge(domain, superseded);
"""


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


class DB:
    def __init__(self, path: str = "pmlab.db"):
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def q(self, sql, args=()):
        return self.conn.execute(sql, args).fetchall()

    def one(self, sql, args=()):
        return self.conn.execute(sql, args).fetchone()

    def exec(self, sql, args=()):
        cur = self.conn.execute(sql, args)
        self.conn.commit()
        return cur.lastrowid

    # ---------- ידע ----------

    def add_knowledge(self, domain, url, title, content, salience=0.5,
                      published_at=None, entity_ids=None):
        """
        published_at: מתי המידע פורסם במקור. קריטי ל-as_of.
        אם לא ידוע — נשאר None, והאחזור ייפול חזרה ל-collected_at
        (שמרני יותר, כי הוא תמיד מאוחר או שווה).
        """
        import hashlib
        ents = "|".join(entity_ids) if entity_ids else None
        h = hashlib.sha256(content.encode()).hexdigest()[:16]
        return self.exec(
            """INSERT INTO knowledge
               (domain, collected_at, published_at, source_url, source_title,
                content, entity_ids, salience, source_hash)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (domain, utcnow(), published_at, url, title, content,
             ents, salience, h),
        )

    def knowledge_for(self, domain, limit=40):
        return self.q(
            """SELECT * FROM knowledge WHERE domain=? AND superseded=0
               ORDER BY salience DESC, collected_at DESC LIMIT ?""",
            (domain, limit),
        )

    def knowledge_count(self, domain):
        r = self.one(
            "SELECT COUNT(*) n FROM knowledge WHERE domain=? AND superseded=0",
            (domain,),
        )
        return int(r["n"])

    # ---------- תחזיות ----------

    def has_forecast(self, platform, market_id, fingerprint=None):
        """
        [3.3] הימנעות אינה סופית.

        שוק שנמנענו ממנו חייב להיבדק שוב — במיוחד בספורט, שבו
        פציעה, החלפה או שקילה יכולים לשנות הכל שעות לפני האירוע.
        חסימה קבועה הייתה אומרת שהמידע החדש לעולם לא ייבדק.
        """
        row = self.one(
            """SELECT status, retry_after, evidence_fingerprint FROM forecasts
               WHERE platform=? AND market_id=?
               ORDER BY id DESC LIMIT 1""",
            (platform, market_id),
        )
        if row is None:
            return False
        if row["status"] == "void":
            return False
        if row["status"] == "abstained":
            # [דרישה 5] ניסיון חוזר גם לפני תום הצינון,
            # אם הראיות *הספציפיות לאירוע* השתנו.
            if fingerprint and row["evidence_fingerprint"] \
                    and fingerprint != row["evidence_fingerprint"]:
                return False
            if not row["retry_after"]:
                return False
            return utcnow() < row["retry_after"]
        return True

    def evidence_version(self, domain: str) -> int:
        """מונה ראיות. גדל בכל הוספת ידע — מפעיל הערכה מחדש."""
        r = self.one(
            "SELECT COUNT(*) n FROM knowledge WHERE domain=? AND superseded=0",
            (domain,),
        )
        return int(r["n"])

    def open_forecasts(self):
        return self.q("SELECT * FROM forecasts WHERE status='open'")

    def resolved(self, domain=None):
        if domain:
            return self.q(
                "SELECT * FROM forecasts WHERE status='resolved' AND domain=?",
                (domain,),
            )
        return self.q("SELECT * FROM forecasts WHERE status='resolved'")

    def insert_row(self, table: str, data: dict) -> int:
        """
        בונה INSERT מתוך dict.

        למה: ספירה ידנית של סימני שאלה מול שמות עמודות היא
        מקור באגים שקטים. מבחן האורקסטרציה תפס בדיוק את זה —
        "37 values for 38 columns" — שהיה מקריס את הריצה החיה
        על התחזית הראשונה. כאן זה בלתי אפשרי מבנית.
        """
        cols = list(data.keys())
        placeholders = ", ".join("?" for _ in cols)
        sql = (f"INSERT INTO {table} ({', '.join(cols)}) "
               f"VALUES ({placeholders})")
        return self.exec(sql, tuple(data[c] for c in cols))

    def log_run(self, kind, domain=None, n=0, notes=""):
        self.exec(
            "INSERT INTO runs (ts, kind, domain, n_items, notes) VALUES (?,?,?,?,?)",
            (utcnow(), kind, domain, n, notes),
        )
