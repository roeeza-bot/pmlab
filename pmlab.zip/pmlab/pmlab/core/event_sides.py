"""
פירוק אירוע לצדדים, וזיהוי האם הכיוון מאומת.

הבעיה החמורה ביותר שהביקורת זיהתה:

    prior של "פייבוריט מנצח ב-66%" תקף **רק אם צד ה-YES הוא
    הפייבוריט**. המערכת לא רואה מחירים, ולכן לא יודעת מי הפייבוריט.
    אם YES הוא דווקא האנדרדוג, ה-prior מצביע לכיוון ההפוך.

ריכוך לכיוון 0.5 מקטין את גודל הטעות אבל **לא פותר כיוון לא ידוע**.

הכלל שמיושם כאן:
    אם הכיוון לא אומת → 0.50. נקודה.
    אם אומת → ה-prior הכיווני, ואם YES הוא הצד השני → המשלים.
"""

import re
from dataclasses import dataclass, field


@dataclass
class EventSides:
    yes_entity: str = ""
    no_entity: str = ""
    favorite_entity: str = ""      # ריק = לא ידוע
    home_entity: str = ""
    reference_side: str = ""       # favorite / home / ""
    direction_verified: bool = False
    parse_confidence: str = "low"  # high / medium / low
    notes: list[str] = field(default_factory=list)

    @property
    def yes_is_reference(self) -> bool:
        """האם צד ה-YES הוא הצד שה-prior מתייחס אליו."""
        if not self.direction_verified:
            return False
        ref = (self.favorite_entity if self.reference_side == "favorite"
               else self.home_entity)
        return bool(ref) and _same(ref, self.yes_entity)


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9 ]", "", (s or "").lower()).strip()


def _same(a: str, b: str) -> bool:
    na, nb = _norm(a), _norm(b)
    if not na or not nb:
        return False
    return na == nb or na in nb or nb in na


# ─────────────────────────────────────────────────────────────
# פירוק שאלה לצדדים
# ─────────────────────────────────────────────────────────────

_VS = re.compile(r"\b(?:vs\.?|versus|v\.)\b", re.I)
_WIN = re.compile(
    r"^\s*will\s+(.+?)\s+(?:beat|defeat|win against|win over)\s+(.+?)\s*\??$",
    re.I)
_WIN_SIMPLE = re.compile(r"^\s*will\s+(.+?)\s+(?:win|advance|qualify)\b", re.I)

_TRAIL = re.compile(
    r"\s*(?:\bat\b|\bin\b|\bon\b)\s+(?:the\s+)?(?:ufc|fight night|main event|"
    r"co-?main|match|game|bout)[^?]*\??$", re.I)


def parse_sides(question: str, description: str = "") -> EventSides:
    """
    מחלץ את צד ה-YES ואת צד ה-NO מטקסט השאלה.

    שמרני בכוונה: אם לא ברור, מחזיר parse_confidence="low"
    וצדדים ריקים — ואז ה-base rate יהיה 0.50.
    """
    q = (question or "").strip()
    s = EventSides()

    m = _WIN.match(q)
    if m:
        s.yes_entity = _clean(m.group(1))
        s.no_entity = _clean(m.group(2))
        s.parse_confidence = "high"
        return s

    m = _WIN_SIMPLE.match(q)
    if m:
        s.yes_entity = _clean(m.group(1))
        s.parse_confidence = "medium"
        s.notes.append("NO side not identifiable from question text")
        # ננסה למצוא את היריב ב-vs
        parts = _VS.split(q)
        if len(parts) == 2:
            cand = _clean(parts[1])
            if cand and not _same(cand, s.yes_entity):
                s.no_entity = cand
                s.parse_confidence = "high"
        return s

    parts = _VS.split(q)
    if len(parts) == 2:
        s.yes_entity = _clean(parts[0].replace("Will", "", 1))
        s.no_entity = _clean(parts[1])
        s.parse_confidence = "medium"
        s.notes.append("sides inferred from 'vs' only; YES side uncertain")
        return s

    s.notes.append("could not parse sides from question")
    return s


def _clean(t: str) -> str:
    t = _TRAIL.sub("", t or "").strip()
    t = re.sub(r"^(the|will)\s+", "", t, flags=re.I).strip()
    t = re.sub(r"[?.,]+$", "", t).strip()
    return t


# ─────────────────────────────────────────────────────────────
# אימות כיוון
# ─────────────────────────────────────────────────────────────

def verify_direction(sides: EventSides, *, favorite: str | None = None,
                     home: str | None = None,
                     reference_side: str = "") -> EventSides:
    """
    מסמן את הכיוון כמאומת **רק** כשידוע מיהו הצד הכיווני.

    favorite / home חייבים להגיע ממקור אמין חיצוני (למשל דירוג
    רשמי או סדר הופעה בכרטיס) — לא ממחיר השוק, שהמערכת עיוורת אליו.
    """
    if favorite:
        sides.favorite_entity = favorite
    if home:
        sides.home_entity = home

    ref = reference_side or sides.reference_side
    sides.reference_side = ref

    ref_entity = (sides.favorite_entity if ref == "favorite"
                  else sides.home_entity if ref == "home" else "")

    ok = bool(ref_entity) and bool(sides.yes_entity) and bool(sides.no_entity)
    if ok:
        # הצד הכיווני חייב להיות אחד משני הצדדים המזוהים
        ok = _same(ref_entity, sides.yes_entity) or _same(ref_entity,
                                                          sides.no_entity)
    sides.direction_verified = ok
    if not ok:
        sides.notes.append(
            f"direction NOT verified (ref_side={ref!r}, "
            f"ref_entity={ref_entity!r}) — prior must be 0.50")
    return sides


def apply_direction(prior_value: float, sides: EventSides) -> tuple[float, str]:
    """
    מחיל prior כיווני לפי הצד הנכון.

    ההיגיון:
      כיוון לא מאומת   → 0.50
      YES הוא הצד      → prior
      NO הוא הצד       → 1 − prior  (המשלים)
    """
    if not sides.direction_verified:
        return 0.50, "direction unverified → neutral 0.50"
    if sides.yes_is_reference:
        return prior_value, f"YES is the {sides.reference_side}"
    return 1.0 - prior_value, (f"YES is NOT the {sides.reference_side} → "
                               f"complement applied")


# ─────────────────────────────────────────────────────────────
# שאילתות מחקר ממוקדות-אירוע
# ─────────────────────────────────────────────────────────────

def event_research_queries(sides: EventSides, domain: str) -> list[dict]:
    """
    [דרישה 4] מחקר ממוקד-אירוע במקום סריקה רחבה של התחום.

    מחזיר שאילתות מתויגות לפי צד, כדי שנוכל למדוד כיסוי
    לכל צד בנפרד ולא רק ממוצע.
    """
    out = []
    tag = {"mma": "fights injuries layoff training camp weigh-in",
           "mls": "form injuries suspensions lineup",
           "tennis": "form injuries surface record recent matches",
           "euro_tier2": "form injuries suspensions lineup"}.get(
        domain, "recent form injuries news")

    if sides.yes_entity:
        out.append({"side": "yes", "entity": sides.yes_entity,
                    "query": f"{sides.yes_entity} {tag}"})
    if sides.no_entity:
        out.append({"side": "no", "entity": sides.no_entity,
                    "query": f"{sides.no_entity} {tag}"})
    if sides.yes_entity and sides.no_entity:
        out.append({"side": "shared", "entity": "",
                    "query": (f"{sides.yes_entity} {sides.no_entity} "
                              f"matchup head to head event status")})
    return out
