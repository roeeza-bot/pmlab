"""
תחומי המומחיות — מוגדרים על בסיס מחקר, לא ניחוש.

לכל תחום מצורף `prior_note`: מה הספרות אומרת על הסיכוי
לנצח את השוק שם. זה לא קישוט — הסוכן מקבל את זה בפרומפט,
כדי שלא ייכנס לתחום בביטחון מופרז.

מקורות מרכזיים שהנחו את הבחירה:
  • טניס: יחסי ההימור מנצחים Elo ו-ML בדיוק ובכיול.
    ML מגיע לתקרה של ~70% דיוק, ורוב המידע כבר בתוך היחסים.
  • MMA: ~30% מהקרבות עם פייבוריט ברור נגמרים בהפתעה.
    קו-מיין 40% הפתעות מול מיין אוונט 23% — פער מבני.
    יחסי ההימור צודקים ב-66%; מודלים טובים מגיעים ל-69%.
  • כדורגל: מודלים כמעט אף פעם לא מנצחים בוקמייקרים באופן עקבי.
"""

from dataclasses import dataclass, field


@dataclass
class Domain:
    key: str
    label_he: str
    include: list[str]
    exclude: list[str] = field(default_factory=list)
    research_queries: list[str] = field(default_factory=list)
    # מה הסוכן צריך לדעת על עצמו לפני שהוא מנחש
    prior_note: str = ""
    # גורמים מבניים שהספרות זיהתה — הסוכן מתבקש לשקול אותם
    structural_factors: list[str] = field(default_factory=list)
    min_days: float = 0.25
    max_days: float = 60.0


DOMAINS: dict[str, Domain] = {

    # ─────────────────────────────────────────────────────────
    # 1. MMA — התחום עם הליד הכי חזק
    # ─────────────────────────────────────────────────────────
    "mma": Domain(
        key="mma",
        label_he="MMA / UFC",
        include=["ufc", "mma", "fight", "bout", "knockout", "submission",
                 "octagon", "fight night", "bellator", "pfl"],
        exclude=[],
        research_queries=[
            "UFC upcoming card fighters records recent form",
            "UFC fighter injury layoff weight cut news",
            "MMA statistical finish rates striking grappling metrics",
            "UFC card position main event co-main prelim structure",
        ],
        prior_note=(
            "יחסי ההימור ב-MMA צודקים בכ-66% מהמקרים; מודלים "
            "סטטיסטיים טובים מגיעים לכ-69%. הפער קטן אך קיים. "
            "כ-30% מהקרבות עם פייבוריט ברור נגמרים בהפתעה — "
            "זו שונות אמיתית, לא טעות תמחור."
        ),
        structural_factors=[
            "מיקום בכרטיס: קו-מיין מראה ~40% הפתעות מול ~23% במיין אוונט",
            "משקל: מתמודדים כבדים יותר מראים שיעור הפתעות גבוה יותר "
            "('סיכוי המכה') ",
            "פערי תמחור קיצוניים מנבאים שיעור סיום גבוה יותר, לא רק ניצחון",
            "היעדרות ארוכה, שינוי קטגוריית משקל, וקיצוץ משקל בעייתי",
            "התאמת סגנונות: מתאבק מול מכה, ולא רק דירוג כללי",
        ],
        min_days=0.25,
        max_days=30.0,
    ),

    # ─────────────────────────────────────────────────────────
    # 2. MLS — שותפות בלעדית, נפח מובטח, ליגה סגורה וקטנה
    # ─────────────────────────────────────────────────────────
    "mls": Domain(
        key="mls",
        label_he="MLS + Leagues Cup",
        include=["mls", "major league soccer", "leagues cup", "mls cup",
                 "supporters shield"],
        exclude=["premier league", "champions league", "la liga", "serie a"],
        research_queries=[
            "MLS standings recent results form table",
            "MLS injuries suspensions squad availability news",
            "MLS travel schedule congestion designated players",
            "Leagues Cup format qualification rules",
        ],
        prior_note=(
            "מודלים לכדורגל כמעט אף פעם לא מנצחים בוקמייקרים באופן "
            "עקבי. היתרון היחיד האפשרי הוא בגורמים מבניים ייחודיים "
            "ל-MLS שמודלים גלובליים לא מתמחרים היטב."
        ),
        structural_factors=[
            "יתרון ביתי חריג בגלל מרחקי טיסה עצומים ואזורי זמן",
            "כללי תקרת שכר ו-Designated Player יוצרים חוסר איזון סגלים",
            "צפיפות לוח בין ליגה, Leagues Cup וקריאות נבחרת",
            "גובה (Colorado) ומזג אוויר קיצוני",
            "ליגה עם 30 קבוצות בלבד — אפשר להכיר כל סגל לעומק",
        ],
        min_days=0.25,
        max_days=21.0,
    ),

    # ─────────────────────────────────────────────────────────
    # 3. טניס — תדירות גבוהה, אבל פריור שלילי חזק
    # ─────────────────────────────────────────────────────────
    "tennis": Domain(
        key="tennis",
        label_he="טניס (מחוץ לגראנד סלאם)",
        include=["atp", "wta", "tennis", "masters", "open"],
        exclude=["wimbledon", "roland garros", "french open",
                 "us open final", "australian open final"],
        research_queries=[
            "ATP WTA tournament draws surface conditions",
            "tennis player injury retirement withdrawal news",
            "tennis surface specific performance clay hard grass",
            "ATP WTA schedule fatigue back-to-back tournaments",
        ],
        prior_note=(
            "אזהרה: המחקר מראה שיחסי ההימור מנצחים גם Elo וגם "
            "מודלי למידת מכונה בדיוק ובכיול. דיוק ML מגיע לתקרה "
            "של כ-70%, ורוב המידע החזוי כבר גלום ביחסים. "
            "זה התחום עם הפריור הכי שלילי מבין הארבעה — "
            "הוא נכלל בעיקר בגלל תדירות המשחקים הגבוהה."
        ),
        structural_factors=[
            "Elo ספציפי-למשטח מנבא טוב יותר מ-Elo כללי או מדירוג רשמי",
            "עוצמת הגשה, ואחריה שיעור המרת ברייק-פוינט, הם המנבאים החזקים",
            "עייפות: משחקים ברצף, מעבר בין משטחים, טיסות",
            "פרישות ופציעות — שכיחות ומשפיעות מיידית",
        ],
        min_days=0.25,
        max_days=14.0,
    ),

    # ─────────────────────────────────────────────────────────
    # 4. כדורגל אירופי דרג שני
    # ─────────────────────────────────────────────────────────
    "euro_tier2": Domain(
        key="euro_tier2",
        label_he="כדורגל אירופי — דרג שני",
        include=["eredivisie", "primeira liga", "jupiler", "pro league",
                 "super lig", "superliga", "allsvenskan", "eliteserien",
                 "championship", "2. bundesliga", "ligue 2", "serie b"],
        exclude=["premier league", "champions league", "la liga",
                 "serie a", "bundesliga", "ligue 1", "europa league"],
        research_queries=[
            "Eredivisie Primeira Liga standings form recent results",
            "second tier European football injuries transfers news",
            "European league promotion relegation race context",
            "European football fixture congestion continental competition",
        ],
        prior_note=(
            "ליגות דרג שני מקבלות פחות תשומת לב ממודלים מקצועיים, "
            "אבל גם פחות נזילות בשוקי החיזוי. הספרד עלול לבלוע "
            "כל יתרון. שווה לבדוק, בציפיות מתונות."
        ),
        structural_factors=[
            "מוטיבציה א-סימטרית: קבוצה שנאבקת על הישרדות מול קבוצה באמצע",
            "השפעת מכירת שחקנים בחלון ההעברות — חדה יותר בליגות קטנות",
            "יתרון ביתי חזק יותר בליגות עם אצטדיונים צפופים",
            "השתתפות במפעל אירופי יוצרת רוטציה וצפיפות",
            "פחות כיסוי תקשורתי -> מידע על פציעות מגיע לשוק לאט יותר",
        ],
        min_days=0.25,
        max_days=21.0,
    ),
}


# ─────────────────────────────────────────────────────────────
# אופק חיזוי קבוע
# ─────────────────────────────────────────────────────────────
#
# תחזית 25 יום לפני ההכרעה ותחזית 8 שעות לפניה אינן אותה
# אוכלוסייה סטטיסטית. חוזים רק בחלון קבוע.
#
# מוגדר כאן ולא ב-run.py כדי שיהיה ניתן לבדיקה בלי ה-SDK.
FORECAST_HORIZON_HOURS = 24.0
HORIZON_TOLERANCE_HOURS = 6.0     # 18–30 שעות לפני ההכרעה
ABSTAIN_RETRY_HOURS = 6.0


def horizon_eligible(hours_to_event: float) -> bool:
    """האם השוק בתוך חלון האופק. 24 כן, 17 ו-31 לא."""
    if hours_to_event is None:
        return False
    return abs(hours_to_event - FORECAST_HORIZON_HOURS) <= HORIZON_TOLERANCE_HOURS


# מספר האשכולות שנדרש לכל תחום — ננעל מראש.
# ראה pmlab/core/stats.py לחישוב העוצמה שמאחורי המספרים.
PREREGISTERED_CLUSTERS = {
    "mma": 200,          # אשכול = כרטיס. פחות אירועים, אבל נקיים
    "mls": 300,          # אשכול = יום משחקים
    "tennis": 400,       # אשכול = טורניר × יום
    "euro_tier2": 400,   # אשכול = ליגה × יום
}
