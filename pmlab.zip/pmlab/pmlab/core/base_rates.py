"""
חישוב base rate מקוהורטה היסטורית.

הבעיה שזה מתקן: הפרומפט ביקש `base_rate_used`, אבל שום דבר
בקוד לא סיפק מספר. המודל פשוט המציא אחד שנשמע סביר —
וזה בדיוק הסוג של כשל שקשה לתפוס, כי הפלט משכנע.

עכשיו: המספר מחושב כאן, נשלח למודל, והמודל מתבקש להתחיל
ממנו ולהצדיק כל סטייה בעובדה מצוטטת. הוא גם נבדק בדיעבד —
אם המודל שינה אותו, זה מסומן.
"""

import logging
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class BaseRate:
    value: float
    source: str            # מאיזו מחלקת ייחוס
    n: int                 # גודל הקוהורטה
    confidence: str        # high / medium / low
    ref_class: str = ""
    note: str = ""
    directional_warning: str = ""   # [3.1] כשלא ידוע איזה צד הוא YES


# ─────────────────────────────────────────────────────────────
# ברירות מחדל מהספרות — משמשות רק כשאין נתונים היסטוריים
# ─────────────────────────────────────────────────────────────
#
# כל ערך כאן חייב מקור. אם אין מקור — אין ערך.

LITERATURE_PRIORS = {
    # MMA: יחסי ההימור צודקים בכ-66%; ~30% הפתעות מול פייבוריט ברור
    ("mma", "favorite"): (0.66, "MMA closing-line accuracy ~66%", 0),
    ("mma", "main_event"): (0.77, "main events ~23% upset rate", 0),
    ("mma", "co_main"): (0.60, "co-main events ~40% upset rate", 0),

    # כדורגל: יתרון ביתי הוא ה-base rate היציב ביותר
    ("mls", "home"): (0.50, "home win rate incl. draws", 0),
    ("euro_tier2", "home"): (0.45, "home win rate, tier-2 leagues", 0),

    # טניס: הפייבוריט לפי דירוג
    ("tennis", "favorite"): (0.65, "higher-ranked player win rate", 0),
}

GENERIC_PRIOR = 0.50


def classify_question(domain: str, question: str) -> str:
    """מסווג את השאלה למחלקת ייחוס. פשוט בכוונה — ניתן לבדיקה."""
    q = (question or "").lower()

    if domain == "mma":
        if "main event" in q and "co-main" not in q and "co main" not in q:
            return "main_event"
        if "co-main" in q or "co main" in q:
            return "co_main"
        return "favorite"

    if domain in ("mls", "euro_tier2"):
        return "home"

    if domain == "tennis":
        return "favorite"

    return "generic"


def empirical_base_rate(db, domain: str, ref_class: str,
                        min_n: int = 30) -> BaseRate | None:
    """
    base rate מהנתונים שלנו.

    [3.1 fix] הקוד הקודם קיבל ref_class אבל **לא סינן לפיו**.
    התוצאה: 'main event' ו-'co-main' קיבלו בדיוק אותו prior,
    למרות שהפער ביניהם (~23% מול ~40% הפתעות) הוא כל העניין.
    """
    rows = db.q(
        """SELECT outcome FROM forecasts
           WHERE domain=? AND reference_class=?
             AND status='resolved' AND outcome IS NOT NULL""",
        (domain, ref_class),
    )
    if len(rows) < min_n:
        return None
    outcomes = [int(r["outcome"]) for r in rows]
    rate = sum(outcomes) / len(outcomes)
    conf = "high" if len(outcomes) >= 200 else "medium"
    return BaseRate(
        value=rate, source=f"empirical cohort ({domain}/{ref_class})",
        n=len(outcomes), confidence=conf,
        note=f"computed from {len(outcomes)} of our own resolved forecasts "
             f"in reference class '{ref_class}'",
    )


# מחלקות ייחוס שהן כיווניות — ה-prior שלהן תלוי בשאלה
# איזה צד בעולם האמיתי מיוצג ע"י YES.
DIRECTIONAL_CLASSES = {"favorite", "main_event", "co_main", "home"}


def get_base_rate(db, domain: str, question: str, sides=None) -> BaseRate:
    """
    סדר עדיפויות:
      1. הנתונים שלנו, אם יש מספיק
      2. ערך מהספרות למחלקת הייחוס
      3. 0.5 עם confidence נמוך — ואז המודל אמור להימנע

    לעולם לא מחזיר None: היעדר base rate הוא עצמו מידע,
    והוא נכנס למערכת כ-confidence נמוך.
    """
    ref = classify_question(domain, question)

    # קוהורטה אמפירית תקפה רק אם YES קודד עקבית בעבר.
    # במחלקה כיוונית, בלי אימות — לא משתמשים בה.
    if ref not in DIRECTIONAL_CLASSES or (sides and sides.direction_verified):
        emp = empirical_base_rate(db, domain, ref)
        if emp is not None:
            emp.ref_class = ref
            if ref in DIRECTIONAL_CLASSES and sides:
                from .event_sides import apply_direction
                emp.value, why = apply_direction(emp.value, sides)
                emp.source += f" [{why}]"
            return emp

    lit = LITERATURE_PRIORS.get((domain, ref))
    if lit:
        value, src, n = lit

        # ─── דרישה 1: כיוון לא מאומת → 0.50, בלי פשרות ───
        #
        # ריכוך לכיוון 0.5 היה הפתרון הקודם. הוא מקטין את *גודל*
        # הטעות אבל לא פותר *כיוון* לא ידוע: אם YES הוא האנדרדוג,
        # prior של פייבוריט מצביע לכיוון ההפוך, ולא משנה כמה ריככנו.
        if ref in DIRECTIONAL_CLASSES:
            if sides is None or not sides.direction_verified:
                return BaseRate(
                    value=0.50, source="neutral (direction unverified)",
                    n=0, confidence="low", ref_class=ref,
                    note=f"'{ref}' is a directional class; YES side was not "
                         f"verified, so the directional prior was discarded",
                    directional_warning="direction unverified → neutral prior",
                )
            from .event_sides import apply_direction
            value, why = apply_direction(value, sides)
            return BaseRate(value=value, source=f"{src} [{why}]", n=n,
                            confidence="medium", ref_class=ref,
                            note="directional prior, side verified")

        return BaseRate(value=value, source=src, n=n, confidence="medium",
                        ref_class=ref,
                        note="from published literature, not our data")

    return BaseRate(
        value=GENERIC_PRIOR, source="uninformative prior", n=0,
        confidence="low", ref_class=ref,
        note="no reference class matched — treat forecast with suspicion",
    )
