"""
דה-דופליקציה של טענות, וכיסוי נפרד לכל צד.

שתי בעיות שהביקורת הדגימה:

  1. ארבע רשומות יכולות להיות ארבע גרסאות של אותו דיווח מקורי.
     ספירת רשומות יוצרת אשליית עומק ראיות.

  2. ארבע רשומות על צד A ואפס על צד B מייצרות coverage ממוצע
     של 0.50 — שנראה סביר, בעוד שההשוואה חסרה לחלוטין.

הפתרון: לספור **טענות ייחודיות** ו**מקורות בלתי-תלויים**,
ולמדוד כיסוי לכל צד בנפרד.
"""

import re
from dataclasses import dataclass, field
from urllib.parse import urlparse

# ─────────────────────────────────────────────────────────────
# אשכול טענות
# ─────────────────────────────────────────────────────────────

_STOP = {
    "the", "a", "an", "is", "was", "are", "were", "be", "been", "has",
    "have", "had", "will", "would", "and", "or", "but", "in", "on", "at",
    "to", "of", "for", "with", "by", "from", "as", "that", "this", "it",
    "his", "her", "their", "he", "she", "they", "after", "before", "who",
    "reportedly", "according", "said", "says", "reports", "report",
}


def _tokens(text: str) -> set[str]:
    words = re.findall(r"[a-z0-9]+", (text or "").lower())
    return {w for w in words if w not in _STOP and len(w) > 2}


def jaccard(a: set, b: set) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


DUPLICATE_THRESHOLD = 0.55      # מעל זה — אותה טענה בניסוח אחר


def cluster_claims(records, threshold: float = DUPLICATE_THRESHOLD):
    """
    מקבץ רשומות לטענות ייחודיות.

    ניסוח שונה של אותה עובדה נספר כטענה אחת. גישה לקסיקלית
    (Jaccard על טוקנים) — לא מושלמת כמו embeddings, אבל תופסת
    את המקרה השכיח: אתרים שמשכתבים דיווח אחד.
    """
    clusters: list[list] = []
    sigs: list[set] = []

    for r in records:
        sig = _tokens(getattr(r, "content", "") or "")
        placed = False
        for i, existing in enumerate(sigs):
            if jaccard(sig, existing) >= threshold:
                clusters[i].append(r)
                sigs[i] = existing | sig
                placed = True
                break
        if not placed:
            clusters.append([r])
            sigs.append(sig)
    return clusters


# ─────────────────────────────────────────────────────────────
# עצמאות מקורות
# ─────────────────────────────────────────────────────────────

# קבוצות בעלות ידועות — דיווחים מהן אינם עצמאיים זה מזה
_SYNDICATION = {
    "espn.com": "espn", "espn.co.uk": "espn",
    "mmajunkie.usatoday.com": "usatoday", "usatoday.com": "usatoday",
    "bleacherreport.com": "br", "sports.yahoo.com": "yahoo",
    "reuters.com": "reuters", "apnews.com": "ap",
}


def source_group(url: str) -> str:
    """מזהה קבוצת מקורות. דומיין = ברירת מחדל."""
    if not url:
        return "unknown"
    try:
        host = (urlparse(url).netloc or "").lower().replace("www.", "")
    except ValueError:
        return "unknown"
    if not host:
        return "unknown"
    return _SYNDICATION.get(host, host)


def independent_sources(records) -> int:
    groups = {source_group(getattr(r, "source_url", "") or "")
              for r in records}
    groups.discard("unknown")
    # רשומות בלי URL נספרות יחד כמקור אחד לא ידוע, לכל היותר
    has_unknown = any(not (getattr(r, "source_url", "") or "")
                      for r in records)
    return len(groups) + (1 if has_unknown else 0)


# ─────────────────────────────────────────────────────────────
# כיסוי לכל צד
# ─────────────────────────────────────────────────────────────

@dataclass
class EvidenceQuality:
    n_records: int = 0
    n_unique_claims: int = 0
    n_independent_sources: int = 0
    coverage_yes_side: float = 0.0
    coverage_no_side: float = 0.0
    shared_event_coverage: float = 0.0
    source_diversity: float = 0.0
    freshness_hours: float | None = None
    freshness_unknown: bool = False   # אין תאריך פרסום -> לא "טרי"
    n_undated: int = 0
    notes: list[str] = field(default_factory=list)


def _mentions(record, entity: str) -> bool:
    if not entity:
        return False
    ent = re.sub(r"[^a-z0-9 ]", "", entity.lower()).strip()
    if not ent:
        return False
    hay = ((getattr(record, "content", "") or "") + " " +
           " ".join(getattr(record, "entity_ids", []) or [])).lower()
    if ent in hay:
        return True
    # התאמה חלקית: שם משפחה מספיק
    parts = [p for p in ent.split() if len(p) > 3]
    return bool(parts) and all(p in hay for p in parts[-1:])


def assess_evidence(records, sides, now=None) -> EvidenceQuality:
    """מדד איכות ראיות מלא — מחליף את ספירת הרשומות."""
    from datetime import datetime, timezone

    q = EvidenceQuality(n_records=len(records))
    if not records:
        q.notes.append("no records")
        return q

    clusters = cluster_claims(records)
    q.n_unique_claims = len(clusters)
    q.n_independent_sources = independent_sources(records)
    q.source_diversity = (q.n_independent_sources / len(records)
                          if records else 0.0)

    # כיסוי לפי צד — נמדד על טענות ייחודיות, לא על רשומות גולמיות
    reps = [c[0] for c in clusters]
    yes_hits = sum(1 for r in reps if _mentions(r, sides.yes_entity))
    no_hits = sum(1 for r in reps if _mentions(r, sides.no_entity))
    both = sum(1 for r in reps
               if _mentions(r, sides.yes_entity) and _mentions(r, sides.no_entity))

    denom = max(len(reps), 1)
    q.coverage_yes_side = yes_hits / denom
    q.coverage_no_side = no_hits / denom
    q.shared_event_coverage = both / denom

    if not sides.yes_entity:
        q.notes.append("YES side unknown — coverage undefined")
    if not sides.no_entity:
        q.notes.append("NO side unknown — coverage undefined")

    now = now or datetime.now(timezone.utc)

    # טריות נמדדת **רק** מתאריך פרסום אמיתי.
    # collected_at הוא גבול בטיחות נגד דליפה, לא תאריך תוכן:
    # כתבה מלפני שנה שנאספה היום אינה בת אפס שעות.
    pubs = [getattr(r, "published_at", None) for r in records]
    dated = [t for t in pubs if t]
    q.n_undated = len(records) - len(dated)

    if dated:
        q.freshness_hours = (now - max(dated)).total_seconds() / 3600
        if q.n_undated:
            q.notes.append(
                f"{q.n_undated} record(s) have no publication date; "
                f"excluded from freshness")
    else:
        q.freshness_hours = None
        q.freshness_unknown = True
        q.notes.append("no record carries a publication date — "
                       "freshness is unknown, not fresh")

    return q


# ─────────────────────────────────────────────────────────────
# שער ההימנעות — מבוסס איכות, לא כמות
# ─────────────────────────────────────────────────────────────

MIN_UNIQUE_CLAIMS = 3
MIN_INDEPENDENT_SOURCES = 2
MIN_SIDE_COVERAGE = 0.25


def should_abstain(q: EvidenceQuality, sides) -> tuple[bool, str]:
    """
    [דרישות 2+3] הימנעות על בסיס טענות ייחודיות ומקורות בלתי-תלויים,
    וכיסוי מינימלי **לכל צד בנפרד**.
    """
    if q.n_unique_claims < MIN_UNIQUE_CLAIMS:
        return True, (f"רק {q.n_unique_claims} טענות ייחודיות מתוך "
                      f"{q.n_records} רשומות (מינימום {MIN_UNIQUE_CLAIMS})")

    if q.n_independent_sources < MIN_INDEPENDENT_SOURCES:
        return True, (f"רק {q.n_independent_sources} מקורות בלתי-תלויים "
                      f"(מינימום {MIN_INDEPENDENT_SOURCES})")

    if not sides.yes_entity or not sides.no_entity:
        return True, "לא ניתן לזהות את שני הצדדים — כיסוי לא מדיד"

    if q.coverage_yes_side < MIN_SIDE_COVERAGE:
        return True, (f"כיסוי צד YES {q.coverage_yes_side:.2f} מתחת ל-"
                      f"{MIN_SIDE_COVERAGE}")

    if q.coverage_no_side < MIN_SIDE_COVERAGE:
        return True, (f"כיסוי צד NO {q.coverage_no_side:.2f} מתחת ל-"
                      f"{MIN_SIDE_COVERAGE} — ראיות חד-צדדיות")

    return False, ""


# ─────────────────────────────────────────────────────────────
# טביעת אצבע לראיות — לטריגר ניסיון חוזר
# ─────────────────────────────────────────────────────────────

def evidence_fingerprint(records, sides) -> str:
    """
    [דרישה 5] טביעת אצבע **ספציפית לאירוע**.

    מידע חדש על ליגה אחרת לא אמור לפתוח מחדש את השוק הזה.
    רק טענה חדשה על אחד משני הצדדים.
    """
    import hashlib

    relevant = [r for r in records
                if _mentions(r, sides.yes_entity) or _mentions(r, sides.no_entity)]
    clusters = cluster_claims(relevant)
    keys = sorted(
        f"{sorted(_tokens(getattr(c[0], 'content', '')))[:8]}"
        f"|{source_group(getattr(c[0], 'source_url', '') or '')}"
        for c in clusters
    )
    blob = "||".join(keys) + f"||{_norm_e(sides.yes_entity)}|{_norm_e(sides.no_entity)}"
    return hashlib.sha256(blob.encode()).hexdigest()[:20]


def _norm_e(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())
