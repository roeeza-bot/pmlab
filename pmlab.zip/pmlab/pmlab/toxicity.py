"""
מודד רעילות זרימה.  ./venv/bin/python -m pmlab.toxicity

השאלה: **האם alpha בשווקים שנגישים לנו מתחת ל-26%?**

זה הסף שמודל עשיית השוק החזיר. מתחתיו — ההחזר מכסה את
הסלקציה השלילית. מעליו — מפסידים.

השיטה: VPIN (Easley, de Prado, O'Hara).
לא סופרים עסקאות לפי זמן אלא לפי **נפח**. כל "דלי" מכיל
כמות נפח קבועה, ומודדים את חוסר-האיזון בין קנייה למכירה בתוכו.

    VPIN = ממוצע |V_buy − V_sell| / V_total  על פני N דליים

חוסר-איזון גבוה = מישהו דוחף לכיוון אחד = זרימה מיודעת.
חוסר-איזון נמוך = רעש דו-כיווני = זרימה בטוחה למייקר.

**למה זה חשוב במיוחד כאן:** המחקר שקראנו מצא שנתח ה-fill
של עושי שוק מתאם חיובית עם VPIN (ρ=+0.44). כלומר עושי שוק
נוטים לשבת דווקא היכן שרעיל. אם זה נכון גם בשווקים שלנו,
המודל אומר מראש שזה מפסיד.

  ./venv/bin/python -m pmlab.toxicity collect 120
  ./venv/bin/python -m pmlab.toxicity report
"""

import logging
import os
import sqlite3
import sys
import time
from datetime import datetime, timedelta, timezone

import numpy as np
import requests

log = logging.getLogger(__name__)

CLOB = "https://clob.polymarket.com"
GAMMA = "https://gamma-api.polymarket.com"

DB = "toxicity.db"

# ── פרמטרים ──
BUCKET_VOLUME = 500.0     # דולר לדלי. קטן מספיק לשווקים דקים.
N_BUCKETS = 50            # חלון ה-VPIN
POLL_SECONDS = 45
MIN_LIQUIDITY = 5000.0

# הסף מהמודל: מעליו עשיית שוק מפסידה בספרד 2%
ALPHA_THRESHOLD = 0.26

SCHEMA = """
CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    market_id TEXT NOT NULL,
    token_id TEXT NOT NULL,
    question TEXT,
    category TEXT,
    best_bid REAL, best_ask REAL, mid REAL, spread REAL,
    bid_depth REAL, ask_depth REAL
);
CREATE INDEX IF NOT EXISTS idx_books ON books(token_id, ts);

CREATE TABLE IF NOT EXISTS flow (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    token_id TEXT NOT NULL,
    d_mid REAL,           -- תנועת המיד מאז הדגימה הקודמת
    buy_vol REAL,         -- נפח מסווג כקנייה
    sell_vol REAL
);
CREATE INDEX IF NOT EXISTS idx_flow ON flow(token_id, ts);
"""


# ─────────────────────────────────────────────────────────────

class Poly:
    def __init__(self):
        self.s = requests.Session()
        self.s.headers.update({"User-Agent": "pmlab-toxicity/1.0"})

    def _get(self, base, path, params=None, retries=3):
        for i in range(retries):
            try:
                r = self.s.get(f"{base}{path}", params=params, timeout=20)
                if r.status_code == 429:
                    time.sleep(2 ** i)
                    continue
                r.raise_for_status()
                return r.json()
            except Exception as e:  # noqa: BLE001
                if i == retries - 1:
                    log.debug("GET %s failed: %s", path, e)
                time.sleep(1.0 * (i + 1))
        return None

    def active_markets(self, pages=2):
        out = []
        for i in range(pages):
            b = self._get(GAMMA, "/markets", {
                "active": "true", "closed": "false", "archived": "false",
                "limit": 250, "offset": i * 250,
                "order": "volume24hr", "ascending": "false",
            })
            if not b:
                break
            out.extend(b)
        return out

    def book(self, token_id):
        return self._get(CLOB, "/book", {"token_id": token_id})


def top_of_book(book):
    if not book:
        return None
    bids = book.get("bids") or []
    asks = book.get("asks") or []
    if not bids or not asks:
        return None
    try:
        bb, ba = float(bids[-1]["price"]), float(asks[-1]["price"])
        bd = sum(float(l["price"]) * float(l["size"]) for l in bids[-5:])
        ad = sum(float(l["price"]) * float(l["size"]) for l in asks[-5:])
    except (KeyError, ValueError, IndexError):
        return None
    if bb >= ba:
        return None
    return {"bid": bb, "ask": ba, "mid": (bb + ba) / 2,
            "spread": ba - bb, "bid_depth": bd, "ask_depth": ad}


# ─────────────────────────────────────────────────────────────
# סיווג זרימה
# ─────────────────────────────────────────────────────────────

def classify_flow(d_mid, d_depth_bid, d_depth_ask, sigma):
    """
    סיווג בולק לפי Easley-de Prado-O'Hara.

    אין לנו טייפ-בטייפ עם דגל צד, אז מסווגים לפי **תנועת המחיר**:
    המיד עלה → הזרימה נטתה לקנייה, ולהפך. החלוקה רציפה לפי
    התפלגות נורמלית, לא בינארית — זו הנקודה של הסיווג הבולק.

    מחזיר (חלק_קנייה, חלק_מכירה) שמסתכמים ל-1.
    """
    from scipy.stats import norm
    if sigma <= 0:
        return 0.5, 0.5
    z = d_mid / sigma
    buy = float(norm.cdf(z))
    return buy, 1.0 - buy


def vpin(buys, sells):
    """
    VPIN = ממוצע חוסר-האיזון היחסי על פני הדליים.
    0 = מאוזן לחלוטין. 1 = כל הזרימה בכיוון אחד.
    """
    b, s = np.asarray(buys, float), np.asarray(sells, float)
    tot = b + s
    ok = tot > 0
    if not ok.any():
        return None
    return float(np.mean(np.abs(b[ok] - s[ok]) / tot[ok]))


# ─────────────────────────────────────────────────────────────

def collect(minutes=120):
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    conn.commit()

    pm = Poly()
    deadline = datetime.now(timezone.utc) + timedelta(minutes=minutes)
    prev = {}
    cycle = 0

    import json as _j
    while datetime.now(timezone.utc) < deadline:
        cycle += 1
        markets = pm.active_markets(pages=2)
        tracked = 0

        for m in markets:
            try:
                liq = float(m.get("liquidityNum") or m.get("liquidity") or 0)
            except (TypeError, ValueError):
                continue
            if liq < MIN_LIQUIDITY:
                continue

            toks = m.get("clobTokenIds")
            if isinstance(toks, str):
                try:
                    toks = _j.loads(toks)
                except _j.JSONDecodeError:
                    continue
            if not isinstance(toks, list) or not toks:
                continue

            tid = str(toks[0])
            tob = top_of_book(pm.book(tid))
            if not tob:
                continue

            now = datetime.now(timezone.utc).isoformat()
            conn.execute(
                """INSERT INTO books (ts, market_id, token_id, question,
                   category, best_bid, best_ask, mid, spread,
                   bid_depth, ask_depth) VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
                (now, str(m.get("id")), tid, (m.get("question") or "")[:200],
                 (m.get("category") or "?"), tob["bid"], tob["ask"],
                 tob["mid"], tob["spread"], tob["bid_depth"], tob["ask_depth"]))

            if tid in prev:
                p = prev[tid]
                d_mid = tob["mid"] - p["mid"]
                # נפח מקורב: שינוי בעומק הספר
                vol = abs(tob["bid_depth"] - p["bid_depth"]) + \
                      abs(tob["ask_depth"] - p["ask_depth"])
                if vol > 0:
                    hist = conn.execute(
                        "SELECT d_mid FROM flow WHERE token_id=? "
                        "ORDER BY ts DESC LIMIT 30", (tid,)).fetchall()
                    ds = [r["d_mid"] for r in hist if r["d_mid"] is not None]
                    sigma = float(np.std(ds)) if len(ds) >= 5 else 0.01
                    bfrac, sfrac = classify_flow(d_mid, 0, 0, max(sigma, 1e-4))
                    conn.execute(
                        "INSERT INTO flow (ts, token_id, d_mid, buy_vol, "
                        "sell_vol) VALUES (?,?,?,?,?)",
                        (now, tid, d_mid, vol * bfrac, vol * sfrac))
            prev[tid] = tob
            tracked += 1
            time.sleep(0.15)

        conn.commit()
        log.info("cycle %d: tracked %d markets", cycle, tracked)
        time.sleep(POLL_SECONDS)

    conn.close()


# ─────────────────────────────────────────────────────────────

def report():
    if not os.path.exists(DB):
        print("\n  אין נתונים. הרץ: toxicity collect\n")
        return
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row

    W = 70
    print("=" * W)
    print("  מודד רעילות — האם alpha מתחת ל-26%?")
    print("=" * W)

    nb = conn.execute("SELECT COUNT(*) c FROM books").fetchone()["c"]
    nf = conn.execute("SELECT COUNT(*) c FROM flow").fetchone()["c"]
    ntok = conn.execute(
        "SELECT COUNT(DISTINCT token_id) c FROM flow").fetchone()["c"]
    print(f"\n  תמונות ספר: {nb}   דגימות זרימה: {nf}   שווקים: {ntok}")

    if nf < 50:
        print("\n  מעט מדי דגימות. צריך זמן ריצה ארוך יותר.")
        print("=" * W)
        return

    # ── VPIN לכל שוק ──
    rows = conn.execute(
        """SELECT token_id, COUNT(*) n FROM flow
           GROUP BY token_id HAVING n >= 10""").fetchall()

    results = []
    for r in rows:
        tid = r["token_id"]
        fl = conn.execute(
            "SELECT buy_vol, sell_vol FROM flow WHERE token_id=? "
            "ORDER BY ts", (tid,)).fetchall()
        buys = [x["buy_vol"] for x in fl]
        sells = [x["sell_vol"] for x in fl]
        v = vpin(buys[-N_BUCKETS:], sells[-N_BUCKETS:])
        if v is None:
            continue
        bk = conn.execute(
            "SELECT question, category, AVG(spread) sp, AVG(mid) md, "
            "AVG(bid_depth+ask_depth) dep FROM books WHERE token_id=?",
            (tid,)).fetchone()
        results.append({
            "vpin": v, "spread": bk["sp"] or 0, "mid": bk["md"] or 0,
            "depth": bk["dep"] or 0, "q": (bk["question"] or "")[:42],
            "cat": bk["category"] or "?", "n": r["n"],
        })

    if not results:
        print("\n  לא ניתן לחשב VPIN. צריך יותר דגימות לכל שוק.")
        print("=" * W)
        return

    vs = np.array([x["vpin"] for x in results])
    print(f"\n[ VPIN — התפלגות על פני {len(results)} שווקים ]")
    print(f"  חציון  : {np.median(vs):.3f}")
    print(f"  ממוצע  : {vs.mean():.3f}")
    print(f"  רבעון 1: {np.percentile(vs,25):.3f}   "
          f"רבעון 3: {np.percentile(vs,75):.3f}")
    print(f"\n  מתחת לסף {ALPHA_THRESHOLD:.0%}: "
          f"{(vs < ALPHA_THRESHOLD).mean()*100:.0f}% מהשווקים")

    # ── לפי קטגוריה ──
    print(f"\n[ לפי קטגוריה ]")
    cats = {}
    for x in results:
        cats.setdefault(x["cat"], []).append(x)
    print(f"  {'קטגוריה':<18} {'n':>4} {'VPIN':>7} {'ספרד':>8} {'מתחת לסף':>10}")
    print("  " + "-" * 52)
    for c, lst in sorted(cats.items(), key=lambda x: -len(x[1]))[:10]:
        v = np.array([y["vpin"] for y in lst])
        sp = np.mean([y["spread"] for y in lst])
        print(f"  {c[:18]:<18} {len(lst):>4} {v.mean():>7.3f} "
              f"{sp*100:>7.2f}% {(v<ALPHA_THRESHOLD).mean()*100:>9.0f}%")

    # ── האם ספרד מפצה על רעילות ──
    print(f"\n[ האם הספרד מפצה על הרעילות? ]")
    sp = np.array([x["spread"] for x in results])
    if len(vs) > 5 and sp.std() > 0:
        corr = float(np.corrcoef(vs, sp)[0, 1])
        print(f"  מתאם VPIN↔ספרד: {corr:+.3f}")
        if corr > 0.2:
            print("  ✓ ספרד רחב יותר היכן שרעיל — השוק מתמחר את הסיכון.")
        elif corr < -0.2:
            print("  ⚠ ספרד צר דווקא היכן שרעיל — מלכודת למייקר.")
        else:
            print("  אין קשר. הספרד לא מפצה על רעילות.")

    # ── פסק דין כלכלי ──
    from .mm_model import profit_per_trade, rebate_per_trade
    reb = rebate_per_trade(0.5)
    print(f"\n[ פסק דין — רווח לעסקה בפועל ]")
    print("  (בהנחת jump=5%, לפי הספרד והרעילות שנמדדו)\n")
    profitable = 0
    for x in results:
        p = profit_per_trade(x["spread"], x["vpin"], 0.05, reb)
        x["profit"] = p
        if p > 0:
            profitable += 1
    ps = np.array([x["profit"] for x in results])
    print(f"  רווחיים: {profitable}/{len(results)} "
          f"({profitable/len(results)*100:.0f}%)")
    print(f"  רווח חציוני לעסקה: {np.median(ps)*100:+.3f}%")

    best = sorted(results, key=lambda x: -x["profit"])[:8]
    print(f"\n[ השווקים הטובים ביותר ]")
    print(f"  {'VPIN':>6} {'ספרד':>7} {'רווח':>8}  שאלה")
    print("  " + "-" * 60)
    for x in best:
        print(f"  {x['vpin']:>6.3f} {x['spread']*100:>6.2f}% "
              f"{x['profit']*100:>+7.3f}%  {x['q']}")

    print(f"\n[ שורה תחתונה ]")
    med_v = float(np.median(vs))
    if med_v < ALPHA_THRESHOLD and profitable / len(results) > 0.5:
        print(f"  ★ הרעילות החציונית {med_v:.2f} מתחת לסף {ALPHA_THRESHOLD}.")
        print("    עשיית שוק יכולה לעבוד. הצעד הבא: לבדוק תדירות מילוי.")
    elif med_v < ALPHA_THRESHOLD:
        print(f"  רעילות {med_v:.2f} סבירה, אבל הספרדים צרים מדי")
        print("  ברוב השווקים. צריך לברור.")
    else:
        print(f"  הרעילות החציונית {med_v:.2f} מעל הסף {ALPHA_THRESHOLD}.")
        print("  עשיית שוק בשווקים האלה מפסידה. ההחזר לא מכסה.")

    print(f"\n[ מגבלות ]")
    print("  • הנפח מקורב משינוי בעומק הספר, לא מטייפ-בטייפ אמיתי")
    print("  • jump=5% הוא הנחה, לא נמדד")
    print("  • VPIN רגיש לגודל הדלי ולאורך החלון")
    print("=" * W)


def main():
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s %(levelname)-7s %(message)s",
                        datefmt="%H:%M:%S")
    cmd = sys.argv[1] if len(sys.argv) > 1 else "report"
    if cmd == "collect":
        collect(int(sys.argv[2]) if len(sys.argv) > 2 else 120)
    else:
        report()


if __name__ == "__main__":
    main()
