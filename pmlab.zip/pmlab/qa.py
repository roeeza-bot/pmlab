"""
QA. python3 qa.py

בודק כל מודול בנפרד על מקרי קצה, כולל קלטים משובשים
מה-API, ערכים חריגים, ושגיאות לוגיות בסטטיסטיקה.
"""

import json
import os
import sys
import traceback
from datetime import datetime, timedelta, timezone

import numpy as np

sys.path.insert(0, ".")

PASS, FAIL = [], []


def check(name, fn):
    try:
        fn()
        PASS.append(name)
        print(f"  ✓ {name}")
    except AssertionError as e:
        FAIL.append((name, str(e)))
        print(f"  ✗ {name}\n      {e}")
    except Exception as e:  # noqa: BLE001
        FAIL.append((name, f"{type(e).__name__}: {e}"))
        print(f"  ✗ {name}\n      {type(e).__name__}: {e}")
        traceback.print_exc(limit=2)


# ═════════ STATS ═════════
def qa_stats():
    from pmlab.core.stats import (
        benjamini_hochberg, bonferroni, brier, calibration_bins,
        cluster_robust_test, paired_bootstrap,
        skill_score, target_clusters,
    )
    print("\n[ stats ]")

    def t_brier():
        assert brier(1.0, 1) == 0.0, "perfect forecast must score 0"
        assert brier(0.0, 1) == 1.0, "worst forecast must score 1"
        assert abs(brier(0.5, 1) - 0.25) < 1e-9, "coin flip must score 0.25"
        assert abs(brier(0.5, 0) - 0.25) < 1e-9
    check("brier: known values", t_brier)

    def t_skill():
        assert skill_score(0.1, 0.2) > 0, "lower brier = positive skill"
        assert skill_score(0.2, 0.1) < 0
        assert abs(skill_score(0.2, 0.2)) < 1e-9, "equal = zero skill"
        assert skill_score(0.1, 0.0) == 0.0, "div-by-zero must be handled"
    check("skill_score: sign + zero-div", t_skill)

    def t_boot_empty():
        r = paired_bootstrap(np.array([]), np.array([]))
        assert r["n"] == 0
        assert r["p_value"] == 1.0, "empty must not claim significance"
        r1 = paired_bootstrap(np.array([0.1]), np.array([0.2]))
        assert r1["p_value"] == 1.0, "n=1 must not claim significance"
    check("bootstrap: empty/singleton safe", t_boot_empty)

    def t_boot_null():
        # אין הבדל אמיתי -> p גבוה
        rng = np.random.default_rng(5)
        x = rng.random(200) * 0.3
        r = paired_bootstrap(x, x.copy())
        assert r["p_value"] > 0.5, f"identical arrays gave p={r['p_value']}"
        assert abs(r["mean_diff"]) < 1e-9
    check("bootstrap: identical inputs -> null", t_boot_null)

    def t_boot_real():
        # הבדל גדול וברור -> p נמוך
        rng = np.random.default_rng(7)
        agent = rng.normal(0.10, 0.02, 300)
        market = rng.normal(0.20, 0.02, 300)
        r = paired_bootstrap(agent, market)
        assert r["mean_diff"] > 0, "market worse -> positive diff"
        assert r["p_value"] < 0.01, f"obvious effect gave p={r['p_value']}"
        assert r["ci_low"] > 0, "CI should exclude zero"
    check("bootstrap: detects obvious effect", t_boot_real)

    def t_boot_direction():
        # ודא שהסימן לא הפוך
        agent = np.full(50, 0.05)    # סוכן טוב (brier נמוך)
        market = np.full(50, 0.25)   # שוק גרוע
        r = paired_bootstrap(agent, market)
        assert r["mean_diff"] > 0, "SIGN BUG: better agent must give positive"
        assert r["win_rate"] == 1.0
    check("bootstrap: sign convention correct", t_boot_direction)

    def t_bh_basic():
        assert benjamini_hochberg([]) == []
        # כולם מובהקים מאוד
        assert all(benjamini_hochberg([0.0001] * 5))
        # אף אחד לא
        assert not any(benjamini_hochberg([0.9, 0.8, 0.7, 0.6, 0.5]))
    check("BH: trivial cases", t_bh_basic)

    def t_bh_order():
        # התוצאה חייבת להתאים לסדר הקלט, לא לסדר הממוין
        pv = [0.9, 0.001, 0.8, 0.7, 0.6]
        res = benjamini_hochberg(pv, 0.05)
        assert res[1] is True, "ORDER BUG: p=0.001 at index 1 must pass"
        assert res[0] is False, "ORDER BUG: p=0.9 must fail"
        assert sum(res) == 1
    check("BH: preserves input ordering", t_bh_order)

    def t_bh_stepup():
        # BH הוא step-up: אם ה-k הגדול עובר, כל מה שמתחתיו עובר
        pv = [0.001, 0.02, 0.03, 0.9, 0.95]
        res = benjamini_hochberg(pv, 0.05)
        idx = [i for i, v in enumerate(res) if v]
        assert 0 in idx and 1 in idx and 2 in idx, f"step-up failed: {res}"
        assert 3 not in idx and 4 not in idx
    check("BH: step-up property", t_bh_stepup)

    def t_bh_conservative():
        # BH לעולם לא פחות שמרני מ-alpha לא מתוקן
        rng = np.random.default_rng(3)
        for _ in range(200):
            pv = list(rng.random(5))
            bh = benjamini_hochberg(pv, 0.05)
            raw = [p < 0.05 for p in pv]
            assert sum(bh) <= sum(raw), "BH passed more than uncorrected!"
    check("BH: never less strict than raw alpha", t_bh_conservative)

    def t_calib():
        p = np.array([0.1, 0.15, 0.85, 0.9])
        o = np.array([0, 0, 1, 1])
        bins = calibration_bins(p, o, n_bins=5)
        assert bins, "should produce bins"
        assert all(0 <= b["actual"] <= 1 for b in bins)
        # בדיקה שהערך 1.0 לא נופל בין הכיסאות
        p2 = np.array([1.0, 0.0])
        o2 = np.array([1, 0])
        b2 = calibration_bins(p2, o2, n_bins=5)
        assert sum(b["n"] for b in b2) == 2, "boundary values 0.0/1.0 dropped!"
    check("calibration: bins + boundary handling", t_calib)

    def t_bonferroni():
        assert bonferroni([]) == []
        assert bonferroni([0.001] * 5, 0.05) == [True] * 5
        assert bonferroni([0.02] * 5, 0.05) == [False] * 5, "0.02 > 0.05/5"
        assert bonferroni([0.009, 0.5], 0.05)[0] is True
        # בונפרוני לעולם לא מקל יותר מ-BH
        import numpy as _np
        rng = _np.random.default_rng(8)
        for _ in range(200):
            pv = list(rng.random(5))
            assert sum(bonferroni(pv, .05)) <= sum(benjamini_hochberg(pv, .05))
    check("bonferroni: correct + never looser than BH", t_bonferroni)

    def t_cluster_reduces_power():
        import numpy as _np
        rng = _np.random.default_rng(12)
        n, k = 100, 5
        cid = _np.arange(k).repeat(n // k)
        a = rng.normal(0.10, 0.02, n)
        m = rng.normal(0.12, 0.02, n)
        p_naive = cluster_robust_test(a, m, None)["p_value"]
        p_clust = cluster_robust_test(a, m, cid)["p_value"]
        assert p_clust > p_naive, \
            "clustering must WIDEN uncertainty, not narrow it"
    check("clustering widens uncertainty (as it must)", t_cluster_reduces_power)

    def t_cluster_metadata():
        import numpy as _np
        rng = _np.random.default_rng(21)
        cid = _np.array([0, 0, 1, 1, 2, 2, 3, 3])
        a = rng.normal(.10, .02, 8)
        m = rng.normal(.15, .02, 8)
        r = cluster_robust_test(a, m, cid)
        assert r["n"] == 8
        assert r["n_clusters"] == 4, f"must count clusters, got {r['n_clusters']}"
        assert r["clustered"] is True
        r2 = cluster_robust_test(a, m, None)
        assert r2["clustered"] is False
        assert r2["n_clusters"] == 8, "no clustering -> each row is a cluster"
        # מקרה קצה: שונות אפס עדיין מדווח מטא-דאטה
        r3 = cluster_robust_test(_np.full(8, .1), _np.full(8, .2), cid)
        assert r3["n_clusters"] == 4, "metadata must survive zero-variance path"
        assert r3["p_value"] == 1.0, "zero variance must not claim significance"
    check("cluster_robust: reports n vs n_clusters", t_cluster_metadata)



    def t_prereg_gate():
        from pmlab.core.stats import domain_verdict
        v = domain_verdict("mma",
                           {"n": 100, "n_clusters": 10, "mean_diff": 0.02},
                           True, True)
        assert "נעול" in v, "must hide verdict below preregistered n"
        assert target_clusters("mma") == 200
    check("pre-registration gate blocks early peeking", t_prereg_gate)


# ═════════ POWER ═════════
def qa_power():
    from pmlab.power import days_to_complete, required_n
    print("\n[ power ]")

    def t_monotonic():
        prev = 0
        for s in [0.03, 0.045, 0.06, 0.07, 0.08]:
            n, _ = required_n(s)
            assert n > prev, "n must grow as edge shrinks"
            prev = n
    check("required_n: monotonic in effect size", t_monotonic)

    def t_no_edge():
        n, eff = required_n(0.09)   # זהה לשוק
        assert n == float("inf"), "zero effect must give infinite n"
        n2, _ = required_n(0.15)    # גרוע מהשוק
        assert n2 == float("inf")
    check("required_n: no/negative edge -> inf", t_no_edge)

    def t_days():
        d = days_to_complete(1000, 10, 5)
        assert abs(d - 105) < 1e-6
        assert days_to_complete(1000, 0, 5) == float("inf")
    check("days_to_complete: math + zero-rate", t_days)


# ═════════ DOMAINS / MATCHING ═════════
def qa_matching():
    from pmlab.core.domains import DOMAINS
    from pmlab.platforms.polymarket import (
        days_to_end, is_binary, liquid_enough, market_prob, match_domain,
    )
    print("\n[ matching ]")

    future = (datetime.now(timezone.utc) + timedelta(days=7)).isoformat()
    far = (datetime.now(timezone.utc) + timedelta(days=400)).isoformat()
    past = (datetime.now(timezone.utc) - timedelta(days=5)).isoformat()

    def mk(q, end=future, **kw):
        d = {"question": q, "endDate": end, "description": "", "category": "",
             "slug": "", "outcomes": json.dumps(["Yes", "No"]),
             "liquidityNum": 50000}
        d.update(kw)
        return d

    def t_major_leagues_excluded():
        for q in ["Will Arsenal win the Premier League match?",
                  "Who wins the Champions League final?",
                  "Will Real Madrid win in La Liga?",
                  "Will the Chiefs win the Super Bowl?",
                  "Who wins the NBA Finals?"]:
            d = match_domain(mk(q), DOMAINS)
            assert d is None, f"major league leaked into domain {d}: {q}"
    check("major leagues excluded from all domains", t_major_leagues_excluded)

    def t_mma_match():
        m = mk("Will Jones win the UFC bout vs Miocic?")
        assert match_domain(m, DOMAINS) == "mma"
    check("mma: matches UFC markets", t_mma_match)

    def t_mls_match():
        m = mk("Will LAFC win the MLS match?")
        assert match_domain(m, DOMAINS) == "mls"
    check("mls: matches MLS markets", t_mls_match)

    def t_tier2_match():
        m = mk("Will Ajax win the Eredivisie match?")
        assert match_domain(m, DOMAINS) == "euro_tier2"
    check("euro_tier2: matches second-tier leagues", t_tier2_match)

    def t_tennis_grandslam_excl():
        m = mk("Will Alcaraz win Wimbledon?")
        assert match_domain(m, DOMAINS) != "tennis", \
            "grand slams must be excluded"
    check("tennis: grand slams excluded", t_tennis_grandslam_excl)

    def t_horizon():
        m = mk("Will Jones win the UFC bout?", end=far)
        assert match_domain(m, DOMAINS) is None, "beyond max_days must not match"
        m2 = mk("Will Jones win the UFC bout?", end=past)
        assert match_domain(m2, DOMAINS) is None, "already-past must not match"
    check("horizon: min/max days enforced", t_horizon)

    def t_no_match():
        m = mk("Will it rain tomorrow in Lisbon?")
        assert match_domain(m, DOMAINS) is None
    check("matching: unrelated returns None", t_no_match)

    def t_malformed():
        """קלטים משובשים חייבים להיכשל בשקט — ובאמת להיבדק."""
        for bad in [{}, {"question": None}, {"endDate": "garbage"},
                    {"endDate": None, "question": "ufc fight"}]:
            assert match_domain(bad, DOMAINS) is None, f"leaked on {bad}"

        # days_to_end: כל אחד מאלה חייב להחזיר None ממש
        for bad_date in [None, "", "garbage", "2026-13-45", "not-a-date"]:
            assert days_to_end(bad_date) is None, \
                f"days_to_end({bad_date!r}) must be None"

        # תאריך ללא אזור זמן — חייב להיות מטופל, לא לזרוק
        naive = days_to_end("2026-12-01T00:00:00")
        assert naive is None or isinstance(naive, float), \
            "naive datetime must be handled explicitly"

        # תאריך תקין חייב להחזיר מספר
        assert isinstance(days_to_end(future), float)
    check("matching: malformed input rejected (real assertions)", t_malformed)

    def t_binary():
        assert is_binary({"outcomes": json.dumps(["Yes", "No"])})
        assert not is_binary({"outcomes": json.dumps(["A", "B", "C"])})
        assert not is_binary({"outcomes": "not json"})
        assert not is_binary({})
        assert is_binary({"outcomes": ["Yes", "No"]}), "list form must work"
    check("is_binary: json + list + garbage", t_binary)

    def t_prob():
        """המחיר נקרא לפי תווית YES — לכן כל פיקסטורה חייבת תוויות."""
        yn = {"outcomes": json.dumps(["Yes", "No"])}
        assert market_prob({**yn, "outcomePrices": json.dumps(["0.62", "0.38"])}) == 0.62
        assert market_prob({**yn, "outcomePrices": ["0.4", "0.6"]}) == 0.4
        # סדר הפוך -> עדיין 0.70, כי קוראים לפי תווית
        assert market_prob({"outcomes": json.dumps(["No", "Yes"]),
                            "outcomePrices": json.dumps(["0.30", "0.70"])}) == 0.70
        assert market_prob({**yn, "outcomePrices": "bad"}) is None
        assert market_prob({}) is None
        assert market_prob({**yn, "outcomePrices": json.dumps([])}) is None
        # בלי תוויות מפורשות -> אין מיפוי -> None
        assert market_prob({"outcomes": json.dumps(["A", "B"]),
                            "outcomePrices": json.dumps(["0.6", "0.4"])}) is None
    check("market_prob: label-based + failure modes", t_prob)

    def t_liquid():
        assert liquid_enough({"liquidityNum": 10000})
        assert not liquid_enough({"liquidityNum": 100})
        assert not liquid_enough({})
        assert not liquid_enough({"liquidityNum": "abc"})
    check("liquid_enough: thresholds + bad types", t_liquid)


# ═════════ DB ═════════
def qa_db():
    from pmlab.core.db import DB, utcnow
    print("\n[ db ]")
    path = "qa_test.db"
    if os.path.exists(path):
        os.remove(path)
    db = DB(path)

    def t_knowledge():
        db.add_knowledge("mma", "u", "t", "fact one", 0.9)
        db.add_knowledge("mma", "u", "t", "fact two", 0.3)
        db.add_knowledge("mls", "u", "t", "other", 0.5)
        assert db.knowledge_count("mma") == 2
        assert db.knowledge_count("mls") == 1
        assert db.knowledge_count("nonexistent") == 0
        rows = db.knowledge_for("mma")
        assert rows[0]["salience"] >= rows[-1]["salience"], "must sort by salience"
    check("db: knowledge insert/count/sort", t_knowledge)

    def t_dedupe():
        fid = db.exec(
            """INSERT INTO forecasts (created_at, domain, platform, market_id,
               question, agent_prob, status) VALUES (?,?,?,?,?,?, 'open')""",
            (utcnow(), "mma", "polymarket", "m1", "Q?", 0.5))
        assert db.has_forecast("polymarket", "m1"), "must detect existing"
        assert not db.has_forecast("polymarket", "m2")
        assert not db.has_forecast("kalshi", "m1"), "platform must be part of key"
        return fid
    check("db: forecast dedupe by platform+id", t_dedupe)

    def t_resolve_flow():
        assert len(db.open_forecasts()) == 1
        db.exec("UPDATE forecasts SET status='resolved', outcome=1, "
                "brier_agent=0.1, brier_market=0.2 WHERE market_id='m1'")
        assert len(db.open_forecasts()) == 0
        assert len(db.resolved()) == 1
        assert len(db.resolved("mma")) == 1
        assert len(db.resolved("mls")) == 0
    check("db: open -> resolved transition", t_resolve_flow)

    os.remove(path)


# ═════════ BACKTEST ═════════
def qa_backtest():
    from pmlab.backtest import (
        COMPARISON_LEAD_HOURS, MODEL_CUTOFF, actual_outcome, cluster_id,
        resolution_window, token_ids,
    )
    print("\n[ backtest ]")

    def t_window():
        after = (MODEL_CUTOFF + timedelta(days=30)).isoformat()
        assert resolution_window({"endDate": after}) == "clean"
        before = "2025-03-15T00:00:00+00:00"
        assert resolution_window({"endDate": before}) == "contaminated_control"
        # אזור אפור בין החלונות -> לא נכלל
        gray = "2025-09-01T00:00:00+00:00"
        assert resolution_window({"endDate": gray}) is None
        assert resolution_window({"endDate": None}) is None
        assert resolution_window({"endDate": "junk"}) is None
    check("window: clean/contaminated/gray separation", t_window)

    def t_cutoff_strict():
        # יום לפני החיתוך אסור שייחשב נקי
        just_before = (MODEL_CUTOFF - timedelta(hours=1)).isoformat()
        assert resolution_window({"endDate": just_before}) != "clean", \
            "CONTAMINATION RISK: pre-cutoff classified as clean"
    check("window: cutoff boundary is strict", t_cutoff_strict)

    def t_outcome():
        yn = {"outcomes": json.dumps(["Yes", "No"])}
        assert actual_outcome({**yn, "outcomePrices": json.dumps(["1", "0"])}) == 1
        assert actual_outcome({**yn, "outcomePrices": json.dumps(["0", "1"])}) == 0
        assert actual_outcome({}) is None
        assert actual_outcome({**yn, "outcomePrices": "junk"}) is None
        # תיקו נבדק בנפרד תחת [void handling]
    check("actual_outcome: parsing + failure modes", t_outcome)

    def t_lead_time():
        assert COMPARISON_LEAD_HOURS > 0, \
            "comparison price must be taken BEFORE resolution"
        assert COMPARISON_LEAD_HOURS >= 12, \
            "lead time too short — price would already contain the outcome"
    check("backtest: fair comparison lead time", t_lead_time)

    def t_no_last_trade_price():
        import pathlib as _pl
        src = _pl.Path("pmlab/backtest.py").read_text()
        run_fn = src[src.find("def run("):]
        assert "lastTradePrice" not in run_fn, \
            "CRIT: backtest must not compare against last traded price"
        assert "historical_price" in run_fn, \
            "backtest must use historical price at fixed lead"
    check("backtest: uses historical not last-trade price", t_no_last_trade_price)

    def t_tokens():
        import json as _j
        assert token_ids({"clobTokenIds": _j.dumps(["a", "b"])}) == ["a", "b"]
        assert token_ids({"clobTokenIds": ["a"]}) == ["a"]
        assert token_ids({"clobTokenIds": "junk"}) == []
        assert token_ids({}) == []
    check("token_ids: parsing + failure modes", t_tokens)

    def t_cluster_id():
        c = cluster_id({"endDate": "2026-07-15T12:00:00Z"}, "mma")
        assert c == "mma|2026-07-15", f"got {c}"
        c2 = cluster_id({"endDate": "2026-07-15T23:00:00Z"}, "mma")
        assert c == c2, "same domain+day must share a cluster"
        c3 = cluster_id({"endDate": "2026-07-16T01:00:00Z"}, "mma")
        assert c3 != c, "different day must be a different cluster"
    check("cluster_id: groups by domain+day", t_cluster_id)


# ═════════ JSON PARSERS ═════════
def qa_parsers():
    from pmlab.core.parsing import (
        extract_probability, parse_json_array, parse_json_object,
    )
    print("\n[ parsers ]")

    def t_obj():
        assert parse_json_object('{"probability":0.3}')["probability"] == 0.3
        assert parse_json_object(
            '```json\n{"probability":0.4}\n```')["probability"] == 0.4
        assert parse_json_object(
            'Here you go:\n{"probability":0.5}\nHope that helps'
        )["probability"] == 0.5
        assert parse_json_object("no json here") is None
        assert parse_json_object("") is None
        assert parse_json_object("{broken") is None
    check("forecaster: json object extraction", t_obj)

    def t_arr():
        assert len(parse_json_array('[{"fact":"a"},{"fact":"b"}]')) == 2
        assert len(parse_json_array('```json\n[{"fact":"a"}]\n```')) == 1
        assert parse_json_array("nope") == []
        assert parse_json_array("") == []
        assert parse_json_array('{"not":"array"}') == []
    check("researcher: json array extraction", t_arr)

    def t_prob_validation():
        assert extract_probability({"probability": 0.3}) == 0.3
        assert extract_probability({"probability": "0.7"}) == 0.7
        assert extract_probability({"probability": 1.5}) is None, "out of range"
        assert extract_probability({"probability": -0.1}) is None
        assert extract_probability({"probability": float("nan")}) is None
        assert extract_probability({"probability": None}) is None
        assert extract_probability({}) is None
        assert extract_probability(None) is None
        assert extract_probability({"probability": 0.0}) == 0.0
        assert extract_probability({"probability": 1.0}) == 1.0
    check("probability: range + NaN validation", t_prob_validation)

    def t_arr_filters_nondict():
        r = parse_json_array('[{"fact":"a"}, "string", 42, {"fact":"b"}]')
        assert len(r) == 2, "non-dict entries must be filtered out"
    check("array: filters non-dict entries", t_arr_filters_nondict)

    def t_obj_rejects_array():
        assert parse_json_object('[1,2,3]') is None, "array must not pass as object"
    check("object: rejects array input", t_obj_rejects_array)


# ═════════ INTEGRATION ═════════
def qa_integration():
    """
    בדיקות היושרה של הניסוי.
    קוראות את הקוד מהדיסק ולא דרך import — כך הן רצות
    גם בלי SDK מותקן, וגם תופסות שינויים בקובץ ישירות.
    """
    import pathlib as _pl
    print("\n[ integration ]")

    def src(rel):
        return _pl.Path(rel).read_text()

    PRICE_TERMS = ["market_prob", "outcomePrices", "bestBid",
                   "lastTradePrice", "implied_prob"]

    def t_forecaster_blind():
        s = src("pmlab/agents/forecaster.py")
        for term in PRICE_TERMS:
            assert term not in s, f"PRICE LEAK: forecaster references '{term}'"
        assert "NOT been shown any market price" in s, \
            "forecaster prompt must state it has not seen a price"
    check("forecaster is blind to market price", t_forecaster_blind)

    def t_researcher_blind():
        s = src("pmlab/agents/researcher.py")
        for term in PRICE_TERMS:
            assert term not in s, f"PRICE LEAK: researcher references '{term}'"
        low = s.lower()
        for word in ["odds", "prediction market prices", "implied probabilities"]:
            assert word in low, f"researcher prompt must forbid '{word}'"
    check("researcher is blind to market price", t_researcher_blind)

    def t_backtest_no_search():
        s = src("pmlab/backtest.py")
        body = s[s.find("class BacktestForecaster"):]
        call = body[body.find("messages.create"):body.find("except")]
        assert "tools=" not in call, \
            "BACKTEST LEAK: web search must be disabled during backtest"
        assert "recalled_outcome" in s, \
            "backtest must ask the model to self-report recall"
    check("backtest: web search disabled + recall flag", t_backtest_no_search)

    def t_order_of_ops():
        """
        נבדק התנהגותית ב-orchestration.py.
        כאן רק שומר שהסדר בקוד לא יתהפך בעריכה עתידית.
        """
        s = src("pmlab/run.py")
        fn = s[s.find("def cmd_forecast"):s.find("def cmd_resolve")]
        i_fc = fn.find("fc.forecast(")
        i_ins = fn.find('db.insert_row("forecasts"')
        i_px = fn.find("market_prob(")
        assert -1 not in (i_fc, i_ins, i_px), "expected markers missing"
        assert i_fc < i_px, "ORDER BUG: price fetched before agent forecast"
        assert i_ins < i_px, "ORDER BUG: forecast must persist before price"
    check("run: forecast locked in before price lookup", t_order_of_ops)

    def t_cutoff_matches_reality():
        s = src("pmlab/backtest.py")
        assert "MODEL_CUTOFF" in s
        # החלון המזוהם חייב להיות לפני החיתוך, אחרת הגלאי חסר משמעות
        from pmlab.backtest import (
            CONTROL_WINDOW_END, CONTROL_WINDOW_START, MODEL_CUTOFF,
        )
        assert CONTROL_WINDOW_END < MODEL_CUTOFF, \
            "control window must end before cutoff or detector is meaningless"
        assert CONTROL_WINDOW_START < CONTROL_WINDOW_END
    check("backtest: control window precedes cutoff", t_cutoff_matches_reality)

    def t_risk_caps_present():
        s = src("pmlab/core/domains.py")
        assert "exclude" in s
        from pmlab.core.domains import DOMAINS, PREREGISTERED_CLUSTERS
        assert len(DOMAINS) == 4, f"expected 4 domains, got {len(DOMAINS)}"
        for k, d in DOMAINS.items():
            assert d.include, f"domain {k} has no include keywords"
            assert d.min_days < d.max_days, f"domain {k} has inverted horizon"
            assert d.prior_note, f"domain {k} missing research prior"
            assert d.structural_factors, f"domain {k} missing structural factors"
            assert k in PREREGISTERED_CLUSTERS, f"{k} has no preregistered n"
            assert PREREGISTERED_CLUSTERS[k] >= 200, \
                f"{k} target too low for adequate power"
    check("domains: config sanity", t_risk_caps_present)


# ═════════ POINT-IN-TIME (as_of) ═════════
def qa_point_in_time():
    """התיקון הקריטי ביותר: אכיפת as_of ואחזור לפי ישות."""
    import os
    from datetime import datetime, timedelta, timezone

    from pmlab.core.db import DB
    from pmlab.core.knowledge_store import (
        entity_overlap, extract_entities, knowledge_for_event,
        parse_ts, should_abstain,
    )
    print("\n[ point-in-time ]")

    path = "qa_pit.db"
    if os.path.exists(path):
        os.remove(path)
    db = DB(path)
    now = datetime(2026, 7, 1, tzinfo=timezone.utc)

    def t_entities():
        e = extract_entities("Will Jon Jones beat Stipe Miocic at UFC 320?")
        assert any("jones" in x for x in e), f"missed Jones: {e}"
        assert any("miocic" in x for x in e), f"missed Miocic: {e}"
        assert not any(x in ("will", "beat", "at") for x in e), \
            "stopwords leaked into entities"
        assert extract_entities("") == []
        assert extract_entities(None) == []
    check("entities: extracted from question", t_entities)

    def t_overlap():
        assert entity_overlap(["jon jones"], ["jon jones"]) == 1.0
        assert entity_overlap(["someone else"], ["jon jones"]) == 0.0
        half = entity_overlap(["jon jones"], ["jon jones", "miocic"])
        assert 0.4 < half < 0.6, f"expected ~0.5, got {half}"
        assert entity_overlap(["x"], []) == 0.0
    check("entity_overlap: fractional matching", t_overlap)

    def t_future_leak_blocked():
        """הבדיקה החשובה: מידע שפורסם אחרי as_of לא ייכנס לעולם."""
        past = (now - timedelta(days=5)).isoformat()
        future = (now + timedelta(days=5)).isoformat()
        db.add_knowledge("mma", "u", "t", "Jon Jones training report",
                         0.9, published_at=past, entity_ids=["jon jones"])
        db.add_knowledge("mma", "u", "t", "Jon Jones LEAKED FUTURE RESULT",
                         0.9, published_at=future, entity_ids=["jon jones"])

        r = knowledge_for_event(db, domain="mma",
                                question="Will Jon Jones win?", as_of=now)
        texts = " ".join(x.content for x in r.records)
        assert "LEAKED FUTURE" not in texts, \
            "CRITICAL: post-as_of record leaked into retrieval"
        assert r.n_excluded_by_time >= 1, "time exclusion not counted"
    check("as_of: future-published records blocked", t_future_leak_blocked)

    def t_unparseable_timestamp_rejected():
        """חותמת זמן משובשת — נפסלת, לא נכנסת בספק."""
        db.exec(
            "INSERT INTO knowledge (domain, collected_at, published_at, "
            "content, salience, superseded) VALUES (?,?,?,?,?,0)",
            ("mma", "not-a-date", "also-garbage",
             "Jon Jones garbage-dated claim", 0.9))
        r = knowledge_for_event(db, domain="mma",
                                question="Will Jon Jones win?", as_of=now)
        assert not any("garbage-dated" in x.content for x in r.records), \
            "record with unparseable timestamp must be rejected"
    check("as_of: unparseable timestamps rejected", t_unparseable_timestamp_rejected)

    def t_published_beats_collected():
        """published_at גובר על collected_at — זו כל הנקודה."""
        old_pub = (now - timedelta(days=30)).isoformat()
        db.add_knowledge("mls", "u", "t", "LAFC squad news",
                         0.9, published_at=old_pub, entity_ids=["lafc"])
        # as_of לפני הפרסום -> חייב להיחסם, למרות שנאסף מזמן
        early = now - timedelta(days=60)
        r = knowledge_for_event(db, domain="mls",
                                question="Will LAFC win?", as_of=early)
        assert not any("LAFC squad" in x.content for x in r.records), \
            "published_at must gate retrieval, not collected_at"
    check("as_of: published_at gates, not collected_at", t_published_beats_collected)

    def t_entity_filter():
        past = (now - timedelta(days=3)).isoformat()
        db.add_knowledge("mma", "u", "t", "Conor McGregor unrelated news",
                         0.9, published_at=past, entity_ids=["conor mcgregor"])
        r = knowledge_for_event(db, domain="mma",
                                question="Will Jon Jones win?", as_of=now)
        assert not any("McGregor" in x.content for x in r.records), \
            "irrelevant entity leaked into event retrieval"
        assert r.n_excluded_by_entity >= 1
    check("retrieval: filters by entity, not just domain", t_entity_filter)

    def t_abstain_gate():
        empty = knowledge_for_event(db, domain="mls",
                                    question="Will Nobody Xyz win?", as_of=now)
        ab, why = should_abstain(empty)
        assert ab is True, "must abstain when no relevant evidence"
        assert why, "abstention must carry a reason"
    check("abstain: triggers on thin evidence", t_abstain_gate)

    def t_parse_ts():
        assert parse_ts(None) is None
        assert parse_ts("garbage") is None
        d = parse_ts("2026-07-01T00:00:00")
        assert d is not None and d.tzinfo is not None, \
            "naive timestamps must be made timezone-aware"
    check("parse_ts: handles naive and invalid", t_parse_ts)

    os.remove(path)


# ═════════ BASE RATES ═════════
def qa_base_rates():
    import os

    from pmlab.core.base_rates import (
        GENERIC_PRIOR, classify_question, get_base_rate,
    )
    from pmlab.core.db import DB
    print("\n[ base rates ]")

    path = "qa_br.db"
    if os.path.exists(path):
        os.remove(path)
    db = DB(path)

    def t_classify():
        assert classify_question("mma", "main event bout") == "main_event"
        assert classify_question("mma", "co-main event bout") == "co_main"
        assert classify_question("mls", "anything") == "home"
        assert classify_question("unknown_domain", "x") == "generic"
    check("classify: maps question to reference class", t_classify)

    def t_supplied_not_invented():
        br = get_base_rate(db, "mma", "Will X win the main event?")
        assert 0.0 < br.value < 1.0
        assert br.source, "base rate must carry a source"
        assert br.confidence in ("high", "medium", "low")
    check("base rate: always sourced, never blank", t_supplied_not_invented)

    def t_unknown_falls_back_low_conf():
        br = get_base_rate(db, "nonexistent", "Will something happen?")
        assert br.value == GENERIC_PRIOR
        assert br.confidence == "low", \
            "unmatched reference class must flag low confidence"
    check("base rate: unknown domain -> low confidence", t_unknown_falls_back_low_conf)

    os.remove(path)


# ═════════ ECONOMIC MEASUREMENT ═════════
def qa_economics():
    import numpy as _np

    from pmlab.core.stats import is_economically_viable, simulated_pnl
    print("\n[ economics ]")

    def t_no_brier_conversion():
        import pmlab.core.stats as st
        assert not hasattr(st, "economic_edge"), \
            "invalid sqrt(Brier) conversion must be removed"
    check("removed: invalid Brier->profit formula", t_no_brier_conversion)

    def t_pnl_correct_null():
        """
        ההשערה הריקה הנכונה: מחיר השוק *הוא* ההסתברות האמיתית,
        והסוכן מוסיף רק רעש בלתי-תלוי.

        הניסוח הקודם של המבחן היה שגוי — הוא נתן לשוק רעש סביב
        האמת, וכל מנבא לא-מוטה "מרוויח" מזה. נתפס ב-QA.
        """
        rng = _np.random.default_rng(1)
        n = 30000
        m = rng.uniform(.1, .9, n)          # השוק מכויל לחלוטין
        o = (rng.random(n) < m).astype(float)
        a = _np.clip(m + rng.normal(0, .08, n), .02, .98)   # רעש טהור
        r = simulated_pnl(a, m, o, spread=0.03)
        assert r["mean_pnl"] < 0, \
            f"pure noise vs calibrated market must LOSE, got {r['mean_pnl']:+.4f}"
    check("pnl: noise vs calibrated market -> loses", t_pnl_correct_null)

    def t_pnl_zero_spread_null():
        """אותו דבר בלי ספרד: בערך אפס, לא רווח."""
        rng = _np.random.default_rng(7)
        n = 30000
        m = rng.uniform(.1, .9, n)
        o = (rng.random(n) < m).astype(float)
        a = _np.clip(m + rng.normal(0, .08, n), .02, .98)
        r = simulated_pnl(a, m, o, spread=0.0)
        assert abs(r["mean_pnl"]) < 0.01, \
            f"zero-spread noise should be ~0, got {r['mean_pnl']:+.4f}"
    check("pnl: noise, zero spread -> breakeven", t_pnl_zero_spread_null)

    def t_pnl_real_edge():
        """שוק מוטה, סוכן שרואה את ההטיה -> חייב להרוויח."""
        rng = _np.random.default_rng(2)
        n = 20000
        truth = rng.uniform(.1, .9, n)
        o = (rng.random(n) < truth).astype(float)
        m = _np.clip(truth + rng.normal(0, .12, n), .02, .98)  # שוק רועש
        a = _np.clip(truth + rng.normal(0, .02, n), .02, .98)  # סוכן חד
        r = simulated_pnl(a, m, o, spread=0.02)
        assert r["mean_pnl"] > 0, "real edge should show profit"
        assert 0 < r["trade_rate"] <= 1
        assert r["n_trades"] > 0
    check("pnl: real edge -> measurable profit", t_pnl_real_edge)

    def t_spread_hurts():
        rng = _np.random.default_rng(3)
        n = 20000
        p = rng.uniform(.1, .9, n)
        o = (rng.random(n) < p).astype(float)
        m = _np.clip(p + rng.normal(0, .10, n), .02, .98)
        a = _np.clip(p + rng.normal(0, .05, n), .02, .98)
        lo = simulated_pnl(a, m, o, spread=0.0)["mean_pnl"]
        hi = simulated_pnl(a, m, o, spread=0.06)["mean_pnl"]
        assert hi < lo, "wider spread must reduce profit"
    check("pnl: spread monotonically reduces profit", t_spread_hurts)

    def t_lower_bound_rule():
        """הכלל מהמסמך: גבול תחתון, לא ממוצע."""
        wide = {"n_trades": 50, "mean_pnl": 0.02, "sd": 0.9, "roi": 0.05}
        ok, why = is_economically_viable(wide)
        assert not ok, "positive mean with huge variance must be rejected"
        tight = {"n_trades": 200, "mean_pnl": 0.02, "sd": 0.05, "roi": 0.05}
        ok2, _ = is_economically_viable(tight)
        assert ok2, "tight positive interval should pass"
        thin = {"n_trades": 5, "mean_pnl": 0.5, "sd": 0.01, "roi": 1.0}
        ok3, _ = is_economically_viable(thin)
        assert not ok3, "too few trades must be rejected regardless"
    check("economics: uses lower bound, not mean", t_lower_bound_rule)


# ═════════ VOID HANDLING ═════════
def qa_void():
    from pmlab.backtest import actual_outcome
    import json as _j
    print("\n[ void handling ]")

    YN = {"outcomes": _j.dumps(["Yes", "No"])}

    def t_tie_is_void():
        assert actual_outcome({**YN, "outcomePrices": _j.dumps(["0.5", "0.5"])}) is None, \
            "50/50 must be void, not NO"
    check("tie 0.5/0.5 -> void not NO", t_tie_is_void)

    def t_disputed_is_void():
        m = {**YN, "outcomePrices": _j.dumps(["1", "0"]),
             "umaResolutionStatus": "disputed"}
        assert actual_outcome(m) is None, "disputed must be void"
    check("disputed resolution -> void", t_disputed_is_void)

    def t_nonsum_is_void():
        assert actual_outcome({**YN, "outcomePrices": _j.dumps(["0.9", "0.9"])}) is None, \
            "prices not summing to 1 must be void"
    check("prices not summing to 1 -> void", t_nonsum_is_void)

    def t_clean_still_works():
        assert actual_outcome({**YN, "outcomePrices": _j.dumps(["1", "0"])}) == 1
        assert actual_outcome({**YN, "outcomePrices": _j.dumps(["0", "1"])}) == 0
    check("clean resolutions still parse", t_clean_still_works)


def main():
    print("=" * 66)
    print("  QA — PMLAB")
    print("=" * 66)
    for fn in (qa_stats, qa_power, qa_matching, qa_db, qa_backtest,
               qa_parsers, qa_point_in_time, qa_base_rates, qa_economics,
               qa_void, qa_integration):
        fn()

    print("\n" + "=" * 66)
    print(f"  עברו: {len(PASS)}    נכשלו: {len(FAIL)}")
    if FAIL:
        print("\n  כשלים:")
        for n, e in FAIL:
            print(f"    ✗ {n}\n        {e}")
    print("=" * 66)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
