"""
בדיקות מקצה-לקצה.  python3 e2e.py

למה זה קיים: 71 בדיקות יחידה עברו, ובכל זאת שלושה מסלולים
חיים היו שבורים — הימנעות הקריסה את הריצה, מנוע ה-base rate
לא היה מחובר, והדוח קרס על נתונים אמיתיים.

בדיקות יחידה מוכיחות שרכיב עובד. הן לא מוכיחות שהוא **מחובר**.
כל בדיקה כאן מריצה מסלול שלם, עם API מזויף, בלי רשת.
"""

import os
import subprocess
import sys
import traceback
from datetime import datetime, timedelta, timezone

sys.path.insert(0, ".")

PASS, FAIL = [], []
DB_PATH = "e2e_test.db"


def check(name, fn):
    try:
        fn()
        PASS.append(name)
        print(f"  ✓ {name}")
    except AssertionError as e:
        FAIL.append((name, str(e)))
        print(f"  ✗ {name}\n      {e}")
    except Exception as e:  # noqa: BLE001
        FAIL.append((name, f"{type(e).__name__}: {e}"))
        print(f"  ✗ {name}\n      {type(e).__name__}: {e}")
        traceback.print_exc(limit=3)


def fresh_db():
    from pmlab.core.db import DB
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    return DB(DB_PATH)


# ═══════════════════════════════════════════════════════════
# מסלול 1: הימנעות — הבאג ש-71 הבדיקות פספסו
# ═══════════════════════════════════════════════════════════

def e2e_abstention():
    from pmlab.core.db import DB, utcnow
    print("\n[ מסלול הימנעות ]")

    def t_abstain_shape():
        """
        פלט ההימנעות הוא dict לא-ריק. `if not result: continue`
        לא תופס אותו, והקוד המשיך ל-result["probability"] → KeyError.
        """
        abstain_result = {"abstain": True, "abstain_reason": "thin evidence"}
        assert abstain_result, "abstention dict is truthy — this was the bug"
        assert "probability" not in abstain_result
        # הבדיקה הנכונה:
        assert abstain_result.get("abstain") is True
    check("abstention payload is truthy but has no probability", t_abstain_shape)

    def t_runner_handles_abstain():
        """הקוד החי חייב לבדוק abstain, לא רק ריקנות."""
        src = open("pmlab/run.py").read()
        fn = src[src.find("def cmd_forecast"):src.find("def cmd_resolve")]
        assert 'result.get("abstain")' in fn, \
            "CRITICAL: runner does not check for abstention"
        i_check = fn.find('result.get("abstain")')
        i_prob = fn.find('result["probability"]')
        assert i_check < i_prob, \
            "CRITICAL: probability accessed before abstention check"
    check("runner checks abstain before reading probability", t_runner_handles_abstain)

    def t_abstention_persisted():
        """הימנעות נשמרת. אחרת אי אפשר למדוד אם השער מועיל."""
        src = open("pmlab/run.py").read()
        fn = src[src.find("def cmd_forecast"):src.find("def cmd_resolve")]
        ab_block = fn[fn.find('result.get("abstain")'):]
        assert 'db.insert_row("forecasts"' in ab_block[:2000], \
            "abstentions must be persisted, not silently skipped"
        assert "abstain_reason" in ab_block[:2000]
    check("abstentions are persisted with reason", t_abstention_persisted)

    def t_abstain_status_queryable():
        db = fresh_db()
        db.exec(
            """INSERT INTO forecasts (created_at, domain, platform, market_id,
               question, abstained, abstain_reason, status)
               VALUES (?,?,?,?,?, 1, ?, 'abstained')""",
            (utcnow(), "mma", "polymarket", "m1", "Q?", "only 2 records"))
        rows = db.q("SELECT * FROM forecasts WHERE status='abstained'")
        assert len(rows) == 1
        assert rows[0]["abstain_reason"] == "only 2 records"
        # והכי חשוב: הימנעות לא נספרת כתחזית
        assert len(db.open_forecasts()) == 0, \
            "abstention must not pollute the open-forecast pool"
        assert len(db.resolved()) == 0
        os.remove(DB_PATH)
    check("abstention is a distinct status, not a forecast", t_abstain_status_queryable)


# ═══════════════════════════════════════════════════════════
# מסלול 2: base rate — נבנה אך לא חובר
# ═══════════════════════════════════════════════════════════

def e2e_base_rate():
    print("\n[ מסלול base rate ]")

    def t_connected():
        src = open("pmlab/run.py").read()
        assert "get_base_rate" in src, \
            "CRITICAL: base rate engine not imported into live path"
        fn = src[src.find("def cmd_forecast"):src.find("def cmd_resolve")]
        assert "get_base_rate(" in fn, "base rate not called in forecast loop"
        assert "base_rate=" in fn, "base rate not passed to forecaster"
    check("base rate engine wired into live path", t_connected)

    def t_ordering():
        """ה-base rate חייב להיות מחושב לפני הקריאה למודל."""
        src = open("pmlab/run.py").read()
        fn = src[src.find("def cmd_forecast"):src.find("def cmd_resolve")]
        i_br = fn.find("get_base_rate(")
        i_fc = fn.find("fc.forecast(")
        assert -1 not in (i_br, i_fc)
        assert i_br < i_fc, "base rate must be computed before forecasting"
    check("base rate computed before model call", t_ordering)

    def t_provenance_stored():
        src = open("pmlab/run.py").read()
        fn = src[src.find("def cmd_forecast"):src.find("def cmd_resolve")]
        for field in ("br.value", "br.source", "br.n", "br.confidence"):
            assert field in fn, f"base rate provenance '{field}' not persisted"
    check("base rate provenance persisted", t_provenance_stored)

    def t_forecaster_validates():
        src = open("pmlab/agents/forecaster.py").read()
        assert "base_rate_violation" in src, \
            "forecaster must flag when model overrides supplied base rate"
    check("forecaster flags base-rate override", t_forecaster_validates)


# ═══════════════════════════════════════════════════════════
# מסלול 3: הדוח — קרס על נתונים אמיתיים
# ═══════════════════════════════════════════════════════════

def e2e_report():
    from pmlab.core.db import DB, utcnow
    from pmlab.core.stats import brier
    print("\n[ מסלול הדוח ]")

    def seed(path, n=40, edge=True):
        if os.path.exists(path):
            os.remove(path)
        db = DB(path)
        import random
        random.seed(4)
        base = datetime(2026, 6, 1, tzinfo=timezone.utc)
        for dom in ("mma", "mls", "tennis", "euro_tier2"):
            for i in range(n):
                day = (base + timedelta(days=i // 4)).date().isoformat()
                p = random.uniform(.15, .85)
                out = 1 if random.random() < p else 0
                mkt = min(.98, max(.02, p + random.gauss(0, .09)))
                sd = .05 if (edge and dom == "mma") else .09
                agt = min(.98, max(.02, p + random.gauss(0, sd)))
                fid = db.exec(
                    """INSERT INTO forecasts (created_at, domain, platform,
                       market_id, question, end_date, cluster_id, agent_prob,
                       market_prob, coverage, n_records, status)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?, 'open')""",
                    (utcnow(), dom, "sim", f"{dom}-{i}", f"Q {dom} {i}?",
                     day, f"{dom}|{day}", agt, mkt, 0.7, 8))
                db.exec(
                    """UPDATE forecasts SET status='resolved', resolved_at=?,
                       outcome=?, brier_agent=?, brier_market=? WHERE id=?""",
                    (utcnow(), out, brier(agt, out), brier(mkt, out), fid))
        # גם הימנעויות
        for i in range(7):
            db.exec(
                """INSERT INTO forecasts (created_at, domain, platform,
                   market_id, question, abstained, abstain_reason, status)
                   VALUES (?,?,?,?,?, 1, ?, 'abstained')""",
                (utcnow(), "mma", "sim", f"ab-{i}", "Q?", "thin evidence"))
        return db

    def t_report_runs_on_real_data():
        """הבדיקה שהייתה חסרה. זו בדיוק הקריסה שדווחה."""
        seed("pmlab.db", n=40)
        r = subprocess.run([sys.executable, "-m", "pmlab.report"],
                           capture_output=True, text=True, timeout=180)
        assert r.returncode == 0, \
            f"report crashed:\n{r.stderr[-900:]}"
        assert "Traceback" not in r.stderr, f"exception:\n{r.stderr[-900:]}"
        out = r.stdout
        assert "מובהקות" in out, "report produced no significance section"
        assert "בונפרוני" in out, "Bonferroni not applied in report"
        assert "אשכולות" in out, "clusters not reported"
        assert "הימנעויות" in out, "abstentions not surfaced in report"
    check("report runs end-to-end on populated DB", t_report_runs_on_real_data)

    def t_report_uses_clusters():
        src = open("pmlab/report.py").read()
        assert "cluster_of" in src, "report must derive cluster ids"
        i_cid = src.find("cid = np.array")
        i_test = src.find("cluster_robust_test(agent, market, cid)")
        assert -1 not in (i_cid, i_test), "cluster ids not passed to the test"
        assert i_cid < i_test
    check("report passes cluster ids into inference", t_report_uses_clusters)

    def t_no_undefined_names():
        """
        סורק *קוד* בלבד — הערות ותיעוד מותר להם להזכיר שמות ישנים.
        קומפילציה לבדה לא תופסת שם לא-מוגדר בפייתון, לכן בודקים
        את עץ התחביר.
        """
        import ast as _ast
        tree = _ast.parse(open("pmlab/report.py").read())
        names = {n.id for n in _ast.walk(tree) if isinstance(n, _ast.Name)}
        for bad in ("MIN_N_PER_DOMAIN", "TARGET_N_PER_DOMAIN"):
            assert bad not in names, f"undefined name {bad} used in code"
        # וגם: כל שם גלובלי שנקרא חייב להיות מיובא או מוגדר
        imported = set()
        for node in _ast.walk(tree):
            if isinstance(node, (_ast.Import, _ast.ImportFrom)):
                for a in node.names:
                    imported.add(a.asname or a.name.split(".")[0])
            elif isinstance(node, _ast.FunctionDef):
                imported.add(node.name)
            elif isinstance(node, _ast.Assign):
                for t in node.targets:
                    if isinstance(t, _ast.Name):
                        imported.add(t.id)
        import builtins
        unknown = {n for n in names
                   if n not in imported and not hasattr(builtins, n)}
        # שמות מקומיים בתוך פונקציות ייפלו לכאן — מסננים לפי אות גדולה,
        # כי קבועים גלובליים הם בדרך כלל UPPER_CASE
        consts = {n for n in unknown if n.isupper() and len(n) > 3}
        assert not consts, f"undefined global constants: {consts}"
    check("report has no undefined constants", t_no_undefined_names)

    def t_verdict_signature():
        import inspect

        from pmlab.core.stats import domain_verdict
        params = list(inspect.signature(domain_verdict).parameters)
        assert len(params) == 4, f"expected 4 params, got {params}"
        src = open("pmlab/report.py").read()
        assert "domain_verdict(key, r, ok_bh, ok_bf)" in src, \
            "report calls domain_verdict with wrong arity"
    check("domain_verdict called with correct arity", t_verdict_signature)

    if os.path.exists("pmlab.db"):
        os.remove("pmlab.db")


# ═══════════════════════════════════════════════════════════
# מסלול 4: הכרעה קנונית אחת
# ═══════════════════════════════════════════════════════════

def e2e_resolution():
    print("\n[ מסלול הכרעה ]")

    def t_single_source_of_truth():
        src = open("pmlab/run.py").read()
        assert "from .backtest import actual_outcome" in src, \
            "live path must use the canonical resolver"
        assert "outcome = 1 if final > 0.5 else 0" not in src, \
            "CRITICAL: live path still has its own ad-hoc resolution rule"
    check("live path uses canonical actual_outcome", t_single_source_of_truth)

    def t_void_marks_void():
        src = open("pmlab/run.py").read()
        fn = src[src.find("def cmd_resolve"):]
        assert "status='void'" in fn, \
            "void markets must be marked void, not scored as losses"
    check("void markets marked void in live path", t_void_marks_void)

    def t_consistency():
        """אותו קלט → אותה תוצאה בשני המסלולים."""
        import json as _j

        from pmlab.backtest import actual_outcome
        yn = {"outcomes": _j.dumps(["Yes", "No"])}
        cases = [
            ({**yn, "outcomePrices": _j.dumps(["1", "0"])}, 1),
            ({**yn, "outcomePrices": _j.dumps(["0", "1"])}, 0),
            ({**yn, "outcomePrices": _j.dumps(["0.5", "0.5"])}, None),
            ({**yn, "outcomePrices": _j.dumps(["0.9", "0.9"])}, None),
            ({**yn, "outcomePrices": _j.dumps(["1", "0"]),
              "umaResolutionStatus": "disputed"}, None),
            # סדר הפוך — חייב להיקרא לפי תווית
            ({"outcomes": _j.dumps(["No", "Yes"]),
              "outcomePrices": _j.dumps(["0", "1"])}, 1),
            # בלי תוויות — נדחה
            ({"outcomes": _j.dumps(["A", "B"]),
              "outcomePrices": _j.dumps(["1", "0"])}, None),
        ]
        for market, expected in cases:
            assert actual_outcome(market) == expected, \
                f"resolution mismatch on {market}"
    check("resolution rule consistent across all cases", t_consistency)


# ═══════════════════════════════════════════════════════════
# מסלול 5: point-in-time מקצה לקצה
# ═══════════════════════════════════════════════════════════

def e2e_point_in_time():
    from pmlab.core.knowledge_store import knowledge_for_event
    print("\n[ מסלול point-in-time ]")

    def t_researcher_stores_provenance():
        src = open("pmlab/agents/researcher.py").read()
        assert "published_at=" in src, \
            "CRITICAL: researcher does not store publication time"
        assert "entity_ids=" in src, \
            "CRITICAL: researcher does not store entities"
        assert "published_at" in src and "null" in src.lower(), \
            "prompt must instruct the model not to guess dates"
    check("researcher preserves published_at and entities", t_researcher_stores_provenance)

    def t_full_chain_blocks_future():
        """שרשרת מלאה: כתיבה → אחזור → חסימה."""
        db = fresh_db()
        now = datetime(2026, 7, 1, tzinfo=timezone.utc)
        db.add_knowledge("mma", "u", "t", "Jones camp report",
                         0.9, published_at=(now - timedelta(days=2)).isoformat(),
                         entity_ids=["jon jones"])
        db.add_knowledge("mma", "u", "t", "Jones FUTURE result",
                         0.9, published_at=(now + timedelta(days=2)).isoformat(),
                         entity_ids=["jon jones"])
        r = knowledge_for_event(db, domain="mma",
                                question="Will Jon Jones win?", as_of=now)
        joined = " ".join(x.content for x in r.records)
        assert "FUTURE" not in joined, "future info leaked through full chain"
        assert "camp report" in joined, "valid past info was wrongly excluded"
        os.remove(DB_PATH)
    check("write->retrieve chain blocks future info", t_full_chain_blocks_future)

    def t_runner_persists_as_of():
        src = open("pmlab/run.py").read()
        fn = src[src.find("def cmd_forecast"):src.find("def cmd_resolve")]
        for field in ("as_of", "coverage", "n_records",
                      "model_version", "prompt_hash", "cluster_id"):
            assert field in fn, f"audit field '{field}' not persisted by runner"
    check("runner persists full audit metadata", t_runner_persists_as_of)


# ═══════════════════════════════════════════════════════════
# מסלול 6: תיקוני הביקורת הרביעית
# ═══════════════════════════════════════════════════════════

def e2e_review4():
    from pmlab.core.base_rates import empirical_base_rate, get_base_rate
    from pmlab.core.db import DB, utcnow
    print("\n[ ביקורת 4 ]")

    def t_abstention_retryable():
        """[3.3] הימנעות אינה סופית — אחרת מידע חדש לעולם לא ייבדק."""
        db = fresh_db()
        past = (datetime.now(timezone.utc) - timedelta(hours=1)).isoformat()
        db.exec(
            """INSERT INTO forecasts (created_at, domain, platform, market_id,
               question, abstained, retry_after, status)
               VALUES (?,?,?,?,?, 1, ?, 'abstained')""",
            (utcnow(), "mma", "polymarket", "m1", "Q?", past))
        assert db.has_forecast("polymarket", "m1") is False, \
            "CRITICAL: expired abstention must be retryable"

        future = (datetime.now(timezone.utc) + timedelta(hours=5)).isoformat()
        db.exec("UPDATE forecasts SET retry_after=? WHERE market_id='m1'",
                (future,))
        assert db.has_forecast("polymarket", "m1") is True, \
            "abstention within cooldown must not be retried immediately"
        os.remove(DB_PATH)
    check("abstention expires and becomes retryable", t_abstention_retryable)

    def t_real_forecast_still_blocks():
        db = fresh_db()
        db.exec(
            """INSERT INTO forecasts (created_at, domain, platform, market_id,
               question, agent_prob, status) VALUES (?,?,?,?,?,?, 'open')""",
            (utcnow(), "mma", "polymarket", "m2", "Q?", 0.6))
        assert db.has_forecast("polymarket", "m2") is True, \
            "a real forecast must still prevent duplicates"
        os.remove(DB_PATH)
    check("real forecasts still deduplicated", t_real_forecast_still_blocks)

    def t_ref_class_filters():
        """[3.1] main_event ו-co_main חייבים לקבל priors שונים."""
        db = fresh_db()
        for i in range(40):
            db.exec(
                """INSERT INTO forecasts (created_at, domain, platform,
                   market_id, question, reference_class, agent_prob, outcome,
                   status) VALUES (?,?,?,?,?,?,?,?, 'resolved')""",
                (utcnow(), "mma", "sim", f"me{i}", "Q?", "main_event",
                 0.6, 1 if i < 32 else 0))          # 80%
        for i in range(40):
            db.exec(
                """INSERT INTO forecasts (created_at, domain, platform,
                   market_id, question, reference_class, agent_prob, outcome,
                   status) VALUES (?,?,?,?,?,?,?,?, 'resolved')""",
                (utcnow(), "mma", "sim", f"cm{i}", "Q?", "co_main",
                 0.6, 1 if i < 20 else 0))          # 50%
        me = empirical_base_rate(db, "mma", "main_event")
        cm = empirical_base_rate(db, "mma", "co_main")
        assert me is not None and cm is not None, "cohorts not found"
        assert abs(me.value - 0.80) < 0.05, f"main_event got {me.value}"
        assert abs(cm.value - 0.50) < 0.05, f"co_main got {cm.value}"
        assert me.value != cm.value, \
            "CRITICAL: reference classes must not share one pooled prior"
        os.remove(DB_PATH)
    check("base rates filter by reference class", t_ref_class_filters)

    def t_directional_warning():
        """[3.1] prior כיווני בלי לדעת מי YES — חייב להיות מסומן ומרוכך."""
        db = fresh_db()
        br = get_base_rate(db, "mma", "Will X win the main event?")
        assert br.directional_warning, \
            "directional prior must carry a warning when YES side unknown"
        assert abs(br.value - 0.5) < abs(0.77 - 0.5), \
            "unverified directional prior must be shrunk toward 0.5"
        assert br.confidence == "low"
        os.remove(DB_PATH)
    check("directional priors flagged and shrunk", t_directional_warning)

    def t_fixed_horizon():
        """[3.4] תחזיות חייבות להיווצר באופק קבוע, והשער לפני החיזוי."""
        from pmlab.core.domains import (
            FORECAST_HORIZON_HOURS, HORIZON_TOLERANCE_HOURS,
        )
        assert FORECAST_HORIZON_HOURS > 0 and HORIZON_TOLERANCE_HOURS > 0
        src = open("pmlab/run.py").read()
        fn = src[src.find("def cmd_forecast"):src.find("def cmd_resolve")]
        assert "horizon_eligible" in fn, "horizon gate not applied per market"
        i_gate = fn.find("horizon_eligible")
        i_fc = fn.find("fc.forecast(")
        assert -1 not in (i_gate, i_fc)
        assert i_gate < i_fc, "horizon must be checked before forecasting"
    check("fixed forecast horizon enforced", t_fixed_horizon)

    def t_horizon_persisted():
        src = open("pmlab/run.py").read()
        fn = src[src.find("def cmd_forecast"):src.find("def cmd_resolve")]
        for f in ("forecast_horizon_hours", "reference_class",
                  "base_rate_value", "base_rate_source"):
            assert f in fn, f"field '{f}' not persisted"
    check("horizon and base-rate provenance persisted", t_horizon_persisted)

    def t_no_stale_domains():
        """[3.7] אין הפניות לתחומים שכבר לא קיימים."""
        import glob as _g

        from pmlab.core.domains import DOMAINS
        # שמות התחומים הישנים, מורכבים בזמן ריצה כדי שהבדיקה
        # לא תיתפס על המחרוזות של עצמה
        stale = {"sports" + "_tail", "mac" + "ro", "geo" + "politics",
                 "te" + "ch", "cry" + "pto"}
        live = set(DOMAINS)
        for f in _g.glob("pmlab/**/*.py", recursive=True) + ["e2e.py", "qa.py"]:
            src = open(f).read()
            for key in stale - live:
                assert f'"{key}"' not in src, \
                    f"stale domain '{key}' referenced in {f}"
    check("no references to removed domains", t_no_stale_domains)


# ═══════════════════════════════════════════════════════════
# מסלול 7: הביקורת החמישית — בדיקות התנהגותיות
# ═══════════════════════════════════════════════════════════

def e2e_review5():
    """
    הביקורת ציינה שחלק מהבדיקות מוודאות מבנה קוד ולא התנהגות.
    כל בדיקה כאן מריצה התנהגות אמיתית עם קלט אמיתי.
    """
    from pmlab.core.base_rates import get_base_rate
    from pmlab.core.db import DB, utcnow
    from pmlab.core.event_sides import parse_sides, verify_direction
    print("\n[ ביקורת 5 — התנהגות ]")

    Q = "Will Jon Jones beat Tom Aspinall at UFC 320?"

    def t_parse_sides():
        s_ = parse_sides(Q)
        assert "Jones" in s_.yes_entity, f"YES={s_.yes_entity}"
        assert "Aspinall" in s_.no_entity, f"NO={s_.no_entity}"
        assert s_.parse_confidence == "high"
        # שאלה לא ניתנת לפירוק -> ריק, לא ניחוש
        bad = parse_sides("Will something interesting happen this year?")
        assert not bad.no_entity, "must not invent a NO side"
        assert bad.parse_confidence in ("low", "medium")
    check("sides parsed from question text", t_parse_sides)

    def t_unverified_forces_neutral():
        """[דרישה 1] הבדיקה המרכזית. כיוון לא מאומת → 0.50 בדיוק."""
        db = fresh_db()
        s_ = parse_sides(Q)
        br = get_base_rate(db, "mma", Q, sides=s_)
        assert br.value == 0.50, \
            f"CRITICAL: unverified direction gave {br.value}, must be 0.50"
        br2 = get_base_rate(db, "mma", Q, sides=None)
        assert br2.value == 0.50, "no sides at all must also give 0.50"
        os.remove(DB_PATH)
    check("unverified direction forces exactly 0.50", t_unverified_forces_neutral)

    def t_complement():
        """YES=פייבוריט → prior. NO=פייבוריט → המשלים."""
        db = fresh_db()
        a = verify_direction(parse_sides(Q), favorite="Jon Jones",
                             reference_side="favorite")
        b = verify_direction(parse_sides(Q), favorite="Tom Aspinall",
                             reference_side="favorite")
        pa = get_base_rate(db, "mma", Q, sides=a).value
        pb = get_base_rate(db, "mma", Q, sides=b).value
        assert pa > 0.5, f"YES=favorite should be >0.5, got {pa}"
        assert pb < 0.5, f"NO=favorite should be <0.5, got {pb}"
        assert abs((pa + pb) - 1.0) < 1e-9, \
            f"complement broken: {pa} + {pb} != 1"
        os.remove(DB_PATH)
    check("verified sides produce exact complements", t_complement)

    def t_bad_favorite_not_verified():
        """פייבוריט שאינו אף אחד מהצדדים — לא נחשב מאומת."""
        s_ = verify_direction(parse_sides(Q), favorite="Somebody Else",
                              reference_side="favorite")
        assert not s_.direction_verified, \
            "favorite outside the two sides must not verify"
    check("stray favorite does not verify direction", t_bad_favorite_not_verified)

    # ---------- ראיות ----------
    from datetime import datetime as _dt

    class Rec:
        def __init__(self, content, url="", ents=None, pub=None):
            self.content = content
            self.source_url = url
            self.entity_ids = ents or []
            self.published_at = pub or _dt(2026, 7, 1, tzinfo=timezone.utc)
            self.collected_at = self.published_at

    from pmlab.core.evidence import (
        assess_evidence, cluster_claims, evidence_fingerprint,
        independent_sources, should_abstain,
    )

    def t_paraphrases_collapse():
        """[דרישה 2] ארבעה ניסוחים של אותה עובדה = טענה אחת."""
        recs = [
            Rec("Jon Jones suffered a knee injury during training camp"),
            Rec("Jones sustained a knee injury in his training camp"),
            Rec("Reports say Jon Jones has a knee injury from training camp"),
            Rec("Jon Jones knee injury reported during camp training"),
        ]
        cl = cluster_claims(recs)
        assert len(cl) == 1, \
            f"CRITICAL: 4 paraphrases became {len(cl)} claims, expected 1"
    check("paraphrased duplicates collapse to one claim", t_paraphrases_collapse)

    def t_distinct_claims_survive():
        recs = [
            Rec("Jon Jones suffered a knee injury during training camp"),
            Rec("Tom Aspinall knocked out his last three opponents quickly"),
            Rec("The bout was moved from Las Vegas to Abu Dhabi"),
        ]
        assert len(cluster_claims(recs)) == 3, "distinct claims must not merge"
    check("genuinely distinct claims stay separate", t_distinct_claims_survive)

    def t_syndication_not_independent():
        recs = [Rec("x", "https://espn.com/a"), Rec("y", "https://espn.co.uk/b")]
        assert independent_sources(recs) == 1, \
            "same media group must count as one independent source"
        recs2 = [Rec("x", "https://espn.com/a"), Rec("y", "https://bbc.com/b")]
        assert independent_sources(recs2) == 2
    check("syndicated sources counted once", t_syndication_not_independent)

    def t_one_sided_abstains():
        """[דרישה 3] ארבע רשומות על צד A ואפס על B → הימנעות."""
        sides = parse_sides(Q)
        recs = [
            Rec("Jon Jones looked sharp in camp", "https://a.com/1"),
            Rec("Jon Jones reach advantage is significant", "https://b.com/2"),
            Rec("Jon Jones wrestling credentials are elite", "https://c.com/3"),
            Rec("Jon Jones has fought at heavyweight before", "https://d.com/4"),
        ]
        q = assess_evidence(recs, sides)
        assert q.coverage_no_side == 0.0, "NO side has no evidence"
        ab, why = should_abstain(q, sides)
        assert ab, "CRITICAL: one-sided evidence must force abstention"
        assert "NO" in why or "חד-צדדי" in why
    check("one-sided evidence forces abstention", t_one_sided_abstains)

    def t_two_sided_passes():
        sides = parse_sides(Q)
        recs = [
            Rec("Jon Jones looked sharp in his camp", "https://a.com/1"),
            Rec("Tom Aspinall finished his last three fights", "https://b.com/2"),
            Rec("Jones and Aspinall both made weight at the ceremony",
                "https://c.com/3"),
            Rec("Aspinall speed is his main asset here", "https://d.com/4"),
        ]
        q = assess_evidence(recs, sides)
        assert q.coverage_yes_side > 0 and q.coverage_no_side > 0
        ab, why = should_abstain(q, sides)
        assert not ab, f"balanced evidence should pass, got: {why}"
    check("balanced two-sided evidence passes gate", t_two_sided_passes)

    def t_duplicates_fail_gate():
        """ארבע כפילויות לא מספקות את סף הראיות."""
        sides = parse_sides(Q)
        recs = [Rec("Jon Jones suffered a knee injury in training camp",
                    f"https://s{i}.com/x") for i in range(4)]
        q = assess_evidence(recs, sides)
        assert q.n_records == 4
        assert q.n_unique_claims == 1, "duplicates must collapse"
        ab, _ = should_abstain(q, sides)
        assert ab, "CRITICAL: 4 duplicates must not satisfy evidence gate"
    check("duplicate records cannot satisfy the gate", t_duplicates_fail_gate)

    def t_fingerprint_event_specific():
        """[דרישה 5] טביעת אצבע משתנה רק על מידע רלוונטי לאירוע."""
        sides = parse_sides(Q)
        base = [Rec("Jon Jones camp report", "https://a.com/1"),
                Rec("Tom Aspinall camp report", "https://b.com/2")]
        f1 = evidence_fingerprint(base, sides)
        # מידע על קרב אחר באותו תחום — אסור לשנות
        other = base + [Rec("Conor McGregor announces return",
                            "https://c.com/3")]
        assert evidence_fingerprint(other, sides) == f1, \
            "unrelated domain news must NOT change event fingerprint"
        # מידע חדש על צד באירוע — חייב לשנות
        new = base + [Rec("Tom Aspinall pulled out with a shoulder injury",
                          "https://d.com/4")]
        assert evidence_fingerprint(new, sides) != f1, \
            "CRITICAL: new event-side evidence must change fingerprint"
    check("fingerprint changes only on event-relevant evidence",
          t_fingerprint_event_specific)

    def t_retry_on_evidence_change():
        db = fresh_db()
        future = (datetime.now(timezone.utc) + timedelta(hours=5)).isoformat()
        db.exec(
            """INSERT INTO forecasts (created_at, domain, platform, market_id,
               question, abstained, retry_after, evidence_fingerprint, status)
               VALUES (?,?,?,?,?, 1, ?, ?, 'abstained')""",
            (utcnow(), "mma", "polymarket", "m9", Q, future, "FP_OLD"))
        assert db.has_forecast("polymarket", "m9", "FP_OLD") is True, \
            "unchanged evidence within cooldown must not retry"
        assert db.has_forecast("polymarket", "m9", "FP_NEW") is False, \
            "CRITICAL: changed evidence must bypass cooldown"
        os.remove(DB_PATH)
    check("evidence change bypasses retry cooldown", t_retry_on_evidence_change)

    # ---------- אופק ----------
    def t_horizon_behaviour():
        """[סעיף 10] התנהגות באמת, לא רק קיום הקבוע."""
        from pmlab.core.domains import horizon_eligible as eligible
        assert eligible(24), "24h must be eligible"
        assert not eligible(17), "17h must be excluded"
        assert not eligible(31), "31h must be excluded"
        assert eligible(18) and eligible(30), "window edges must be inclusive"
        assert not eligible(None), "missing horizon must be excluded"
        assert not eligible(0.5), "already-resolving market must be excluded"
    check("horizon window behaves at 17/24/31 hours", t_horizon_behaviour)

    def t_price_after_lock():
        """[דרישה 6] המחיר נשלף אחרי נעילת התחזית."""
        src = open("pmlab/run.py").read()
        fn = src[src.find("def cmd_forecast"):src.find("def cmd_resolve")]
        i_lock = fn.find("locked_at = utcnow()")
        i_fetch = fn.find("market_by_condition")
        i_ins = fn.find('db.insert_row("forecasts"')
        assert -1 not in (i_lock, i_fetch, i_ins)
        assert i_ins < i_fetch, "forecast must be persisted before price refetch"
        assert "market_fetched_at" in fn, "actual fetch time not stored"
        assert "market_snapshot_source" in fn, "snapshot provenance not stored"
    check("market price refetched after forecast lock", t_price_after_lock)

    def t_event_specific_queries():
        """[דרישה 4] שאילתות מחקר מתייחסות לשני הצדדים."""
        from pmlab.core.event_sides import event_research_queries
        sides = parse_sides(Q)
        qs = event_research_queries(sides, "mma")
        tags = {x["side"] for x in qs}
        assert tags == {"yes", "no", "shared"}, f"got {tags}"
        joined = " ".join(x["query"] for x in qs)
        assert "Jones" in joined and "Aspinall" in joined, \
            "queries must name both resolved entities"
    check("research queries are event- and side-specific",
          t_event_specific_queries)


def main():
    print("=" * 66)
    print("  END-TO-END — מסלולים חיים, לא רכיבים")
    print("=" * 66)
    for fn in (e2e_abstention, e2e_base_rate, e2e_report,
               e2e_resolution, e2e_point_in_time, e2e_review4,
               e2e_review5):
        fn()

    print("\n" + "=" * 66)
    print(f"  עברו: {len(PASS)}    נכשלו: {len(FAIL)}")
    if FAIL:
        print("\n  כשלים:")
        for n, e in FAIL:
            print(f"    ✗ {n}\n        {e}")
    print("=" * 66)
    for f in (DB_PATH, "pmlab.db"):
        if os.path.exists(f):
            os.remove(f)
    return 1 if FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
